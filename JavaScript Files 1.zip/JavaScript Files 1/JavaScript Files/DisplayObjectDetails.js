var fs = require('fs');
 
// Read the input file
var input = fs.readFileSync('input.txt').toString().trim();
var array = input.split("\n");
 
// Create an object and store the values
var userDetails = new Object();
userDetails.name = array[0];
userDetails.age = array[1];
userDetails.mobileNumber = array[2];
userDetails.state = array[3];
 
// Output the object
console.log(userDetails);