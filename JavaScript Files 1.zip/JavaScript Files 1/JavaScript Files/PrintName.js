var fs = require('fs');
var input = fs.readFileSync('input.txt').toString().trim(); // trim to remove newline
 
let object = new Object()
 
object = {
    STU1: 'John',
    STU2: 'Joe',
    STU3: 'Canio'
};
 
console.log(object[input]);