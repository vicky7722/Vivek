var fs = require('fs');
var value = fs.readFileSync('input.txt', 'utf8').toString().trim();
function checkVowel(char) {
    switch (char) {
        case 'a':
            console.log(1);
            break;
        case 'e':
            console.log(2);
            break;
        case 'i':
            console.log(3);
            break;
        case 'o':
            console.log(4);
            break;
        case 'u':
            console.log(5);
            break;
        default:
            console.log('Invalid choice');
    }
}
 
// Call the function with the input value
checkVowel(value);