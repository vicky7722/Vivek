//fill your code
function login(){
    const form = document.forms[0];
    const username = form.elements.username.value;
 
    form.style.display = "none";
    const welcomeDiv = document.getElementById("welcome");
    welcomeDiv.style.display="block";
 
    document.getElementById("displayName").textContent = username;
}