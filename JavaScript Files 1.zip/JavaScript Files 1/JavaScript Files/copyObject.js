var fs = require('fs');

// Read the input file
var input = fs.readFileSync('input.txt').toString().trim();

// Create object1 using new Object() with the given input
var object1 = new Object();
object1.message = input;

// Create object2 using new Object()
var object2 = new Object();

// Use Object.assign() to assign object1 to object2 (source to destination)
Object.assign(object2, object1);

// Output the destination object
console.log(object2);
