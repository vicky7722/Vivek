var fs = require('fs');
var input = fs.readFileSync("input.txt").toString();
 
//Fill your code
 
let len = input.trim().length;
 
let checker = new Object();
 
checker.evenOrOdd = function(number) {
    if (number % 2 === 0) {
        console.log("Even");
    } else {
        console.log("Odd");
    }
};
 
 
checker.evenOrOdd(len)