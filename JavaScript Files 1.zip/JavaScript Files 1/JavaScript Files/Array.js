let num=[5,7,9,11]
console.log(num[0]);
let stud_names = ["abc","fgh","sai","priya","teja"]
console.log(stud_names)
stud_names.push("sss")
console.log(stud_names)
stud_names.pop()
stud_names.pop();
console.log(stud_names)
console.log(stud_names.length)