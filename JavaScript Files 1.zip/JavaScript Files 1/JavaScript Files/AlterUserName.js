var fs = require('fs');
 
// Read the input file
var value = fs.readFileSync("input.txt").toString().trim();
 
// Create an object and store the value
var user = new Object();
user.username = value;
 
// Modify the username
if (user.username.startsWith("Hend")) {
    user.username = user.username.replace("Hend", "Hendry");
}
 
// Output the modified username
console.log(user.username);