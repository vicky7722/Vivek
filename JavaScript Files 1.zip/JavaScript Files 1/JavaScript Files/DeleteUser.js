var fs = require('fs');

// Read the input file
var userIdToDelete = fs.readFileSync('input.txt').toString().trim();

// Create an object with initial values
var users = new Object();
users.S1 = "John";
users.S2 = "James";
users.S3 = "Jack";

// Delete the user based on the user ID
delete users[userIdToDelete];

// Output the object after deletion
console.log(users);
