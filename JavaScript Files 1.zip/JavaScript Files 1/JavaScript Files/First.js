let age=18;
if(age>=18)
{
    console.log("Number is 18");
    console.log('Hello World')
}
function evenOdd()
{
    let x=8
    if(x%2==0)
    {
        console.log("Even Number")
    }
    else
    {
        console.log("Odd Number");
    }
}
function Name(name)
{
    console.log("Hello "+name)
}
evenOdd()
Name("Priya")