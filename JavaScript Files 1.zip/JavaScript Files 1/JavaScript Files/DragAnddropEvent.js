//fill your code
function isLiItem(event){
    return event && event.tagName === 'LI';
}
 
let draggedItem = null;
 
function onDragStart(event){
    draggedItem = event.target;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData("text/html", event.target.innerHTML);
    event.target.classList.add('dragging');
}
 
function onDragEnter(event){
    if(isLiItem(event.target) && event.target != draggedItem){
        event.target.classList.add('over');
    }
}
 
function onDragLeave(event){
    if(isLiItem(event.target)){
        event.target.classList.remove('over');
    }
}
 
function onDragOver(event){
    if(isLiItem(event.target)){
        event.preventDefault();
        event.dataTransfer.dropEffect = 'move';
    }
}
function onDragDrop(event){
    event.preventDefault();
    if(isLiItem(event.target) && event.target != draggedItem){
        let draggedHTML = draggedItem.innerHTML;
        draggedItem.innerHTML = event.target.innerHTML;
        event.target.innerHTML = draggedHTML;
    }
    event.target.classList.remove('over');
}
 
function onDragEnd(event){
    document.querySelectorAll('.draggable-list li').forEach(item => {
        item.classList.remove('over','dragging');
    });
}
 
document.querySelectorAll('li').forEach(item => {
    item.addEventListener('dragstart', onDragStart);
    item.addEventListener('dragenter', onDragEnter);
    item.addEventListener('dragleave', onDragLeave);
    item.addEventListener('dragover', onDragOver);
    item.addEventListener('dragdrop', onDragDrop);
    item.addEventListener('dragend', onDragEnd);
});
// });