var fs = require('fs');
var input = fs.readFileSync('input.txt', 'utf8').toString();
var spl = input.trim();
var array = spl.split("\n");
 
// Initial object with values
var items = {
    Item1: '30',
    Item2: '40',
    Item3: '50'
};
 
// Create a new object
var itemManager = new Object();
 
// Method to add an item
itemManager.addItem = function(id, cost) {
    items[id] = cost;
};
 
// Method to remove an item
itemManager.removeItem = function(id) {
    delete items[id];
};
 
// Add the new item
itemManager.addItem(array[0], array[1]);
 
// Remove the specified item
itemManager.removeItem(array[2]);
 
// Print the final object
console.log(items);