var fs = require('fs');
var input = fs.readFileSync('input.txt').toString();
 
var number = parseInt(input.trim(),10)
 
const numberChecker = new Object();
 
// Define the method to check if the number is even or odd
numberChecker.evenOrOdd = function(number) {
    if (number % 2 === 0) {
        console.log("Even");
    } else {
        console.log("Odd");
    }
};
 
 
numberChecker.evenOrOdd(number)