//fill your code
function showGamePage() {
    document.getElementById('instruction').style.display = "none";
    document.getElementById('gamePage').style.display = "block";
 
    var typedWord = "";
    document.onkeydown = function(event) {
        var key = event.keyCode;
        var letter = String.fromCharCode(key).toUpperCase();
        typedWord += letter;
        document.getElementById('typedWord').innerHTML = typedWord;
    };
}
 