//fill your code
const accountDetails = {
    row1 : {
        name : "John",
        accountNumber : "8456844568845",
        balance : "123.46"
    },
    row2 : {
        name : "William",
        accountNumber : "8453333568845",
        balance : "223.46"
    },
    row3 : {
        name : "James",
        accountNumber : "8456882214345",
        balance : "123.46"
    },
    row4 : {
        name : "Jack",
        accountNumber : "4554589568845",
        balance : "13.46"
    },
 
};
 
 
function hoverRow1(){
    const row = document.getElementById("row1");
    row.innerHTML = `Acc Number : ${accountDetails.row1.accountNumber}<br>Balance: ${accountDetails.row1.balance}`; 
}
 
function removeHover1(){
    document.getElementById("row1").textContent = accountDetails.row1.name;
}
 
 
function hoverRow2(){
    const row = document.getElementById("row2");
    row.innerHTML = `Acc Number : ${accountDetails.row2.accountNumber}<br>Balance: ${accountDetails.row2.balance}`; 
}
 
function removeHover2(){
    document.getElementById("row2").textContent = accountDetails.row2.name;
}
 
 
function hoverRow3(){
    const row = document.getElementById("row3");
    row.innerHTML = `Acc Number : ${accountDetails.row3.accountNumber}<br>Balance: ${accountDetails.row3.balance}`; 
}
 
function removeHover3(){
    document.getElementById("row3").textContent = accountDetails.row3.name;
}
 
 
function hoverRow4(){
    const row = document.getElementById("row4");
    row.innerHTML = `Acc Number : ${accountDetails.row4.accountNumber}<br>Balance: ${accountDetails.row4.balance}`; 
}
 
function removeHover4(){
    document.getElementById("row4").textContent = accountDetails.row4.name;
}
 