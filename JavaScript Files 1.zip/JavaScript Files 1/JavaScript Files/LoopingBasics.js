var fs = require('fs');

// Read the input from 'input.txt'
var input = fs.readFileSync("input.txt").toString().trim();

// Convert the input to a number
var n = parseInt(input);

// Loop through numbers from 1 to n-1
for (var i = 1; i < n; i++) {
    // Check if the number is even
    if (i % 2 === 0) {
        console.log(i);
    }
}
