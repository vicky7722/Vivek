let Student={
    name:"priya",
    age:22,
    roll:1654,
    //array in an object
    subjects : ["Maths","English"],
    //methos inside an object
    hello:function()
    {
        console.log("Hello!!!");
    }
};
console.log(Student.name)
console.log(Student.hello())
let dt = new Date(); //Date is a native Object
console.log(dt.getFullYear());

console(console.log(document.title));