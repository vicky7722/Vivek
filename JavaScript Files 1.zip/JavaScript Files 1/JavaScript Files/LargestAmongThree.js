
//fill your code
var fs = require('fs');
var input = fs.readFileSync('input.txt', 'utf8').toString();
var spl = input.trim();
var array = spl.split("\n").map(Number);
 
// Create a new object
var numberChecker = new Object();
 
// Add the findLargest method to the object
numberChecker.findLargest = function(numbers) {
    return Math.max(...numbers);
};
 
// Find the largest number and print the result
console.log(numberChecker.findLargest(array));
 