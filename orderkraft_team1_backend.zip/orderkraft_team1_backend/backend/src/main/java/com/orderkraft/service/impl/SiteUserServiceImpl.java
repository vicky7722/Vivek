package com.orderkraft.service.impl;

import com.orderkraft.model.SiteUser;
import com.orderkraft.repository.SiteUserRepository;
import com.orderkraft.service.EmailService;
import com.orderkraft.service.PasswordPolicyValidator;
import com.orderkraft.service.SiteUserService;
import com.orderkraft.security.JwtService;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

import jakarta.transaction.Transactional;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.time.Instant;
import java.util.*;

@Service
@Transactional
public class SiteUserServiceImpl implements SiteUserService {

    private final SiteUserRepository repo;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;
    private final PasswordPolicyValidator passwordPolicyValidator;
    private final JwtService jwtService;

    @Value("${file.storage.base-dir}")
    private String uploadDir;

    @Value("${auth.lockout.threshold:5}")
    private int lockoutThreshold;

    @Value("${auth.lockout.duration-ms:3600000}")
    private long lockDurationMs;

    public SiteUserServiceImpl(
            SiteUserRepository repo,
            PasswordEncoder passwordEncoder,
            EmailService emailService,
            PasswordPolicyValidator passwordPolicyValidator,
            JwtService jwtService
    ) {
        this.repo = repo;
        this.passwordEncoder = passwordEncoder;
        this.emailService = emailService;
        this.passwordPolicyValidator = passwordPolicyValidator;
        this.jwtService = jwtService;
    }

    // ============================================================
    // CREATE USER
    // ============================================================
    @Override
    public SiteUser saveSiteUser(SiteUser u) {
        if (u.getEmailAddress() == null || u.getPassword() == null)
            throw new IllegalArgumentException("emailAddress and password required");

        if (repo.findByEmailAddress(u.getEmailAddress()).isPresent())
            throw new IllegalArgumentException("User already exists");

        passwordPolicyValidator.validateOrThrow(u.getPassword(), u);

        u.setPassword(passwordEncoder.encode(u.getPassword()));
        u.setStatus("Active");
        u.setFailedAttempts(0);
        u.setLockUntil(null);

        return repo.save(u);
    }

    @Override
    public List<SiteUser> getAllSiteUsers() {
        return repo.findAll();
    }

    @Override
    public Optional<SiteUser> getSiteUserById(Long id) {
        return repo.findById(id);
    }

    @Override
    public boolean changePassword(Long id, String current, String next) {
        SiteUser u = repo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("User not found"));

        if (!passwordEncoder.matches(current, u.getPassword()))
            return false;

        passwordPolicyValidator.validateOrThrow(next, u);

        u.setPassword(passwordEncoder.encode(next));
        repo.save(u);
        return true;
    }

    @Override
    public String deleteSiteUser(Long id) {
        if (!repo.existsById(id))
            throw new NoSuchElementException("User not found");

        repo.deleteById(id);
        return "User deleted";
    }

    @Override
    public Optional<SiteUser> findByEmail(String email) {
        return repo.findByEmailAddress(email);
    }

    // ============================================================
    // LOGIN (WITH LOCKOUT SUPPORT)
    // ============================================================
    @Override
    public ResponseEntity<?> login(String email, String password) {

        Optional<SiteUser> opt = repo.findByEmailAddress(email);
        if (opt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of(
                    "success", false,
                    "message", "Invalid email or password"
            ));
        }

        SiteUser user = opt.get();
        long now = Instant.now().toEpochMilli();
        String status = user.getStatus();

        if (status == null || !status.equalsIgnoreCase("Active")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of(
                "success", false,
                "message", "Your account is inactive. Please contact admin."
            ));
        }

        // locked?
        if (user.getLockUntil() != null && now < user.getLockUntil()) {
            return ResponseEntity.status(HttpStatus.LOCKED).body(Map.of(
                    "success", false,
                    "locked", true,
                    "message", "Account locked until: " + user.getLockUntil()
            ));
        }

        // incorrect password
        if (!passwordEncoder.matches(password, user.getPassword())) {

            repo.incrementFailedAttempts(email);

            SiteUser fresh = repo.findByEmailAddress(email).orElse(user);
            int failed = fresh.getFailedAttempts() == null ? 0 : fresh.getFailedAttempts();

            if (failed >= lockoutThreshold) {
                long until = now + lockDurationMs;
                repo.lockUser(email, until);

                return ResponseEntity.status(HttpStatus.LOCKED).body(Map.of(
                        "success", false,
                        "locked", true,
                        "message", "Account locked due to failed attempts"
                ));
            }

            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of(
                    "success", false,
                    "message", "Invalid email or password"
            ));
        }

        // success
        repo.resetFailedAttempts(email);

        if (user.getLockUntil() != null) {
            repo.unlockUser(email);
        }

        String role = user.getRole() == null ? "USER" : user.getRole().toUpperCase();

        String token = jwtService.generateToken(user.getEmailAddress(), role);
        long expUnix = jwtService.getExpirationSeconds();

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);
        headers.set("X-Session-Expires-At", String.valueOf(expUnix));
        headers.set("X-Session-Max-Age", String.valueOf(jwtService.getExpirationSeconds()));

        Map<String, Object> userData = new HashMap<>();

        String username = user.getUsername();

        if (username == null || username.isBlank()) {
            username = user.getEmailAddress().split("@")[0];
        }

        userData.put("id", user.getId());
        userData.put("emailAddress", user.getEmailAddress());
        userData.put("username", username);
        userData.put("role", user.getRole());
        userData.put("status", user.getStatus());

        return ResponseEntity.ok().headers(headers).body(Map.of(
                "success", true,
                "token", token,
                "user", userData
        ));
    }

    // ============================================================
    // PROFILE UPDATE
    // ============================================================
    @Override
    public SiteUser updateSiteUser(Long id, SiteUser updated) {

        SiteUser existing = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Update role safely
        if (updated.getRole() != null && !updated.getRole().isBlank()) {
            existing.setRole(updated.getRole());
        }

        // Update status safely
        if (updated.getStatus() != null && !updated.getStatus().isBlank()) {
            existing.setStatus(updated.getStatus());
        }

        return repo.save(existing);
    }

    @Override
    @Transactional
    public SiteUser updateProfile(Long id, String username, String phoneNumber, String avatarUrl) {

        SiteUser existing = repo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("User not found"));

        existing.setUsername(username);
        existing.setPhoneNumber(phoneNumber);

        if (avatarUrl != null) {
            existing.setAvatarUrl(avatarUrl);
        }

        // 🔥 FORCE FLUSH TO ORACLE
        repo.saveAndFlush(existing);

        return existing;
    }

    // ============================================================
    // PHOTO UPLOAD
    // ============================================================
    @Override
    public SiteUser savePhoto(Long userId, MultipartFile file) throws Exception {
        SiteUser u = repo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));

        if (file.isEmpty())
            throw new IllegalArgumentException("Empty file");

        String original = Optional.ofNullable(file.getOriginalFilename()).orElse("avatar-" + userId);
        String clean = original.replaceAll("[^a-zA-Z0-9._-]", "_");

        Path dir = Paths.get(uploadDir);
        Files.createDirectories(dir);

        Path target = dir.resolve(clean);
        Files.write(target, file.getBytes());

        u.setAvatarUrl("/uploads/" + clean);
        return repo.save(u);
    }

    // ============================================================
    // STATUS + UNLOCK
    // ============================================================
    @Override
    public void deactivateUser(String email) {
        repo.updateUserStatus(email, "Inactive");
    }

    @Override
    public void unlockUserByEmail(String email) {
        repo.unlockUser(email);
    }

    @Scheduled(fixedRateString = "${auth.lockout.auto-check-ms:60000}")
    @Override
    public void autoUnlockExpiredUsers() {
        long now = Instant.now().toEpochMilli();
        List<SiteUser> expired = repo.findExpiredLockedUsers(now);

        for (SiteUser u : expired) {
            repo.unlockUser(u.getEmailAddress());
        }
    }

    // ============================================================
    // RECAPTCHA (NOT USED)
    // ============================================================
    @Override
    public int getRecaptchaThreshold() {
        return 0;
    }
}
