package com.orderkraft.service;

import com.orderkraft.model.OrderLine;
import com.orderkraft.repository.OrderLineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderLineService {

    @Autowired
    private OrderLineRepository orderLineRepository;

    public OrderLine saveOrderLine(OrderLine orderLine) {
        return orderLineRepository.save(orderLine);
    }

    public List<OrderLine> getAllOrderLines() {
        return (List<OrderLine>) orderLineRepository.findAll();
    }

    public Optional<OrderLine> getOrderLineById(Long id) {
        return orderLineRepository.findById(id);
    }

    public OrderLine updateOrderLine(Long id, OrderLine updatedOrderLine) {
        Optional<OrderLine> optionalLine = orderLineRepository.findById(id);
        if (optionalLine.isPresent()) {
            OrderLine line = optionalLine.get();
            line.setProductItemId(updatedOrderLine.getProductItemId());
            line.setOrderId(updatedOrderLine.getOrderId());
            line.setQty(updatedOrderLine.getQty());
            line.setPrice(updatedOrderLine.getPrice());
            return orderLineRepository.save(line);// to save in order line repository
        }
        return null;
    }

    public String deleteOrderLine(Long id) {
        if (orderLineRepository.existsById(id)) {
            orderLineRepository.deleteById(id);
            return "Order Line deleted successfully.";
        }
        return "Order Line not found.";
    }
}