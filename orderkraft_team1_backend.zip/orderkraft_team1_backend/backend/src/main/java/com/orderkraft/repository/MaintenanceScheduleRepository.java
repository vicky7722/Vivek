package com.orderkraft.repository;

import com.orderkraft.model.MaintenanceSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface MaintenanceScheduleRepository extends JpaRepository<MaintenanceSchedule, Long> {

    // Existing
    List<MaintenanceSchedule> findByUnitId(Long unitId);
    
    boolean existsByUnitIdAndStatus(Long unitId, String status);

    // find maintenance windows for a unit that overlap given range
    List<MaintenanceSchedule> findByUnitIdAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
            Long unitId, LocalDateTime end, LocalDateTime start);

    // active maintenance at a moment
    List<MaintenanceSchedule> findByUnitIdAndStatusAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
            Long unitId, String status, LocalDateTime now1, LocalDateTime now2);

    // 🔹 New: All schedules with a specific status
    List<MaintenanceSchedule> findByStatus(String status);

    // 🔹 New: All schedules with given status whose end time is already past
    List<MaintenanceSchedule> findByStatusAndEndTimeBefore(String status, LocalDateTime before);

    // 🔹 New: All schedules with given status that should be active now (time window contains "now")
    List<MaintenanceSchedule> findByStatusAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
            String status, LocalDateTime now1, LocalDateTime now2);
}
