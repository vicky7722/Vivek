package com.orderkraft.service;

import com.orderkraft.model.Alert;
import com.orderkraft.repository.AlertRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AlertService {
    @Autowired
    private AlertRepository repo;

    public Alert createAlert(Long itemId, String sku, String message){
        Alert a = new Alert();
        a.setItemId(itemId);
        a.setSku(sku);
        a.setMessage(message);
        a.setCreatedAt(LocalDateTime.now());
        a.setResolved(false);
        return repo.save(a);
    }

    public List<Alert> getActiveAlerts(){ return repo.findByResolvedFalse(); }
    public List<Alert> getAll(){ return repo.findAll(); }
    public Alert resolve(Long id){
        return repo.findById(id).map(a -> { a.setResolved(true); return repo.save(a); }).orElse(null);
    }
}
