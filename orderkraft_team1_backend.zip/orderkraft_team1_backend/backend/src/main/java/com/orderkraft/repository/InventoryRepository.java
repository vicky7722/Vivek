package com.orderkraft.repository;

import com.orderkraft.model.InventoryItem;
import com.orderkraft.model.StockStatus; // Import the correct enum
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface InventoryRepository extends JpaRepository<InventoryItem, Long> {

    Optional<InventoryItem> findBySku(String sku);

    // Find all items that are NOT archived
    @Query("SELECT i FROM InventoryItem i WHERE i.status != com.orderkraft.model.StockStatus.ARCHIVED")
    List<InventoryItem> findAllActive();

    // Find low stock items that are NOT archived
    @Query("""
            select i from InventoryItem i
            where (i.quantity = 0
               or (i.reorderLevel is not null and i.quantity <= i.reorderLevel))
            and i.status != com.orderkraft.model.StockStatus.ARCHIVED
            """)
    List<InventoryItem> findLowStockActive();

    // Sum quantities of items that are NOT archived
    @Query("select coalesce(sum(i.quantity),0) from InventoryItem i WHERE i.status != com.orderkraft.model.StockStatus.ARCHIVED")
    Long sumQuantitiesActive();

    List<InventoryItem> findAllByStatus(StockStatus status);
}