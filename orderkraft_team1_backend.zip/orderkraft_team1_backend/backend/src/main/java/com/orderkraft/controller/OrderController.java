package com.orderkraft.controller;

import com.orderkraft.model.Order;
import com.orderkraft.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "http://localhost:4200")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // ➕ Add order
    @PostMapping("/add")
    public Order createOrder(@RequestBody Order order) {
        return orderService.createOrder(order);
    }

    // ✅ DEFAULT PAGINATED ENDPOINT (USED BY FRONTEND)
    // GET /api/orders?page=0&size=20
    @GetMapping
    public Page<Order> getOrders(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size
    ) {
        Pageable pageable =
                PageRequest.of(page, size, Sort.by("createdAt").descending());

        // No search here – plain paginated fetch
        return orderService.getOrdersPaginated(null, pageable);
    }

    // 📄 Paginated + Search Orders (advanced usage)
    // GET /api/orders/paged?page=0&size=10&search=abc
    @GetMapping("/paged")
    public Page<Order> getOrdersPaged(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String search
    ) {
        Pageable pageable =
                PageRequest.of(page, size, Sort.by("createdAt").descending());

        return orderService.getOrdersPaginated(search, pageable);
    }

    // 📜 All orders (legacy – keep for now)
    @GetMapping("/getAll")
    public List<Order> getAllOrders() {
        return orderService.getAllOrders();
    }

    // 🔍 Filter by status
    @GetMapping("/status/{status}")
    public List<Order> getOrdersByStatus(@PathVariable String status) {
        return orderService.getOrdersByStatus(status);
    }

    // 🔍 Get by ID
    @GetMapping("/{id}")
    public Order getOrderById(@PathVariable Long id) {
        return orderService.getOrderById(id).orElse(null);
    }

    // ✏️ Update order
    @PutMapping("/{id}")
    public Order updateOrder(@PathVariable Long id, @RequestBody Order order) {
        return orderService.updateOrder(id, order);
    }

    // ❌ Delete order
    @DeleteMapping("/{id}")
    public String deleteOrder(@PathVariable Long id) {
        return orderService.deleteOrder(id);
    }
}
