package com.orderkraft.model;

import jakarta.persistence.*;

@Entity
@Table(name = "user_review")
public class UserReview {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_review_seq_gen")
    @SequenceGenerator(name = "user_review_seq_gen", sequenceName = "user_review_seq", allocationSize = 1)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "ordered_product_id")
    private Long orderedProductId;

    @Column(name = "rating_value")
    private Integer ratingValue;

    @Column(name = "comments", columnDefinition="CLOB")
    private String comment;
    
    // Constructors
    public UserReview() {
        super();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getOrderedProductId() { return orderedProductId; }
    public void setOrderedProductId(Long orderedProductId) { this.orderedProductId = orderedProductId; }
    public Integer getRatingValue() { return ratingValue; }
    public void setRatingValue(Integer ratingValue) { this.ratingValue = ratingValue; }
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
}