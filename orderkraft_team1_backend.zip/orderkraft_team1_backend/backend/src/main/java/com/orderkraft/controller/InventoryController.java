package com.orderkraft.controller;

import com.orderkraft.dto.ReturnItemDTO;

import com.orderkraft.dto.ReturnItemResponseDTO;
import com.orderkraft.model.InventoryItem;
import com.orderkraft.model.ReturnItem;
import com.orderkraft.service.InventoryService;
import com.orderkraft.service.ReturnItemService;
import com.orderkraft.service.StockMovementService;
import com.orderkraft.model.StockMovement; // Keep this import
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/inventory")
@CrossOrigin(origins = "http://localhost:4200", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    // ✅ ADDED: Inject the new services
    @Autowired
    private ReturnItemService returnItemService;

    @Autowired
    private StockMovementService stockMovementService; // This is still needed for other controllers


    // Get all items
    @GetMapping("/getAll")
    public ResponseEntity<List<InventoryItem>> getAllItems() {
        System.out.println(">>> [InventoryController] GET /getAll called");
        try {
            List<InventoryItem> items = inventoryService.getAllItems();
            System.out.println("<<< [InventoryController] GET /getAll returning " + items.size() + " items.");
            return ResponseEntity.ok(items);
        } catch (Exception e) {
            System.err.println("!!! [InventoryController] ERROR in GET /getAll: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Get item by ID
    @GetMapping("/{id}")
    public ResponseEntity<InventoryItem> getItemById(@PathVariable Long id) {
        System.out.println(">>> [InventoryController] GET /" + id + " called");
        try {
            return inventoryService.getItem(id)
                    .map(item -> {
                        System.out.println("<<< [InventoryController] GET /" + id + " found item.");
                        return ResponseEntity.ok(item);
                    })
                    .orElseGet(() -> {
                        System.out.println("<<< [InventoryController] GET /" + id + " item NOT FOUND.");
                        return ResponseEntity.notFound().build();
                    });
        } catch (Exception e) {
            System.err.println("!!! [InventoryController] ERROR in GET /" + id + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Add new item (for single item)
    @PostMapping("/add")
    public ResponseEntity<InventoryItem> addItem(@RequestBody InventoryItem item) {

        InventoryItem savedItem = inventoryService.addItem(item);

        // ✅ record movement OUTSIDE transaction
        try {
            stockMovementService.recordMovement(
                savedItem,
                savedItem.getQuantity(),
                "ADD",
                "New item created",
                "AdminUser"
            );
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(savedItem);
    }


    /**
     * Adds a list of new inventory items in bulk.
     * This endpoint accepts a JSON array of items.
     */
    @PostMapping("/add-all")
    public ResponseEntity<List<InventoryItem>> addAllItems(@RequestBody List<InventoryItem> items) {
        System.out.println(">>> [InventoryController] POST /add-all called with " + items.size() + " items.");
        try {
            List<InventoryItem> savedItems = inventoryService.saveAll(items);
            System.out.println("<<< [InventoryController] POST /add-all completed.");
            return ResponseEntity.status(HttpStatus.CREATED).body(savedItems);
        } catch (Exception e) {
            System.err.println("!!! [InventoryController] ERROR in POST /add-all: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }


    // Update existing item
    @PutMapping("/update/{id}")
    public ResponseEntity<InventoryItem> updateItem(@PathVariable Long id, @RequestBody InventoryItem itemDetails) {
        System.out.println(">>> [InventoryController] PUT /update/" + id + " called with item: " + itemDetails.getName());
        try {
            InventoryItem updatedItem = inventoryService.updateItem(id, itemDetails);
            System.out.println("<<< [InventoryController] PUT /update/" + id + " completed.");
            return ResponseEntity.ok(updatedItem);
        } catch (NoSuchElementException e) {
            System.out.println("<<< [InventoryController] PUT /update/" + id + " item NOT FOUND.");
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            System.err.println("!!! [InventoryController] ERROR in PUT /update/" + id + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Delete item (archives it)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable Long id) {
        System.out.println(">>> [InventoryController] DELETE /" + id + " called.");
        try {
            inventoryService.deleteItem(id);
            System.out.println("<<< [InventoryController] DELETE /" + id + " completed (item archived).");
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            System.err.println("!!! [InventoryController] ERROR in DELETE /" + id + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Summary endpoint
    @GetMapping("/summary")
    public ResponseEntity<Map<String, Object>> getSummary() {
        System.out.println(">>> [InventoryController] GET /summary called.");
        try {
            Map<String, Object> summary = inventoryService.stockSummary();
            System.out.println("<<< [InventoryController] GET /summary returning summary data.");
            return ResponseEntity.ok(summary);
        } catch (Exception e) {
            System.err.println("!!! [InventoryController] ERROR in GET /summary: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // =================================================================
    // ✅✅✅ NEW ENDPOINTS FOR RETURNS & MOVEMENTS ✅✅✅
    // =================================================================

    /**
     * Creates a new return record.
     * This is called by the frontend AFTER updating the item's stock.
     */
    @PostMapping("/returns")
    public ResponseEntity<ReturnItemResponseDTO> createReturn(@RequestBody ReturnItemDTO returnDTO) {
        System.out.println(">>> [InventoryController] POST /returns called for item ID: " + returnDTO.getItemId());
        try {
            ReturnItem savedReturn = returnItemService.createReturn(returnDTO);
            // We return a DTO to avoid potential JSON infinite loops
            ReturnItemResponseDTO responseDTO = new ReturnItemResponseDTO(savedReturn);
            System.out.println("<<< [InventoryController] POST /returns saved new return with ID: " + savedReturn.getId());
            return ResponseEntity.status(HttpStatus.CREATED).body(responseDTO);
        } catch (Exception e) {
            System.err.println("!!! [InventoryController] ERROR in POST /returns: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    /**
     * Gets all return records, sorted by most recent first.
     */
    @GetMapping("/returns")
    public ResponseEntity<List<ReturnItemResponseDTO>> getAllReturns() {
        System.out.println(">>> [InventoryController] GET /returns called.");
        try {
            List<ReturnItem> returns = returnItemService.getAllReturns();
            // Convert to DTOs for a clean API response
            List<ReturnItemResponseDTO> dtos = returns.stream()
                    .map(ReturnItemResponseDTO::new)
                    .collect(Collectors.toList());
            System.out.println("<<< [InventoryController] GET /returns returning " + dtos.size() + " items.");
            return ResponseEntity.ok(dtos);
        } catch (Exception e) {
            System.err.println("!!! [InventoryController] ERROR in GET /returns: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    //
    // ✅✅✅ The duplicate /movements endpoints have been removed ✅✅✅
    //
}