package com.orderkraft.controller;

import com.orderkraft.model.PurchaseOrder;
import com.orderkraft.service.PurchaseOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/suppliers")
@CrossOrigin(origins = "http://localhost:4200")
public class SupplierPOController {

    @Autowired private PurchaseOrderService poService;

    @GetMapping("/{id}/po-history")
    public List<PurchaseOrder> getPoHistory(@PathVariable Long id) {
        return poService.getPoHistoryForSupplier(id);
    }

    // Create PO
    @PostMapping("/{id}/po")
    public ResponseEntity<PurchaseOrder> createPo(@PathVariable Long id, @RequestBody PurchaseOrder payload) {
        payload.setSupplierId(id);
        if (payload.getCreatedDate() == null) {
            payload.setCreatedDate(java.time.LocalDate.now());
        }
        PurchaseOrder saved = poService.savePo(payload);
        return ResponseEntity.created(URI.create("/api/suppliers/" + id + "/po/" + saved.getId())).body(saved);
    }

    // Get single PO (optional)
    @GetMapping("/{id}/po/{poId}")
    public ResponseEntity<PurchaseOrder> getPo(@PathVariable Long id, @PathVariable Long poId) {
        return poService.getById(poId)
                .map(po -> ResponseEntity.ok(po))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Mark PO as paid
    @PutMapping("/{id}/po/{poId}/pay")
    public ResponseEntity<PurchaseOrder> payPo(@PathVariable Long id, @PathVariable Long poId) {
        PurchaseOrder updated = poService.markPaid(poId);
        return ResponseEntity.ok(updated);
    }

    // Cancel PO
    @PutMapping("/{id}/po/{poId}/cancel")
    public ResponseEntity<PurchaseOrder> cancelPo(
            @PathVariable Long id,
            @PathVariable Long poId,
            @RequestBody Map<String, String> body
    ) {
        String reason = body.getOrDefault("reason", "Cancelled by user");
        PurchaseOrder updated = poService.cancelPo(poId, reason);
        return ResponseEntity.ok(updated);
    }

    // Return PO
    @PutMapping("/{id}/po/{poId}/return")
    public ResponseEntity<PurchaseOrder> returnPo(
            @PathVariable Long id,
            @PathVariable Long poId,
            @RequestBody Map<String, Object> body
    ) {
        Integer quantity = (body.get("quantity") == null) ? 0 : (Integer) body.get("quantity");
        String reason = (body.get("reason") == null) ? "Return" : (String) body.get("reason");
        PurchaseOrder updated = poService.returnPo(poId, quantity, reason);
        return ResponseEntity.ok(updated);
    }

    // Advance tracking
    @PutMapping("/{id}/po/{poId}/track")
    public ResponseEntity<PurchaseOrder> trackPo(@PathVariable Long id, @PathVariable Long poId) {
        PurchaseOrder updated = poService.advanceTracking(poId);
        return ResponseEntity.ok(updated);
    }
}
