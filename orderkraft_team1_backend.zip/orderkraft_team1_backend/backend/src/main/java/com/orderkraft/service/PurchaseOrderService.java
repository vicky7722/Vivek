package com.orderkraft.service;

import com.orderkraft.model.PurchaseOrder;
import com.orderkraft.repository.PurchaseOrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class PurchaseOrderService {

    @Autowired private PurchaseOrderRepository poRepo;
    @Autowired private SupplierAuditService auditService;

    public List<PurchaseOrder> getPoHistoryForSupplier(Long supplierId) {
        return poRepo.findBySupplierIdOrderByCreatedDateDesc(supplierId);
    }

    public PurchaseOrder savePo(PurchaseOrder p) {
        // compute amount if not provided and unitPrice/quantity provided
        if ((p.getAmount() == null || p.getAmount().compareTo(BigDecimal.ZERO) == 0)
                && p.getUnitPrice() != null && p.getQuantity() != null) {
            p.setAmount(p.getUnitPrice().multiply(BigDecimal.valueOf(p.getQuantity())));
        }

        // default values
        if (p.getCreatedDate() == null) p.setCreatedDate(LocalDate.now());
        if (p.getStatus() == null) p.setStatus("PENDING");
        if (p.getPaymentStatus() == null) p.setPaymentStatus("PENDING");

        PurchaseOrder saved = poRepo.save(p);
        try { auditService.log(saved.getSupplierId(), "PO_CREATED", "PO created: " + saved.getId()); } catch(Exception e){}
        return saved;
    }

    public Optional<PurchaseOrder> getById(Long id) {
        return poRepo.findById(id);
    }

    // mark as paid
    public PurchaseOrder markPaid(Long poId) {
        PurchaseOrder po = poRepo.findById(poId).orElseThrow();
        po.setPaymentStatus("PAID");
        po.setStatus("PAID");
        po.setProcessedAt(LocalDate.now());
        PurchaseOrder saved = poRepo.save(po);
        try { auditService.log(saved.getSupplierId(), "PO_PAID", "PO paid: " + saved.getId()); } catch(Exception e){}
        return saved;
    }

    // cancel PO with reason
    public PurchaseOrder cancelPo(Long poId, String reason) {
        PurchaseOrder po = poRepo.findById(poId).orElseThrow();
        po.setStatus("CANCELLED");
        po.setCancelReason(reason);
        po.setCancelledDate(LocalDate.now());
        PurchaseOrder saved = poRepo.save(po);
        try { auditService.log(saved.getSupplierId(), "PO_CANCELLED", "PO cancelled: " + saved.getId() + " reason: " + reason); } catch(Exception e){}
        return saved;
    }

    // return PO
    public PurchaseOrder returnPo(Long poId, Integer quantity, String reason) {
        PurchaseOrder po = poRepo.findById(poId).orElseThrow();
        po.setStatus("RETURNED");
        po.setReturnQuantity(quantity);
        po.setReturnReason(reason);
        po.setReturnDate(LocalDate.now());
        PurchaseOrder saved = poRepo.save(po);
        try { auditService.log(saved.getSupplierId(), "PO_RETURNED", "PO returned: " + saved.getId() + " qty: " + quantity); } catch(Exception e){}
        return saved;
    }

    // advance tracking: PAID -> DISPATCHED -> DELIVERED -> COMPLETED
    public PurchaseOrder advanceTracking(Long poId) {
        PurchaseOrder po = poRepo.findById(poId).orElseThrow();
        String s = po.getStatus() == null ? "PENDING" : po.getStatus();

        switch (s) {
            case "PAID":
            case "PENDING":
                po.setStatus("DISPATCHED");
                po.setDispatchedDate(LocalDate.now());
                break;
            case "DISPATCHED":
                po.setStatus("DELIVERED");
                po.setDeliveredDate(LocalDate.now());
                break;
            case "DELIVERED":
                po.setStatus("COMPLETED");
                break;
            default:
                // no-op if CANCELLED/RETURNED/COMPLETED
                break;
        }
        PurchaseOrder saved = poRepo.save(po);
        try { auditService.log(saved.getSupplierId(), "PO_TRACK", "PO status advanced to: " + saved.getStatus() + " for PO: " + saved.getId()); } catch(Exception e){}
        return saved;
    }
}
