package com.orderkraft.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class MaintenanceSyncService {

    @Autowired
    private ProductionUnitService unitService;

    @Scheduled(fixedRate = 60000)
    public void syncMaintenanceUnits() {

        unitService.syncMaintenanceUnits();

    }
}