package com.orderkraft.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "production_task")
public class ProductionTask {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "task_seq_gen")
    @SequenceGenerator(name = "task_seq_gen", sequenceName = "task_seq", allocationSize = 1)
    private Long id;

    private String taskName;
//    private String taskType; // PRODUCTION / PACKAGING / SHIPPING
    private LocalDate deadline;
    private Integer progress;
    private String status;

    // NEW: priority and simple dependency
    private String priority; // HIGH / MEDIUM / LOW

    @Column(name = "depends_on_task_id")
    private Long dependsOnTaskId;

    @ManyToOne
    @JoinColumn(name = "schedule_id")
    private ProductionSchedule schedule;

    @ManyToOne
    @JoinColumn(name = "assigned_machine_id")
    private ProductionUnit unit;

    // NEW: assign worker
    @ManyToOne
    @JoinColumn(name = "assigned_worker_id")
    private Worker assignedWorker;

    // -----------------------------
    // Constructors
    // -----------------------------
    public ProductionTask() {}

    public ProductionTask(Long id) { this.id = id; }

    // -----------------------------
    // Getters / Setters
    // -----------------------------
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTaskName() { return taskName; }
    public void setTaskName(String taskName) { this.taskName = taskName; }
    
//    public String getTaskType() {
//        return taskType;
//    }
//
//    public void setTaskType(String taskType) {
//        this.taskType = taskType;
//    }

    public LocalDate getDeadline() { return deadline; }
    public void setDeadline(LocalDate deadline) { this.deadline = deadline; }

    public Integer getProgress() { return progress; }
    public void setProgress(Integer progress) { this.progress = progress; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    public Long getDependsOnTaskId() { return dependsOnTaskId; }
    public void setDependsOnTaskId(Long dependsOnTaskId) { this.dependsOnTaskId = dependsOnTaskId; }

    public ProductionSchedule getSchedule() { return schedule; }
    public void setSchedule(ProductionSchedule schedule) { this.schedule = schedule; }

    public ProductionUnit getUnit() { return unit; }
    public void setUnit(ProductionUnit unit) { this.unit = unit; }

    public Worker getAssignedWorker() { return assignedWorker; }
    public void setAssignedWorker(Worker assignedWorker) { this.assignedWorker = assignedWorker; }
}
