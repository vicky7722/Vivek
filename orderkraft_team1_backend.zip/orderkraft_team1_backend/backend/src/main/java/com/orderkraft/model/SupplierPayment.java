package com.orderkraft.model;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "supplier_payment")
public class SupplierPayment {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sup_payment_seq")
    @SequenceGenerator(name = "sup_payment_seq", sequenceName = "sup_payment_seq", allocationSize = 1)
    private Long id;

    @Column(name="supplier_id")
    private Long supplierId;

    @Column(name="order_id")
    private Long orderId;

    @Column(name="invoice_no")
    private String invoiceNo;

    private BigDecimal amount;

    private String status; // PENDING/PAID/FAILED

    @Column(name="payment_date")
    private LocalDate paymentDate;

    // getters / setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getSupplierId() { return supplierId; }
    public void setSupplierId(Long supplierId) { this.supplierId = supplierId; }

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public String getInvoiceNo() { return invoiceNo; }
    public void setInvoiceNo(String invoiceNo) { this.invoiceNo = invoiceNo; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }
}
