package com.orderkraft.service; // Or whatever your main package is, e.g., com.orderkraft.config

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * This method sets up a global CORS policy for the entire application,
     * allowing your frontend to the make requests.
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // Apply to ALL paths
                .allowedOrigins("http://localhost:4200") // Your Angular app's URL
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }

    /**
     * This method tells Spring Boot to the serve files from your 'uploads' directory
     * when a request comes in for "/uploads/**".
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // This maps the URL path "/uploads/**"
        registry.addResourceHandler("/uploads/**")
                // This maps it to the physical directory "file:uploads/"
                // The "file:" prefix is crucial. "uploads/" is relative to your project root.
                .addResourceLocations("file:uploads/");
    }
}