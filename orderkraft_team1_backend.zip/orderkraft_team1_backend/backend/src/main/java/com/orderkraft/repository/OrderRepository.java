package com.orderkraft.repository;

import com.orderkraft.model.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByStatus(String status);

    // 🔍 Search by supplier OR item with pagination
    Page<Order> findBySupplierContainingIgnoreCaseOrItemContainingIgnoreCase(
            String supplier, String item, Pageable pageable
    );
}
