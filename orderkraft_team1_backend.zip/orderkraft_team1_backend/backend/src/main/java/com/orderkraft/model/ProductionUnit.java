package com.orderkraft.model;

import jakarta.persistence.*;

@Entity
@Table(name = "production_unit")
public class ProductionUnit {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "unit_seq_gen")
    @SequenceGenerator(name = "unit_seq_gen", sequenceName = "unit_seq", allocationSize = 1)
    private Long id;

    @Column(nullable = false)
    private String unitName;

    // MACHINE / WORKER / GENERAL (you already use this)
//    @Column(name = "unit_type")
//    private String unitType;

    /**
     * NEW:
     * Logical department this unit belongs to.
     * Examples: "PRODUCTION", "PACKAGING", "SHIPPING"
     */
    @Column(name = "department")
    private String department;
    
//    @ManyToOne
//    @JoinColumn(name = "department_id")
//    private Department department;

    // Max allowed active tasks OR worker capacity
    private Integer capacity;

    // AVAILABLE / BUSY / MAINTENANCE
    @Column(name = "availability_status")
    private String availabilityStatus = "AVAILABLE";

    @Column(name = "current_load")
    private Integer currentLoad = 0;

    @Version
    @Column(name = "version")
    private Long version;

    // -----------------------------
    // Constructors
    // -----------------------------

    public ProductionUnit() {}

    public ProductionUnit(Long id) {
        this.id = id;
    }

    public ProductionUnit(Long id,
                          String unitName,
                          Integer capacity,
                          String availabilityStatus,
                          Integer currentLoad,
                          String unitType,
                          Long version,
                          String department) {

        this.id = id;
        this.unitName = unitName;
        this.capacity = capacity;
        this.availabilityStatus = availabilityStatus;
        this.currentLoad = currentLoad;
//        this.unitType = unitType;
        this.version = version;
        this.department = department;
    }

    // -----------------------------
    // Getters / Setters
    // -----------------------------

    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getUnitName() { return unitName; }

    public void setUnitName(String unitName) { this.unitName = unitName; }

    public Integer getCapacity() { return capacity; }

    public void setCapacity(Integer capacity) { this.capacity = capacity; }

    public String getAvailabilityStatus() { return availabilityStatus; }

    public void setAvailabilityStatus(String availabilityStatus) {
        this.availabilityStatus = availabilityStatus;
    }

    public Integer getCurrentLoad() {
        return currentLoad == null ? 0 : currentLoad;
    }

    public void setCurrentLoad(Integer currentLoad) {
        this.currentLoad = currentLoad == null ? 0 : currentLoad;
    }

//    public String getUnitType() { return unitType; }
//
//    public void setUnitType(String unitType) { this.unitType = unitType; }

    public Long getVersion() { return version; }

    public void setVersion(Long version) { this.version = version; }

    public String getDepartment() { return department; }

    public void setDepartment(String department) { this.department = department; }

    // -----------------------------
    // Helper logic (already had)
    // -----------------------------

    @Transient
    public boolean isFull() {
        if (capacity == null) return false;
        return getCurrentLoad() >= capacity;
    }

    @Transient
    public boolean isBusy() {
        return "BUSY".equalsIgnoreCase(availabilityStatus);
    }

    @Transient
    public boolean canAcceptTask() {
        return !isBusy() && !isFull();
    }
}
