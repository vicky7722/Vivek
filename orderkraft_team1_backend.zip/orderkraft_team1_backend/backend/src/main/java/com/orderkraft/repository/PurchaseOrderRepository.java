package com.orderkraft.repository;

import com.orderkraft.model.PurchaseOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder, Long> {
    List<PurchaseOrder> findBySupplierIdOrderByCreatedDateDesc(Long supplierId);
}
