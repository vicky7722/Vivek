package com.orderkraft.model;

import jakarta.persistence.*;

@Entity
@Table(name = "workers")
public class Worker {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "worker_seq_gen")
    @SequenceGenerator(name = "worker_seq_gen", sequenceName = "worker_seq", allocationSize = 1)
    private Long id;

    private String name;

    // AVAILABLE / BUSY / OFF
    private String availabilityStatus = "AVAILABLE";

    /**
     * Department this worker belongs to.
     * Examples: "PRODUCTION", "PACKAGING", "SHIPPING"
     */
    @Column(name = "department")
    private String department;

    /**
     * NEW:
     * Each worker can be linked to exactly one primary machine
     * (ProductionUnit with UNIT_TYPE = 'MACHINE').
     * This is the machine they usually operate.
     */
    @ManyToOne
    @JoinColumn(name = "assigned_machine_id")
    private ProductionUnit assignedMachine;

    public Worker() {}

    public Worker(Long id) {
        this.id = id;
    }

    // ---------- Getters & Setters ----------

    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getAvailabilityStatus() { return availabilityStatus; }

    public void setAvailabilityStatus(String availabilityStatus) {
        this.availabilityStatus = availabilityStatus;
    }

    public String getDepartment() { return department; }

    public void setDepartment(String department) { this.department = department; }

    public ProductionUnit getAssignedMachine() { return assignedMachine; }

    public void setAssignedMachine(ProductionUnit assignedMachine) {
        this.assignedMachine = assignedMachine;
    }

    @Transient
    public boolean isAvailable() {
        return "AVAILABLE".equalsIgnoreCase(availabilityStatus);
    }
}
