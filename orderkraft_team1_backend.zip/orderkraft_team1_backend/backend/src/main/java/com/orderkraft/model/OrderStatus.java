package com.orderkraft.model;

import jakarta.persistence.*;

@Entity
@Table(name = "order_status")
public class OrderStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_status_seq_gen")
    @SequenceGenerator(name = "order_status_seq_gen", sequenceName = "order_status_seq", allocationSize = 1)
    private Long id;

    @Column(name = "status")
    private String status;

    // Constructors
    public OrderStatus() {
        super();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}