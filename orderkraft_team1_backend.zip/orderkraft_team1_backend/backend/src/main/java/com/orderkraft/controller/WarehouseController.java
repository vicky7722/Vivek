package com.orderkraft.controller;

import com.orderkraft.model.Warehouse;
import com.orderkraft.model.WarehouseStock;
import com.orderkraft.service.WarehouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/warehouses")
@CrossOrigin(origins = "http://localhost:4200")
public class WarehouseController {
    @Autowired private WarehouseService service;

    @PostMapping("/add")
    public Warehouse add(@RequestBody Warehouse w){ return service.create(w); }

    @GetMapping("/getAll")
    public List<Warehouse> getAll(){ return service.getAll(); }

    @GetMapping("/{id}/stock")
    public List<WarehouseStock> getStock(@PathVariable Long id){ return service.getStockForWarehouse(id); }

    @PostMapping("/transfer")
    public ResponseEntity<?> transfer(@RequestParam Long fromWarehouse, @RequestParam Long toWarehouse, @RequestParam Long itemId, @RequestParam int qty){
        WarehouseStock res = service.transfer(fromWarehouse, toWarehouse, itemId, qty);
        if(res == null) return ResponseEntity.badRequest().body("Insufficient stock or invalid warehouses");
        return ResponseEntity.ok(res);
    }

    @PostMapping("/{warehouseId}/adjust")
    public ResponseEntity<?> adjust(@PathVariable Long warehouseId, @RequestParam Long itemId, @RequestParam int delta){
        WarehouseStock res = service.adjustStock(warehouseId, itemId, delta);
        return ResponseEntity.ok(res);
    }
}
