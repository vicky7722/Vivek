package com.orderkraft.repository;

import com.orderkraft.model.Item;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemRepository extends JpaRepository<Item, Long> {
    List<Item> findBySupplierId(Long supplierId);
}
