package com.orderkraft.model;

import jakarta.persistence.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "warehouse_transfer")
public class WarehouseTransfer {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "warehouse_transfer_seq")
    @SequenceGenerator(name = "warehouse_transfer_seq", sequenceName = "warehouse_transfer_seq", allocationSize = 1)
    private Long id;

    @Column(nullable = false)
    private Long fromWarehouseId;

    @Column(nullable = false)
    private Long toWarehouseId;

    @Column(nullable = false)
    private Long productId;

    @Column(nullable = false)
    private Integer quantity;

    private Long performedByUserId;

    @Column(nullable = false)
    private OffsetDateTime createdAt = OffsetDateTime.now();

    public WarehouseTransfer() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getFromWarehouseId() { return fromWarehouseId; }
    public void setFromWarehouseId(Long fromWarehouseId) { this.fromWarehouseId = fromWarehouseId; }

    public Long getToWarehouseId() { return toWarehouseId; }
    public void setToWarehouseId(Long toWarehouseId) { this.toWarehouseId = toWarehouseId; }

    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public Long getPerformedByUserId() { return performedByUserId; }
    public void setPerformedByUserId(Long performedByUserId) { this.performedByUserId = performedByUserId; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }
}
