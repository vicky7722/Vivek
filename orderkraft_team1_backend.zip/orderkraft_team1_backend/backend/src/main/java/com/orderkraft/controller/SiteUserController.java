package com.orderkraft.controller;

import com.orderkraft.dto.LoginRequest;
import com.orderkraft.dto.PasswordChangeRequest;
import com.orderkraft.dto.ProfileUpdateRequest;
import com.orderkraft.model.PasswordResetToken;
import com.orderkraft.model.SiteUser;
import com.orderkraft.security.JwtService;
import com.orderkraft.service.PasswordResetService;
import com.orderkraft.service.SiteUserService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/siteusers")
@CrossOrigin(origins = "http://localhost:4200")
public class SiteUserController {

    private final SiteUserService siteUserService;
    private final PasswordResetService passwordResetService;
    private final JwtService jwtService;

    public SiteUserController(
            SiteUserService siteUserService,
            PasswordResetService passwordResetService,
            JwtService jwtService
    ) {
        this.siteUserService = siteUserService;
        this.passwordResetService = passwordResetService;
        this.jwtService = jwtService;
    }

    // =================================================================
    // LOGIN
    // =================================================================
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        return siteUserService.login(
                request.getEmailAddress(),
                request.getPassword()
        );
    }

    // =================================================================
    // GET CURRENT USER (/me)
    // =================================================================
    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(
            @RequestHeader(value = "Authorization", required = false)
            String authHeader
    ) {

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(401).body(Map.of(
                    "timestamp", System.currentTimeMillis(),
                    "status", 401,
                    "error", "Missing token"
            ));
        }

        String token = authHeader.substring(7);
        String email = jwtService.extractUsername(token);

        if (email == null) {
            return ResponseEntity.status(401).body(Map.of(
                    "timestamp", System.currentTimeMillis(),
                    "status", 401,
                    "error", "Invalid or expired token"
            ));
        }

        SiteUser user = siteUserService.findByEmail(email).orElse(null);
        if (user == null) {
            return ResponseEntity.status(404).body(Map.of(
                    "timestamp", System.currentTimeMillis(),
                    "status", 404,
                    "error", "User not found"
            ));
        }

        Map<String, Object> safe = new HashMap<>();
        safe.put("id", user.getId());
        safe.put("username", user.getUsername());
        safe.put("emailAddress", user.getEmailAddress());
        safe.put("phoneNumber", user.getPhoneNumber());
        safe.put("role", user.getRole());
        safe.put("status", user.getStatus());
        safe.put("avatarUrl", user.getAvatarUrl());

        return ResponseEntity.ok(Map.of(
                "success", true,
                "data", safe
        ));
    }

    // =================================================================
    // CREATE USER (REGISTER)
    // =================================================================
    @PostMapping("/add")
    public ResponseEntity<?> createSiteUser(@RequestBody SiteUser siteUser) {
        try {
            SiteUser savedUser = siteUserService.saveSiteUser(siteUser);
            return ResponseEntity.ok(Map.of("success", true, "data", savedUser));

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "errors", e.getMessage().split(" \\| ")
            ));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }

    // =================================================================
    // GET ALL USERS
    // =================================================================
    @GetMapping("/getAll")
    public ResponseEntity<?> getAllSiteUsers() {
        return ResponseEntity.ok(Map.of(
                "success", true,
                "data", siteUserService.getAllSiteUsers()
        ));
    }
    
 // ================================================================
 // ADMIN UPDATE USER (ROLE + STATUS)
 // ================================================================
    @PutMapping("/admin/{id}")
    public ResponseEntity<?> adminUpdateUser(
            @PathVariable Long id,
            @RequestBody SiteUser req
    ) {
        try {

            SiteUser updated = siteUserService.updateSiteUser(id, req);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "data", updated
            ));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }

    // =================================================================
    // GET SINGLE USER BY ID
    // =================================================================
    @GetMapping("/{id}")
    public ResponseEntity<?> getSiteUserById(@PathVariable Long id) {
        return siteUserService.getSiteUserById(id)
                .map(u -> ResponseEntity.ok(Map.of("success", true, "data", u)))
                .orElse(ResponseEntity.status(404).body(Map.of(
                        "success", false,
                        "message", "User not found"
                )));
    }

    // =================================================================
    // UPDATE USER PROFILE
    // =================================================================
    @PutMapping("/{id}")
    public ResponseEntity<?> updateProfile(
            @PathVariable Long id,
            @RequestBody SiteUser req
    ) {
        try {

            SiteUser updated = siteUserService.updateProfile(
                    id,
                    req.getUsername(),
                    req.getPhoneNumber(),
                    req.getAvatarUrl()
            );

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "data", updated
            ));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }


    // =================================================================
    // DELETE USER
    // =================================================================
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteSiteUser(@PathVariable Long id) {
        try {
            String msg = siteUserService.deleteSiteUser(id);
            return ResponseEntity.ok(Map.of("success", true, "message", msg));

        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }

    // =================================================================
    // CHANGE PASSWORD (PROFILE SETTINGS)
    // =================================================================
    @PutMapping("/change-password/{id}")
    public ResponseEntity<?> changePassword(
            @PathVariable Long id,
            @RequestBody PasswordChangeRequest req
    ) {
        try {
            boolean ok = siteUserService.changePassword(
                    id,
                    req.getCurrentPassword(),
                    req.getNewPassword()
            );

            if (!ok) {
                return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "message", "Current password incorrect"
                ));
            }

            return ResponseEntity.ok(Map.of("success", true));

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "errors", e.getMessage().split(" \\| ")
            ));
        }
    }

    // =================================================================
    // UPLOAD PHOTO
    // =================================================================
    @PostMapping("/upload-photo")
    public ResponseEntity<?> uploadPhoto(
            @RequestParam MultipartFile file,
            @RequestParam Long userId
    ) {
        try {
            SiteUser updated = siteUserService.savePhoto(userId, file);
            return ResponseEntity.ok(Map.of("success", true, "data", updated));

        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }

   

    // =================================================================
    // ADMIN UNLOCK USER
    // =================================================================
    @PostMapping("/admin/unlock")
    public ResponseEntity<?> adminUnlock(@RequestBody Map<String, String> req) {
        try {
            siteUserService.unlockUserByEmail(req.get("emailAddress"));
            return ResponseEntity.ok(Map.of("success", true));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }
}
