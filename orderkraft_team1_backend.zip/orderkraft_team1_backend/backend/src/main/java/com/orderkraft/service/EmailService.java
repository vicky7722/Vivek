package com.orderkraft.service;

public interface EmailService {

    /**
     * Sends a password reset email containing:
     * - clickable reset link (Angular frontend route)
     * - OTP code
     * - resetId reference
     */
	void sendPasswordResetEmail(String toEmail, String resetId, String otp, String resetUrl);

    /**
     * Sends account unlocked notification
     */
    void sendAccountUnlockedEmail(String toEmail);
}
