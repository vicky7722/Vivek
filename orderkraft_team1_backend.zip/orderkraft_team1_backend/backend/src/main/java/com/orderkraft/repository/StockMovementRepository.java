package com.orderkraft.repository;

import com.orderkraft.model.StockMovement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StockMovementRepository extends JpaRepository<StockMovement, Long> {

    // Find all movements for a specific item, newest first
    List<StockMovement> findByItemIdOrderByTimestampDesc(Long itemId);
    
    // Find all movements, newest first
    List<StockMovement> findAllByOrderByTimestampDesc();
}