package com.orderkraft.service;

import com.orderkraft.model.InventoryItem;
import com.orderkraft.model.StockMovement;
import com.orderkraft.repository.StockMovementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class StockMovementService {

    @Autowired
    private StockMovementRepository stockMovementRepository;

    @Transactional
    public void recordMovement(InventoryItem item, int quantityChanged, String movementType, String reason, String performedBy) {
        try {
            System.out.println("    >>> [StockMovementService] Recording movement for item ID: " + item.getId());
            StockMovement movement = new StockMovement();

            movement.setItem(item);
            movement.setQuantityChanged(quantityChanged);

            // FIX: ensure movementType is never null
            movement.setMovementType(movementType != null ? movementType : "UNKNOWN");

            // FIX: ensure reason is not null
            movement.setReason(reason != null ? reason : "No reason provided");

            // FIX: ensure performedBy is not null
            movement.setPerformedBy(performedBy != null ? performedBy : "System");

            // FIX: ensure timestamp exists even if @PrePersist fails
            movement.setTimestamp(LocalDateTime.now());

            stockMovementRepository.save(movement);
            System.out.println("    <<< [StockMovementService] Movement saved successfully.");
        } catch (Exception e) {
            System.err.println("!!! [StockMovementService] FAILED to record stock movement for item ID "
                    + (item != null ? item.getId() : "null") + ": " + e.getMessage());
        }
    }


    public List<StockMovement> getMovementsForItem(Long itemId) {
        System.out.println(">>> [StockMovementService] getMovementsForItem called for item ID: " + itemId);
        return stockMovementRepository.findByItemIdOrderByTimestampDesc(itemId);
    }
    
    public List<StockMovement> getAllMovements() {
        System.out.println(">>> [StockMovementService] getAllMovements called.");
        return stockMovementRepository.findAllByOrderByTimestampDesc();
    }
}