package com.orderkraft.scheduler;

import com.orderkraft.model.MaintenanceSchedule;
import com.orderkraft.model.ProductionUnit;
import com.orderkraft.repository.MaintenanceScheduleRepository;
import com.orderkraft.repository.ProductionUnitRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class MaintenanceStatusScheduler {

    private final MaintenanceScheduleRepository msRepo;
    private final ProductionUnitRepository unitRepo;

    public MaintenanceStatusScheduler(
            MaintenanceScheduleRepository msRepo,
            ProductionUnitRepository unitRepo
    ) {
        this.msRepo = msRepo;
        this.unitRepo = unitRepo;
    }

    /**
     * Runs every 1 minute.
     */
    @Scheduled(fixedRate = 60000)
    public void autoUpdateMaintenanceStatuses() {

        LocalDateTime now = LocalDateTime.now();
        List<MaintenanceSchedule> list = msRepo.findAll();

        for (MaintenanceSchedule m : list) {

            if ("CANCELLED".equalsIgnoreCase(m.getStatus())) {
                continue;
            }

            // BEFORE start → PENDING
            if (now.isBefore(m.getStartTime())) {
                if (!"PENDING".equals(m.getStatus())) {
                    m.setStatus("PENDING");
                    msRepo.save(m);
                }
                continue;
            }

            // DURING → ACTIVE
            if (!now.isAfter(m.getEndTime())) {
                if (!"ACTIVE".equalsIgnoreCase(m.getStatus())) {
                    m.setStatus("ACTIVE");
                    msRepo.save(m);

                    // Mark unit under maintenance
                    ProductionUnit unit = unitRepo.findById(m.getUnitId()).orElse(null);
                    if (unit != null) {
                        unit.setAvailabilityStatus("MAINTENANCE");
                        unitRepo.save(unit);
                    }
                }
                continue;
            }

            // AFTER END → COMPLETED
            if (now.isAfter(m.getEndTime())) {
                if (!"COMPLETED".equalsIgnoreCase(m.getStatus())) {
                    m.setStatus("COMPLETED");
                    msRepo.save(m);

                    // Restore unit availability
                    ProductionUnit unit = unitRepo.findById(m.getUnitId()).orElse(null);
                    if (unit != null) {

                        // If load < capacity → AVAILABLE
                        if (unit.getCurrentLoad() < unit.getCapacity()) {
                            unit.setAvailabilityStatus("AVAILABLE");
                        } else {
                            unit.setAvailabilityStatus("BUSY");
                        }
                        unitRepo.save(unit);
                    }
                }
            }
        }
    }
}
