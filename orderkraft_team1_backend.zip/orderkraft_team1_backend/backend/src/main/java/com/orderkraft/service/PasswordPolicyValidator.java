package com.orderkraft.service;

import com.orderkraft.config.PasswordPolicyProperties;
import com.orderkraft.model.SiteUser;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.regex.Pattern;

/**
 * Validates password strength using configured rules.
 */
@Component
public class PasswordPolicyValidator {

    private final PasswordPolicyProperties props;

    private static final Pattern UPPER = Pattern.compile(".*[A-Z].*");
    private static final Pattern LOWER = Pattern.compile(".*[a-z].*");
    private static final Pattern DIGIT = Pattern.compile(".*\\d.*");
    private static final Pattern SPECIAL = Pattern.compile(".*[!@#$%^&*()\\-_=+\\[\\]{};:'\",.<>/?].*");

    public PasswordPolicyValidator(PasswordPolicyProperties props) {
        this.props = props;
    }

    public List<String> validate(String password, SiteUser user) {
        List<String> errors = new ArrayList<>();

        if (!StringUtils.hasText(password)) {
            errors.add("Password cannot be empty.");
            return errors;
        }

        int len = password.length();

        if (len < props.getMinLength()) {
            errors.add("Password must be at least " + props.getMinLength() + " characters long.");
        }

        if (len > props.getMaxLength()) {
            errors.add("Password must be at most " + props.getMaxLength() + " characters long.");
        }

        if (props.isRequireUpper() && !UPPER.matcher(password).matches()) {
            errors.add("Password must contain at least one uppercase letter.");
        }

        if (props.isRequireLower() && !LOWER.matcher(password).matches()) {
            errors.add("Password must contain at least one lowercase letter.");
        }

        if (props.isRequireDigit() && !DIGIT.matcher(password).matches()) {
            errors.add("Password must contain at least one digit.");
        }

        if (props.isRequireSpecial() && !SPECIAL.matcher(password).matches()) {
            errors.add("Password must contain at least one special character.");
        }

        if (props.isDisallowUsername() && user != null) {
            String u = user.getUsername() == null ? "" : user.getUsername().toLowerCase();
            String email = user.getEmailAddress() == null ? "" : user.getEmailAddress().split("@")[0].toLowerCase();
            String pwLower = password.toLowerCase();

            if (u.length() >= 3 && pwLower.contains(u)) {
                errors.add("Password must not contain your username.");
            }

            if (email.length() >= 3 && pwLower.contains(email)) {
                errors.add("Password must not contain your email.");
            }
        }

        if (StringUtils.hasText(props.getForbiddenWords())) {
            List<String> forbidden = Arrays.asList(props.getForbiddenWords().split(","));
            String pw = password.toLowerCase();
            for (String word : forbidden) {
                if (pw.contains(word.trim().toLowerCase())) {
                    errors.add("Password contains forbidden words or weak patterns.");
                    break;
                }
            }
        }

        return errors;
    }

    public void validateOrThrow(String password, SiteUser user) {
        List<String> errors = validate(password, user);
        if (!errors.isEmpty()) {
            throw new IllegalArgumentException(String.join(" | ", errors));
        }
    }
}
