package com.orderkraft.repository;
import com.orderkraft.model.WarehouseStock;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface WarehouseStockRepository extends JpaRepository<WarehouseStock, Long> {
    List<WarehouseStock> findByWarehouseId(Long warehouseId);
    Optional<WarehouseStock> findByWarehouseIdAndInventoryItemId(Long warehouseId, Long itemId);
}
