package com.orderkraft.scheduler;

import com.orderkraft.model.ProductionTask;
import com.orderkraft.repository.ProductionTaskRepository;
import com.orderkraft.service.NotificationService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class DeadlineMonitorService {

    private final ProductionTaskRepository taskRepo;
    private final NotificationService notifications;

    public DeadlineMonitorService(ProductionTaskRepository taskRepo,
                                  NotificationService notifications) {
        this.taskRepo = taskRepo;
        this.notifications = notifications;
    }

    // runs every 5 minutes
    @Scheduled(fixedRate = 300_000)
    public void checkDeadlines() {
        LocalDate today = LocalDate.now();

        List<ProductionTask> overdue =
                taskRepo.findByDeadlineBeforeAndProgressLessThan(today, 100);

        for (ProductionTask t : overdue) {
            notifications.warning("Task '" + t.getTaskName()
                    + "' is overdue (deadline " + t.getDeadline() + ")");
        }
    }
}
