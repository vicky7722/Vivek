package com.orderkraft.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "inventory_items")
public class InventoryItem {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "inventory_seq")
    @SequenceGenerator(
        name = "inventory_seq",
        sequenceName = "INVENTORY_SEQ",
        allocationSize = 1
    )
    private Long id;

    @Column(nullable = false, unique = true)
    private String sku;

    @Column(nullable = false)
    private String name;

    @Column(length = 500)
    private String description;

    @Column(nullable = false)
    private int quantity;

    @Column(name = "reorder_level")
    private Integer reorderLevel;

    @Column(name = "location")
    private String location;

    @Column(name = "warehouse")
    private String warehouse;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private StockStatus status;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;

    // ✅ ADDED: New fields from your frontend
    @Enumerated(EnumType.STRING)
    @Column(name = "shipping_status", length = 20)
    private ShippingStatus shippingStatus;

    @Column(name = "tracking_number")
    private String trackingNumber;


    // ====================== Constructors ======================
    public InventoryItem() {}

    public InventoryItem(String sku, String name, int quantity, Integer reorderLevel,
                         String location, String warehouse, String description) {
        this.sku = sku;
        this.name = name;
        this.quantity = quantity;
        this.reorderLevel = reorderLevel;
        this.location = location;
        this.warehouse = warehouse;
        this.description = description;
        this.lastUpdated = LocalDateTime.now();
    }

    // ====================== Getters & Setters ======================
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Integer getReorderLevel() {
        return reorderLevel;
    }

    public void setReorderLevel(Integer reorderLevel) {
        this.reorderLevel = reorderLevel;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }

    public StockStatus getStatus() {
        return status;
    }

    public void setStatus(StockStatus status) {
        this.status = status;
    }

    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDateTime lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    // ✅ ADDED: Getters and Setters for new fields
    public ShippingStatus getShippingStatus() {
        return shippingStatus;
    }

    public void setShippingStatus(ShippingStatus shippingStatus) {
        this.shippingStatus = shippingStatus;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }


    // ====================== Helper Methods ======================
    @PrePersist
    @PreUpdate
    public void updateTimestamp() {
        this.lastUpdated = LocalDateTime.now();
    }
}