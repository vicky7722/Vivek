package com.orderkraft.service;

import com.orderkraft.model.PasswordResetToken;
import com.orderkraft.model.SiteUser;

public interface PasswordResetService {
    PasswordResetToken createTokenForUser(SiteUser user);
    PasswordResetToken findByToken(String token);
    void invalidateToken(PasswordResetToken token);
    void invalidateAllForUser(SiteUser user);
}
