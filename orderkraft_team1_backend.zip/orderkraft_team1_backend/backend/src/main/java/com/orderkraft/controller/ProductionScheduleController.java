package com.orderkraft.controller;

import com.orderkraft.dto.ScheduleValidationRequest;
import com.orderkraft.dto.ValidationResult;
import com.orderkraft.model.ProductionSchedule;
import com.orderkraft.service.ProductionScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.stream.Collectors;


import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/schedules")
@CrossOrigin(origins = "http://localhost:4200")
public class ProductionScheduleController {

    private final ProductionScheduleService service;

    @Autowired
    public ProductionScheduleController(ProductionScheduleService service) {
        this.service = service;
    }

    @PostMapping("/validate")
    public ResponseEntity<ValidationResult> validateSchedule(@RequestBody ScheduleValidationRequest req) {
        ValidationResult vr = service.validateSchedule(req);
        return ResponseEntity.ok(vr);
    }

    @PostMapping("/add")
    public ResponseEntity<?> add(@RequestBody ProductionSchedule schedule) {
        try {
            ProductionSchedule saved = service.add(schedule);
            return ResponseEntity.ok(saved);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody ProductionSchedule payload) {
        try {
            ProductionSchedule updated = service.update(id, payload);
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{id}/status/{status}")
    public ResponseEntity<?> updateStatus(@PathVariable Long id, @PathVariable String status) {
        ProductionSchedule updated = service.updateStatus(id, status);
        if (updated == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(updated);
    }

    @PostMapping("/{id}/clone")
    public ResponseEntity<?> cloneSchedule(@PathVariable Long id) {
        try {
            ProductionSchedule clone = service.cloneSchedule(id);
            return ResponseEntity.ok(clone);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/getAll")
    public List<ProductionSchedule> getAll() {
        return service.getAll();
    }

    
    @GetMapping("/deleted")
    public List<ProductionSchedule> getDeletedSchedules() {
        return service.getDeletedSchedules();
    }



    @GetMapping
    public List<ProductionSchedule> search(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String name) {

        List<ProductionSchedule> all = service.getAll(); 

        return all.stream()
            .filter(s -> status == null || status.isBlank()
                || status.equalsIgnoreCase(s.getStatus()))
            .filter(s -> name == null || name.isBlank()
                || (s.getName() != null &&
                    s.getName().toLowerCase().contains(name.toLowerCase())))
            .collect(Collectors.toList());
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(
            @PathVariable Long id,
            @RequestParam String reason
    ) {
        String msg = service.delete(id, reason);
        if ("Not found.".equals(msg)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(Map.of("message", msg));

    }
    
    @PutMapping("/restore/{id}")
    public ResponseEntity<?> restoreSchedule(@PathVariable Long id) {
        try {

            ProductionSchedule restored = service.restoreSchedule(id);

            return ResponseEntity.ok(restored);

        } catch (RuntimeException e) {

            return ResponseEntity.badRequest().body(e.getMessage());

        } catch (Exception e) {

            e.printStackTrace();
            return ResponseEntity.internalServerError().body("Restore failed");

        }
    }
    
    

   
    
}
