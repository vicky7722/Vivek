package com.orderkraft.service;

import com.orderkraft.model.UserReview;
import com.orderkraft.repository.UserReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserReviewService {

    @Autowired
    private UserReviewRepository userReviewRepository;

    public UserReview saveUserReview(UserReview userReview) {
        return userReviewRepository.save(userReview);
    }

    public List<UserReview> getAllUserReviews() {
        return (List<UserReview>) userReviewRepository.findAll();
    }

    public Optional<UserReview> getUserReviewById(Long id) {
        return userReviewRepository.findById(id);
    }

    public UserReview updateUserReview(Long id, UserReview updatedReview) {
        Optional<UserReview> optionalReview = userReviewRepository.findById(id);
        if (optionalReview.isPresent()) {
            UserReview review = optionalReview.get();
            review.setUserId(updatedReview.getUserId());
            review.setOrderedProductId(updatedReview.getOrderedProductId());
            review.setRatingValue(updatedReview.getRatingValue());
            review.setComment(updatedReview.getComment());
            return userReviewRepository.save(review);
        }
        return null;
    }

    public String deleteUserReview(Long id) {
        if (userReviewRepository.existsById(id)) {
            userReviewRepository.deleteById(id);
            return "User Review deleted successfully.";
        }
        return "User Review not found.";
    }
}