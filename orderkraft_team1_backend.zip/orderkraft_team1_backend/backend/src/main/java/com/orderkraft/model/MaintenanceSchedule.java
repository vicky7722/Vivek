package com.orderkraft.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "maintenance_schedule")
public class MaintenanceSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "maintenance_seq_gen")
    @SequenceGenerator(name = "maintenance_seq_gen", sequenceName = "maintenance_seq", allocationSize = 1)
    private Long id;

    @Column(name = "unit_id", nullable = false)
    private Long unitId;

    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    @Column(name = "end_time", nullable = false)
    private LocalDateTime endTime;

    private String reason;

    /**
     * PENDING / ACTIVE / CANCELLED / COMPLETED
     */
    private String status = "PENDING";

    public MaintenanceSchedule() {}

    public MaintenanceSchedule(Long unitId, LocalDateTime startTime, LocalDateTime endTime, String reason) {
        this.unitId = unitId;
        this.startTime = startTime;
        this.endTime = endTime;
        this.reason = reason;
        this.status = "PENDING";
    }

    // getters / setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUnitId() { return unitId; }
    public void setUnitId(Long unitId) { this.unitId = unitId; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
