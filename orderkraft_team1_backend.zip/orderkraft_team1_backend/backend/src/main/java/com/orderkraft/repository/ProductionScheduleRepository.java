package com.orderkraft.repository;

import com.orderkraft.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ProductionScheduleRepository extends JpaRepository<ProductionSchedule, Long> {
	List<ProductionSchedule> findAllByAllocatedMachinesContains(Long machineId);

    @Query("SELECT ps FROM ProductionSchedule ps JOIN ps.allocatedMachines am WHERE am = :machineId")
    List<ProductionSchedule> findSchedulesByMachineId(@Param("machineId") Long machineId);
    
    List<ProductionSchedule> findByDeletedTrueAndStatusIgnoreCase(String status);

}