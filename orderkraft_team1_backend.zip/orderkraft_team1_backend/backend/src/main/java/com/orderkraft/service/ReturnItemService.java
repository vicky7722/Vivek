
package com.orderkraft.service;

import com.orderkraft.dto.ReturnItemDTO;
import com.orderkraft.model.InventoryItem;
import com.orderkraft.model.ReturnItem;
import com.orderkraft.repository.InventoryRepository;
import com.orderkraft.repository.ReturnItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class ReturnItemService {

    @Autowired
    private ReturnItemRepository returnItemRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    /**
     * Creates a new ReturnItem record and DECREASES stock (returns cannot exceed current stock).
     *
     * Business rule: If client requests quantity > current stock -> reject (IllegalArgumentException)
     * Otherwise reduce stock by quantityReturned (never below 0) and save the return record.
     */
    @Transactional
    public ReturnItem createReturn(ReturnItemDTO dto) {
        System.out.println(">>> [ReturnItemService] createReturn called for item ID: " + dto.getItemId());

        InventoryItem item = inventoryRepository.findById(dto.getItemId())
                .orElseThrow(() -> new NoSuchElementException("Inventory item not found: " + dto.getItemId()));

        int returnQty = dto.getQuantityReturned();
        if (returnQty <= 0) {
            throw new IllegalArgumentException("Return quantity must be greater than zero.");
        }

        int currentQty = item.getQuantity();
        if (returnQty > currentQty) {
            throw new IllegalArgumentException("Unable to return. Current stock is " + currentQty + ".");
        }

        // Subtract returned qty (will never go negative because we validated above)
        item.setQuantity(currentQty - returnQty);
        inventoryRepository.save(item);
        System.out.println("    [ReturnItemService] Stock updated: old=" + currentQty + ", new=" + item.getQuantity());

        // Save the return record
        ReturnItem newReturn = new ReturnItem();
        newReturn.setItem(item);
        newReturn.setQuantityReturned(returnQty);
        newReturn.setReason(dto.getReason());

        ReturnItem savedReturn = returnItemRepository.save(newReturn);
        System.out.println("<<< [ReturnItemService] Return saved with ID: " + savedReturn.getId());
        return savedReturn;
    }

    public List<ReturnItem> getAllReturns() {
        System.out.println(">>> [ReturnItemService] getAllReturns called.");
        return returnItemRepository.findAllByOrderByTimestampDesc();
    }
}
