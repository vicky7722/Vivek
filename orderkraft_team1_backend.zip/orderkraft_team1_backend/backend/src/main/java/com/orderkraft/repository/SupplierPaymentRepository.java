package com.orderkraft.repository;

import com.orderkraft.model.SupplierPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SupplierPaymentRepository extends JpaRepository<SupplierPayment, Long> {
    List<SupplierPayment> findBySupplierId(Long supplierId);
}
