package com.orderkraft.controller;

import com.orderkraft.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/inventory/reports")
@CrossOrigin(origins = "http://localhost:4200")
public class ReportController {

    @Autowired
    private ReportService reportService;

    // ✅ JSON summary
    @GetMapping("/summary")
    public Map<String, Object> getSummary() {
        return reportService.generateSummary();
    }

    // ✅ Download Inventory CSV
    @GetMapping("/inventory/csv")
    public ResponseEntity<InputStreamResource> downloadInventoryCsv() {
        var csvStream = reportService.exportInventoryCsv();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=inventory_report.csv")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(new InputStreamResource(csvStream));
    }

    // ✅ Download Movements CSV
    @GetMapping("/movements/csv")
    public ResponseEntity<InputStreamResource> downloadMovementsCsv() {
        var csvStream = reportService.exportMovementsCsv();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=stock_movements.csv")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(new InputStreamResource(csvStream));
    }
}
