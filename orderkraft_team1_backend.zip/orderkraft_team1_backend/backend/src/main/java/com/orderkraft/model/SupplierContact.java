package com.orderkraft.model;

import jakarta.persistence.*;

@Entity
@Table(name = "supplier_contact")
public class SupplierContact {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sup_contact_seq")
    @SequenceGenerator(name = "sup_contact_seq", sequenceName = "sup_contact_seq", allocationSize = 1)
    private Long id;

    @Column(name = "supplier_id", nullable = false)
    private Long supplierId;

    private String name;
    private String email;
    private String phone;
    private String designation;
    private Boolean preferred;

    // getters / setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getSupplierId() { return supplierId; }
    public void setSupplierId(Long supplierId) { this.supplierId = supplierId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }

    public Boolean getPreferred() { return preferred; }
    public void setPreferred(Boolean preferred) { this.preferred = preferred; }
}
