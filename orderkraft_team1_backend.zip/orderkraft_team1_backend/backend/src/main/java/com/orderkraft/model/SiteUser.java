package com.orderkraft.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.Instant;

@Entity
@Table(name = "SITE_USER")
public class SiteUser {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "site_user_seq_gen")
    @SequenceGenerator(name = "site_user_seq_gen", sequenceName = "SITE_USER_SEQ", allocationSize = 1)
    private Long id;

    @Column(name = "EMAIL_ADDRESS", nullable = false, unique = true)
    private String emailAddress;

    @Column(name = "PHONE_NUMBER")
    @Size(min = 10, max = 10, message = "Phone number must be exactly 10 digits")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Phone number must start with 6, 7, 8, or 9")
    private String phoneNumber;

    @Column(name = "PASSWORD", nullable = false)
    private String password;

    @Column(name = "USERNAME")
    private String username;

    @Column(name = "ROLE")
    private String role;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "AVATAR_URL")
    private String avatarUrl;

    // =========================
    // ACCOUNT LOCKING FIELDS
    // =========================
    @Column(name = "FAILED_ATTEMPTS")
    private Integer failedAttempts = 0;

    @Column(name = "LOCK_UNTIL")
    private Long lockUntil; // epoch millis

    // =========================
    // UTILITY
    // =========================
    public boolean isLocked() {
        return lockUntil != null && Instant.now().toEpochMilli() < lockUntil;
    }

    // =========================
    // GETTERS & SETTERS
    // =========================

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getEmailAddress() { return emailAddress; }
    public void setEmailAddress(String emailAddress) { this.emailAddress = emailAddress; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getAvatarUrl() { return avatarUrl; }
    public void setAvatarUrl(String avatarUrl) { this.avatarUrl = avatarUrl; }

    public Integer getFailedAttempts() { return failedAttempts; }
    public void setFailedAttempts(Integer failedAttempts) { this.failedAttempts = failedAttempts; }

    public Long getLockUntil() { return lockUntil; }
    public void setLockUntil(Long lockUntil) { this.lockUntil = lockUntil; }
}
