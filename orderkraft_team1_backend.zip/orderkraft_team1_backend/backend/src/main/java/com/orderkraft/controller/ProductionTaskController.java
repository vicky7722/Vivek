package com.orderkraft.controller;

import com.orderkraft.model.ProductionSchedule;
import com.orderkraft.model.ProductionTask;
import com.orderkraft.model.ProductionUnit;
import com.orderkraft.model.Worker;
import com.orderkraft.service.ProductionTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tasks")
@CrossOrigin(origins = "http://localhost:4200")
public class ProductionTaskController {

    @Autowired
    private ProductionTaskService service;

    @GetMapping("/schedule/{id}")
    public List<ProductionTask> getTasks(@PathVariable Long id) {

        service.refreshTaskStatuses();

        return service.getBySchedule(id);
    }

    @PostMapping("/add")
    public ResponseEntity<?> create(@RequestBody ProductionTask task) {

        if (task.getTaskName() == null || task.getTaskName().trim().isEmpty()) {
            return ResponseEntity
                    .badRequest()
                    .body(Map.of("error", "Task name is required"));
        }

        try {

            // Debug log (helps verify frontend payload)
            System.out.println("Creating task:");
            System.out.println("Task Name: " + task.getTaskName());
            System.out.println("Schedule ID: " + (task.getSchedule() != null ? task.getSchedule().getId() : null));
            System.out.println("Machine ID: " + (task.getUnit() != null ? task.getUnit().getId() : null));
            System.out.println("Worker ID: " + (task.getAssignedWorker() != null ? task.getAssignedWorker().getId() : null));

            ProductionTask saved = service.addTask(task);

            return ResponseEntity.ok(saved);

        } catch (Exception e) {

            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));

        }
    }

    @PutMapping("/{taskId}/assign/{unitId}")
    public ResponseEntity<?> assignUnit(@PathVariable Long taskId,
                                        @PathVariable Long unitId) {
        try {
            service.assignUnit(taskId, unitId);
            return ResponseEntity.ok(Map.of(
                    "message", "Unit assigned successfully"
            ));
        } catch (Exception e) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of(
                            "error", e.getMessage()
                    ));
        }
    }

    @PutMapping("/{taskId}/progress/{value}")
    public ResponseEntity<?> updateProgress(@PathVariable Long taskId,
                                            @PathVariable int value) {
        try {
            service.updateProgress(taskId, value);
            return ResponseEntity.ok(Map.of(
                    "message", "Progress updated"
            ));
        } catch (Exception e) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of(
                            "error", e.getMessage()
                    ));
        }
    }

    @PutMapping("/{taskId}/deadline/{date}")
    public ProductionTask updateDeadline(@PathVariable Long taskId,
                                         @PathVariable String date) {
        LocalDate d = LocalDate.parse(date);
        return service.updateDeadline(taskId, d);
    }

    @GetMapping("/overdue")
    public List<ProductionTask> getOverdue() {
        return service.getOverdue(LocalDate.now());
    }

    @GetMapping("/alternatives")
    public List<ProductionUnit> listAlternatives() {
        return service.suggestAlternativeUnits();
    }

    // ------------------ NEW endpoints ------------------

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody ProductionTask body) {
        try {
            ProductionTask updated = service.updateTask(id, body);
            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        try {
            service.deleteTask(id);
            return ResponseEntity.ok().body("Task deleted");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PutMapping("/{taskId}/assign-worker/{workerId}")
    public ResponseEntity<?> assignWorker(@PathVariable Long taskId,
                                          @PathVariable Long workerId) {
        try {
            service.assignWorker(taskId, workerId);
            return ResponseEntity.ok(Map.of(
                    "message", "Worker assigned"
            ));
        } catch (Exception e) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of(
                            "error", e.getMessage()
                    ));
        }
    }

    @PutMapping("/{taskId}/unassign-worker")
    public ResponseEntity<?> unassignWorker(@PathVariable Long taskId) {
        try {
            service.unassignWorker(taskId);
            return ResponseEntity.ok(Map.of(
                    "message", "Worker unassigned"
            ));
        } catch (Exception e) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of(
                            "error", e.getMessage()
                    ));
        }
    }

}
