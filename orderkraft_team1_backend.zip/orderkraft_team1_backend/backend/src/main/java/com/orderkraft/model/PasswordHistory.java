package com.orderkraft.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "password_history")
public class PasswordHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pwd_hist_seq_gen")
    @SequenceGenerator(name = "pwd_hist_seq_gen", sequenceName = "pwd_hist_seq", allocationSize = 1)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "hashed_password")
    private String hashedPassword;

    @Column(name = "created_at")
    private Long createdAt = Instant.now().toEpochMilli();

    // getters / setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getHashedPassword() { return hashedPassword; }
    public void setHashedPassword(String hashedPassword) { this.hashedPassword = hashedPassword; }
    public Long getCreatedAt() { return createdAt; }
    public void setCreatedAt(Long createdAt) { this.createdAt = createdAt; }
}
