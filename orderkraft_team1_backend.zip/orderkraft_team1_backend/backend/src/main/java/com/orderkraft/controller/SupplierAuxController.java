package com.orderkraft.controller;

import com.orderkraft.model.*;
import com.orderkraft.service.SupplierAuxService;
import com.orderkraft.service.SupplierPerformanceService;
import com.orderkraft.dto.SupplierPerformanceDTO;
import com.orderkraft.dto.SupplierHistoryDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.PathResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.net.URLEncoder;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/suppliers")
@CrossOrigin(origins = "http://localhost:4200")
public class SupplierAuxController {

    @Autowired private SupplierAuxService auxService;
    @Autowired private SupplierPerformanceService perfService;

    // Contacts
    @GetMapping("/{id}/contacts")
    public List<SupplierContact> getContacts(@PathVariable Long id) {
        return auxService.getContacts(id);
    }

    @PostMapping("/{id}/contacts")
    public ResponseEntity<SupplierContact> addContact(@PathVariable Long id, @RequestBody SupplierContact c) {
        c.setSupplierId(id);
        SupplierContact saved = auxService.addContact(c);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PutMapping("/contacts/{cid}")
    public SupplierContact updateContact(@PathVariable Long cid, @RequestBody SupplierContact c) {
        return auxService.updateContact(cid, c);
    }

    @DeleteMapping("/contacts/{cid}")
    public ResponseEntity<String> deleteContact(@PathVariable Long cid) {
        auxService.deleteContact(cid);
        return ResponseEntity.ok("Deleted");
    }

    // Contracts list
    @GetMapping("/{id}/contracts")
    public List<SupplierContract> getContracts(@PathVariable Long id) {
        return auxService.getContracts(id);
    }

    // Upload contract
    @PostMapping("/{id}/contracts")
    public ResponseEntity<SupplierContract> uploadContract(
            @PathVariable Long id,
            @RequestParam("file") MultipartFile file,
            @RequestParam(value="effectiveDate", required=false) String effectiveDate,
            @RequestParam(value="expiryDate", required=false) String expiryDate
    ) {
        LocalDate eff = effectiveDate == null || effectiveDate.isBlank() ? null : LocalDate.parse(effectiveDate);
        LocalDate exp = expiryDate == null || expiryDate.isBlank() ? null : LocalDate.parse(expiryDate);
        SupplierContract saved = auxService.saveContract(id, file, eff, exp);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // Download stored contract file
    @GetMapping("/{id}/contracts/download/{storedFileName:.+}")
    public ResponseEntity<Resource> downloadContract(@PathVariable Long id, @PathVariable String storedFileName) {
        Path p = auxService.loadContractFile(id, storedFileName);
        Resource resource = new PathResource(p);
        if (!resource.exists()) return ResponseEntity.notFound().build();

        String encoded;
        try {
            encoded = URLEncoder.encode(resource.getFilename(), "UTF-8").replaceAll("\\+", "%20");
        } catch (Exception e) {
            encoded = resource.getFilename();
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + encoded + "\"");
        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(p.toFile().length())
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }

    // Payments
    @GetMapping("/{id}/payments")
    public List<SupplierPayment> getPayments(@PathVariable Long id) {
        return auxService.getPayments(id);
    }

    @PostMapping("/{id}/payments")
    public ResponseEntity<SupplierPayment> addPayment(@PathVariable Long id, @RequestBody SupplierPayment p) {
        p.setSupplierId(id);
        SupplierPayment saved = auxService.savePayment(p);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // Performance
    @GetMapping("/{id}/performance")
    public SupplierPerformanceDTO getPerformance(@PathVariable Long id) {
        return perfService.computeForSupplier(id, 6); // last 6 months
    }

    // History
    @GetMapping("/{id}/history")
    public List<SupplierHistoryDTO> getHistory(@PathVariable Long id) {
        return auxService.getHistoryForSupplier(id);
    }
}
