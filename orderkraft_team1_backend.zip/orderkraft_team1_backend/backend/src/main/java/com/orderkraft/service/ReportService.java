package com.orderkraft.service;

import com.orderkraft.model.InventoryItem;
import com.orderkraft.model.StockMovement;
import com.orderkraft.repository.InventoryRepository;
import com.orderkraft.repository.StockMovementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@Service
public class ReportService {

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private StockMovementRepository stockMovementRepository;

    @Autowired
    private InventoryService inventoryService;

    // ✅ Generate JSON summary for dashboard
    public Map<String, Object> generateSummary() {
        return inventoryService.stockSummary();
    }

    // ✅ Generate inventory CSV (manual, no dependencies)
    public ByteArrayInputStream exportInventoryCsv() {
        List<InventoryItem> items = inventoryRepository.findAll();
        StringBuilder sb = new StringBuilder();

        sb.append("ID,SKU,Name,Quantity,ReorderLevel,Location,Status,LastUpdated\n");
        for (InventoryItem i : items) {
            sb.append(i.getId()).append(",")
              .append(escapeCsv(i.getSku())).append(",")
              .append(escapeCsv(i.getName())).append(",")
              .append(i.getQuantity()).append(",")
              .append(i.getReorderLevel() != null ? i.getReorderLevel() : "").append(",")
              .append(escapeCsv(i.getLocation())).append(",")
              .append(getStatus(i)).append(",")
              .append(i.getLastUpdated() != null ? i.getLastUpdated() : "")
              .append("\n");
        }

        return new ByteArrayInputStream(sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    // ✅ Generate movement history CSV (manual)
    public ByteArrayInputStream exportMovementsCsv() {
        List<StockMovement> moves = stockMovementRepository.findAll();
        StringBuilder sb = new StringBuilder();

        sb.append("ID,ItemName,QuantityChanged,MovementType,Reason,PerformedBy,Timestamp\n");
        for (StockMovement m : moves) {
            sb.append(m.getId()).append(",")
              .append(escapeCsv(m.getItem().getName())).append(",")
              .append(m.getQuantityChanged()).append(",")
              .append(m.getMovementType()).append(",")
              .append(escapeCsv(m.getReason())).append(",")
              .append(escapeCsv(m.getPerformedBy())).append(",")
              .append(m.getTimestamp())
              .append("\n");
        }

        return new ByteArrayInputStream(sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    // --- Helpers ---
    private String getStatus(InventoryItem item) {
        if (item.getQuantity() == 0) return "Out of Stock";
        if (item.getReorderLevel() != null && item.getQuantity() <= item.getReorderLevel())
            return "Low Stock";
        return "In Stock";
    }

    private String escapeCsv(String value) {
        if (value == null) return "";
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
}
