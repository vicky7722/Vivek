package com.orderkraft.scheduler;

import com.orderkraft.repository.PasswordResetTokenRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class TokenCleanupScheduler {

    private final PasswordResetTokenRepository tokenRepo;

    public TokenCleanupScheduler(PasswordResetTokenRepository tokenRepo) {
        this.tokenRepo = tokenRepo;
    }

    // run every hour
    @Scheduled(cron = "0 0 * * * *")
    public void cleanupExpired() {
        tokenRepo.deleteAllByExpiresAtBefore(LocalDateTime.now());
    }
}
