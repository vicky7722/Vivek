package com.orderkraft.repository;

import com.orderkraft.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;


public interface ProductionReportRepository extends JpaRepository<ProductionReport, Long> { }
