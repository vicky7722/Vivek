package com.orderkraft.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "inventory_alert")
public class Alert {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "alert_seq_gen")
    @SequenceGenerator(name = "alert_seq_gen", sequenceName = "alert_seq", allocationSize = 1)
    private Long id;

    @Column(name = "item_id")
    private Long itemId;

    @Column(name = "sku")
    private String sku;

    @Column(name = "message", length = 1000)
    private String message;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "resolved")
    private boolean resolved = false;

    public Alert() {}
    // getters/setters...
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Long getItemId(){return itemId;}
    public void setItemId(Long itemId){this.itemId=itemId;}
    public String getSku(){return sku;}
    public void setSku(String sku){this.sku=sku;}
    public String getMessage(){return message;}
    public void setMessage(String message){this.message = message;}
    public LocalDateTime getCreatedAt(){return createdAt;}
    public void setCreatedAt(LocalDateTime createdAt){this.createdAt = createdAt;}
    public boolean isResolved(){return resolved;}
    public void setResolved(boolean resolved){this.resolved = resolved;}
}
