package com.orderkraft.controller;

import com.orderkraft.api.ApiResponse;
import com.orderkraft.dto.WarehouseTransferRequest;
import com.orderkraft.model.WarehouseTransfer;
import com.orderkraft.service.WarehouseTransferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/warehouses")
public class WarehouseTransferController {

    private final WarehouseTransferService service;

    @Autowired
    public WarehouseTransferController(WarehouseTransferService service) {
        this.service = service;
    }

    /**
     * ✅ New endpoint name: /transfer-stock
     * This avoids conflict with the existing /transfer mapping in WarehouseController
     */
    @PostMapping("/transfer-stock")
    public ApiResponse<WarehouseTransfer> transfer(@RequestBody WarehouseTransferRequest req) {
        return ApiResponse.ok(service.transfer(req));
    }

    /**
     * 📦 Get all warehouse transfers
     */
    @GetMapping("/transfers")
    public ApiResponse<List<WarehouseTransfer>> allTransfers() {
        return ApiResponse.ok(service.findAll());
    }

    /**
     * 🔎 Get transfer history for a specific product
     */
    @GetMapping("/transfers/{productId}")
    public ApiResponse<List<WarehouseTransfer>> transfersByProduct(@PathVariable Long productId) {
        return ApiResponse.ok(service.findByProduct(productId));
    }
}
