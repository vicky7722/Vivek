package com.orderkraft.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "inventory_adjustment")
public class Adjustment {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "adjust_seq_gen")
    @SequenceGenerator(name = "adjust_seq_gen", sequenceName = "adjust_seq", allocationSize = 1)
    private Long id;

    @Column(name = "item_id")
    private Long itemId;

    @Column(name = "warehouse_id")
    private Long warehouseId;

    @Column(name = "delta")
    private Integer delta;

    @Column(name = "reason", length = 1000)
    private String reason;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public Adjustment(){}
    // getters/setters...
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Long getItemId(){return itemId;}
    public void setItemId(Long itemId){this.itemId=itemId;}
    public Long getWarehouseId(){return warehouseId;}
    public void setWarehouseId(Long warehouseId){this.warehouseId=warehouseId;}
    public Integer getDelta(){return delta;}
    public void setDelta(Integer delta){this.delta=delta;}
    public String getReason(){return reason;}
    public void setReason(String reason){this.reason=reason;}
    public LocalDateTime getCreatedAt(){return createdAt;}
    public void setCreatedAt(LocalDateTime createdAt){this.createdAt=createdAt;}
}
