package com.orderkraft.repository;

import com.orderkraft.model.UserAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface UserAuditRepository extends JpaRepository<UserAudit, Long> {
    List<UserAudit> findByUserIdOrderByCreatedAtDesc(Long userId);
}
