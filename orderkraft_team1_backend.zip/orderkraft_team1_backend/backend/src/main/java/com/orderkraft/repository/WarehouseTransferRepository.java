package com.orderkraft.repository;

import com.orderkraft.model.WarehouseTransfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface WarehouseTransferRepository extends JpaRepository<WarehouseTransfer, Long> {
    List<WarehouseTransfer> findByProductIdOrderByCreatedAtDesc(Long productId);

    @Query("select wt from WarehouseTransfer wt order by wt.createdAt desc")
    List<WarehouseTransfer> findAllOrderByCreatedAtDesc();
}
