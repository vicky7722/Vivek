package com.orderkraft.security;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Service
public class JwtService {

    @Value("${jwt.secret-base64}")
    private String base64Secret;

    @Value("${jwt.expiration-seconds}")
    private long expirationSeconds;

    private final ObjectMapper mapper = new ObjectMapper();

    public long getExpirationSeconds() {
        return expirationSeconds;
    }

    public String generateToken(String email, String role) {
        long now = System.currentTimeMillis() / 1000;
        long exp = now + expirationSeconds;

        Map<String, Object> header = Map.of("alg","HS256","typ","JWT");
        Map<String, Object> payload = new HashMap<>();
        payload.put("sub", email);
        payload.put("role", role);
        payload.put("iat", now);
        payload.put("exp", exp);

        String headerPart = base64UrlEncode(toJson(header).getBytes());
        String payloadPart = base64UrlEncode(toJson(payload).getBytes());
        String signature = hmacSha256(headerPart + "." + payloadPart, base64Secret);

        return headerPart + "." + payloadPart + "." + signature;
    }

    // Validate token and return claims map (null if invalid/expired)
    public Map<String, Object> validateTokenAndGetClaims(String token) {
        try {
            if (token == null) return null;
            String[] parts = token.split("\\.");
            if (parts.length != 3) return null;

            String headerPart = parts[0];
            String payloadPart = parts[1];
            String signaturePart = parts[2];

            String expected = hmacSha256(headerPart + "." + payloadPart, base64Secret);
            if (!expected.equals(signaturePart)) return null;

            byte[] json = Base64.getUrlDecoder().decode(payloadPart);
            Map<String, Object> claims = mapper.readValue(json, Map.class);

            Number expObj = (Number) claims.get("exp");
            long exp = expObj == null ? 0L : expObj.longValue();
            long now = System.currentTimeMillis() / 1000;
            if (now > exp) return null;

            return claims;
        } catch (Exception e) {
            return null;
        }
    }

    // Convenience helper used by controllers
    public String extractUsername(String token) {
        Map<String, Object> claims = validateTokenAndGetClaims(token);
        if (claims == null) return null;
        return (String) claims.get("sub");
    }

    public long getExpirationFromClaims(Map<String, Object> claims) {
        if (claims == null) return 0;
        Object expObj = claims.get("exp");
        return expObj == null ? 0 : ((Number) expObj).longValue();
    }

    private String toJson(Object o) {
        try { return mapper.writeValueAsString(o); } catch (Exception e) { throw new RuntimeException(e); }
    }

    private String base64UrlEncode(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private String hmacSha256(String data, String base64Secret) {
        try {
            byte[] keyBytes = Base64.getDecoder().decode(base64Secret);
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(keyBytes, "HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.getBytes()));
        } catch (Exception e) {
            throw new RuntimeException("Failed to calculate HMAC-SHA256", e);
        }
    }
}
