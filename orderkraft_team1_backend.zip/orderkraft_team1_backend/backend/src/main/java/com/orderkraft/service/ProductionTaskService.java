package com.orderkraft.service;

import com.orderkraft.model.ProductionSchedule;
import com.orderkraft.model.ProductionTask;
import com.orderkraft.model.ProductionUnit;
import com.orderkraft.model.Worker;
import com.orderkraft.repository.ProductionScheduleRepository;
import com.orderkraft.repository.ProductionTaskRepository;
import com.orderkraft.repository.ProductionUnitRepository;
import com.orderkraft.repository.WorkerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductionTaskService {

    @Autowired
    private ProductionTaskRepository taskRepo;

    @Autowired
    private ProductionUnitRepository unitRepo;
    
    @Autowired
    private ProductionScheduleRepository scheduleRepo;

    @Autowired
    private WorkerRepository workerRepo;

    @Autowired
    private NotificationService notificationService;  // existing

    @Autowired
    private MaintenanceService maintenanceService;  // existing

    // -------------------------------------------------
    //             GET TASKS BY SCHEDULE
    // -------------------------------------------------
    public List<ProductionTask> getBySchedule(Long scheduleId) {
        return taskRepo.findByScheduleId(scheduleId);
    }

    // -------------------------------------------------
    //                ADD NEW TASK
    // -------------------------------------------------
    public ProductionTask addTask(ProductionTask task) {

        // Resolve schedule
        if (task.getSchedule() != null && task.getSchedule().getId() != null) {
            ProductionSchedule schedule = new ProductionSchedule(task.getSchedule().getId());
            task.setSchedule(schedule);
        }
        
        if (task.getSchedule() != null && task.getSchedule().getId() != null) {

            ProductionSchedule schedule = scheduleRepo
                    .findById(task.getSchedule().getId())
                    .orElseThrow(() -> new RuntimeException("Schedule not found"));

            task.setSchedule(schedule);

            // 🔴 VALIDATE TASK DEADLINE INSIDE SCHEDULE
            if (task.getDeadline() != null) {

                LocalDate deadline = task.getDeadline();

                if (deadline.isBefore(schedule.getStartDate()) ||
                    deadline.isAfter(schedule.getEndDate())) {

                    throw new RuntimeException(
                        "Task deadline must be within schedule timeline"
                    );
                }
            }
        }

        // Resolve worker
        if (task.getAssignedWorker() != null && task.getAssignedWorker().getId() != null) {
            Worker worker = workerRepo.findById(task.getAssignedWorker().getId())
                    .orElseThrow(() -> new RuntimeException("Worker not found"));
            task.setAssignedWorker(worker);
        }

        // Resolve machine
        if (task.getUnit() != null && task.getUnit().getId() != null) {
            ProductionUnit unit = unitRepo.findById(task.getUnit().getId())
                    .orElseThrow(() -> new RuntimeException("Unit not found"));
            task.setUnit(unit);
        }
        
        if (task.getTaskName() == null || task.getTaskName().trim().isEmpty()) {
            task.setTaskName("Untitled Task");
        }

        ProductionTask saved = taskRepo.save(task);

        updateScheduleStatus(saved.getSchedule().getId());

        return saved;
    }

    // -------------------------------------------------
    //          UPDATE TASK PROGRESS (BRD)
    // -------------------------------------------------
    @Transactional
    public void updateProgress(Long taskId, int progress) {

        ProductionTask task = taskRepo.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        int oldProgress = task.getProgress() == null ? 0 : task.getProgress();
        task.setProgress(progress);

        if(progress >= 100){
            task.setStatus("COMPLETED");
        }
        else if(progress > 0){
            task.setStatus("IN_PROGRESS");
        }

        if (progress >= 100 && oldProgress < 100) {

            freeMachine(task);
            freeWorkerIfAssigned(task);

            String name = task.getTaskName() != null ? task.getTaskName() : "Unknown Task";

            notificationService.success(
                "Task '" + name + "' completed"
            );
        }

        taskRepo.save(task);
    }


    // -------------------------------------------------
    //       ASSIGN MACHINE TO TASK (BRD + MAINTENANCE)
    // -------------------------------------------------
    @Transactional
    public void assignUnit(Long taskId, Long unitId) {

        ProductionTask task = taskRepo.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        ProductionUnit unit = unitRepo.findById(unitId)
                .orElseThrow(() -> new RuntimeException("Unit not found"));
        
     // ------------------------------------
     // Department validation (TaskType vs Unit)
     // ------------------------------------
//     String taskType = task.getTaskType();

//     if (taskType != null) {
//
//         String unitDept = unit.getDepartment();
//
//         if (unitDept == null || !unitDept.equalsIgnoreCase(taskType)) {
//             throw new RuntimeException(
//                 "Unit does not belong to selected Task Department (" + taskType + ")"
//             );
//         }
//     }

        LocalDateTime now = LocalDateTime.now();

        // 1) If unit marked MAINTENANCE → block immediately
        if ("MAINTENANCE".equalsIgnoreCase(unit.getAvailabilityStatus())) {
            throw new RuntimeException("Unit is under maintenance.");
        }

        // 2) True maintenance time overlap check
        if (maintenanceService.isUnitUnderMaintenance(unitId, now, now)) {
            throw new RuntimeException("Unit is unavailable due to scheduled maintenance.");
        }

        // EXISTING VALIDATION (BUSY / CAPACITY)
        if (unit.isBusy())
            throw new RuntimeException("Unit is currently BUSY.");

        if (unit.isFull())
            throw new RuntimeException("Unit is at full capacity.");

        // UPDATE MACHINE LOAD
        unit.setCurrentLoad(unit.getCurrentLoad() + 1);

        if (unit.getCapacity() != null && unit.getCurrentLoad() >= unit.getCapacity()) {
            unit.setAvailabilityStatus("BUSY");
        }

        unitRepo.save(unit);

        // Link task to unit
        task.setUnit(unit);
        taskRepo.save(task);
    }

    // -------------------------------------------------
    //      FREE MACHINE WHEN TASK COMPLETES (BRD)
    // -------------------------------------------------
    @Transactional
    public void freeMachine(ProductionTask task) {

        ProductionUnit unit = task.getUnit();
        if (unit == null) return; // no machine assigned

        // reduce load
        int newLoad = Math.max(0, unit.getCurrentLoad() - 1);
        unit.setCurrentLoad(newLoad);

        // if machine was BUSY but now has free capacity
        if (unit.getCapacity() != null && newLoad < unit.getCapacity()) {
            unit.setAvailabilityStatus("AVAILABLE");
        }

        unitRepo.save(unit);

        // unlink task from machine
        task.setUnit(null);
        taskRepo.save(task);
    }

    // -------------------------------------------------
    //    NEW: Update Task (edit fields)
    // -------------------------------------------------
    
    @Transactional
    public ProductionTask updateTask(Long taskId, ProductionTask payload) {

        ProductionTask t = taskRepo.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        // Protect task name
        if (payload.getTaskName() != null && !payload.getTaskName().trim().isEmpty()) {
            t.setTaskName(payload.getTaskName());
        }

        // deadline
        if (payload.getDeadline() != null) {
            t.setDeadline(payload.getDeadline());
        }

        // priority
        if (payload.getPriority() != null) {
            t.setPriority(payload.getPriority());
        }

        // progress
        if (payload.getProgress() != null) {
            t.setProgress(payload.getProgress());
        }

        // machine
        if (payload.getUnit() != null && payload.getUnit().getId() != null) {

            ProductionUnit unit = unitRepo.findById(payload.getUnit().getId())
                    .orElseThrow(() -> new RuntimeException("Unit not found"));

            t.setUnit(unit);
        }

        // worker
        if (payload.getAssignedWorker() != null && payload.getAssignedWorker().getId() != null) {

            Worker worker = workerRepo.findById(payload.getAssignedWorker().getId())
                    .orElseThrow(() -> new RuntimeException("Worker not found"));

            t.setAssignedWorker(worker);
        }

        ProductionTask saved = taskRepo.save(t);

        if (saved.getSchedule() != null) {
            updateScheduleStatus(saved.getSchedule().getId());
        }

        return saved;
    }

    // -------------------------------------------------
    //    NEW: Delete Task
    // -------------------------------------------------
    @Transactional
    public void deleteTask(Long taskId) {
    	
        ProductionTask t = taskRepo.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));
        
        Long scheduleId = t.getSchedule() != null ? t.getSchedule().getId() : null;

        // prevent deleting if other tasks depend on this
        boolean beingDepended = taskRepo.findAll().stream()
                .anyMatch(x -> taskId.equals(x.getDependsOnTaskId()));
        if (beingDepended) {
            throw new RuntimeException("Cannot delete task: other tasks depend on it");
        }

        // If machine assigned, reduce load
        if (t.getUnit() != null) {
            ProductionUnit u = unitRepo.findById(t.getUnit().getId()).orElse(null);
            if (u != null) {
                u.setCurrentLoad(Math.max(0, u.getCurrentLoad() - 1));
                if (u.getCapacity() != null && u.getCurrentLoad() < u.getCapacity()) {
                    u.setAvailabilityStatus("AVAILABLE");
                }
                unitRepo.save(u);
            }
        }

        // If worker assigned, free worker
        freeWorkerIfAssigned(t);
        taskRepo.deleteById(taskId);

        if (scheduleId != null) {
            updateScheduleStatus(scheduleId);
        }
    }

    // -------------------------------------------------
    //    NEW: Assign / Unassign Worker
    // -------------------------------------------------
    @Transactional
    public void assignWorker(Long taskId, Long workerId) {
        ProductionTask t = taskRepo.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));
        Worker w = workerRepo.findById(workerId)
                .orElseThrow(() -> new RuntimeException("Worker not found"));

        if (!w.isAvailable()) {
            throw new RuntimeException("Worker is not available");
        }

        t.setAssignedWorker(w);
        taskRepo.save(t);

        // mark worker BUSY
        w.setAvailabilityStatus("BUSY");
        workerRepo.save(w);
    }

    @Transactional
    public void unassignWorker(Long taskId) {
        ProductionTask t = taskRepo.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));
        freeWorkerIfAssigned(t);
        taskRepo.save(t);
    }

    @Transactional
    protected void freeWorkerIfAssigned(ProductionTask task) {
        Worker w = task.getAssignedWorker();
        if (w == null) return;
        // unlink from task
        task.setAssignedWorker(null);
        // mark worker available (simple model)
        w.setAvailabilityStatus("AVAILABLE");
        workerRepo.save(w);
    }

    // -------------------------------------------------
    //    Deadline & Overdue helpers (existing)
    // -------------------------------------------------
    public ProductionTask updateDeadline(Long taskId, LocalDate deadline) {
        ProductionTask t = taskRepo.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));
        t.setDeadline(deadline);
        return taskRepo.save(t);
    }

    public List<ProductionTask> getOverdue(LocalDate today) {
        return taskRepo.findByDeadlineBeforeAndProgressLessThan(today, 100);
    }
    
    @Transactional
    public void refreshTaskStatuses() {

        List<ProductionTask> tasks = taskRepo.findAll();
        LocalDate today = LocalDate.now();

        for (ProductionTask task : tasks) {

            Integer progress = task.getProgress() == null ? 0 : task.getProgress();

            // COMPLETED
            if (progress >= 100) {

                if (!"COMPLETED".equalsIgnoreCase(task.getStatus())) {

                    task.setStatus("COMPLETED");

                    notificationService.success(
                            "Task '" + task.getTaskName() + "' completed"
                    );
                }

            }
            // OVERDUE
            else if (task.getDeadline() != null && task.getDeadline().isBefore(today)) {

                if (!"OVERDUE".equalsIgnoreCase(task.getStatus())) {

                    task.setStatus("OVERDUE");

                    notificationService.warning(
                            "Task '" + task.getTaskName() +
                            "' is overdue (deadline " + task.getDeadline() + ")"
                    );
                }

            }
            // IN PROGRESS
            else if (progress > 0) {
                task.setStatus("IN_PROGRESS");
            }
            // CREATED
            else {
                task.setStatus("CREATED");
            }
        }

        taskRepo.saveAll(tasks);
    }

    public List<ProductionUnit> suggestAlternativeUnits() {
        LocalDateTime now = LocalDateTime.now();
        List<ProductionUnit> all = unitRepo.findAll();

        return all.stream()
                .filter(u -> !"MAINTENANCE".equalsIgnoreCase(u.getAvailabilityStatus()))
                .filter(ProductionUnit::canAcceptTask)
                .filter(u -> !maintenanceService.isUnitUnderMaintenance(u.getId(), now, now))
                .collect(Collectors.toList());
    }
    
    private void validateWorkerMachineForTask(Worker worker, ProductionUnit machine) {
        if (worker == null || machine == null) {
            throw new IllegalArgumentException("Both worker and machine must be provided.");
        }

        // Check departments details
        String wDept = worker.getDepartment();
        String mDept = machine.getDepartment();
        if (wDept == null || mDept == null ||
            !wDept.trim().equalsIgnoreCase(mDept.trim())) {
            throw new IllegalArgumentException(
                    "Worker '" + worker.getName() + "' (" + wDept + ") and machine '"
                  + machine.getUnitName() + "' (" + mDept + ") are in different departments.");
        }

        // Worker must be assigned to this machine
        if (worker.getAssignedMachine() == null
                || !worker.getAssignedMachine().getId().equals(machine.getId())) {
            throw new IllegalArgumentException(
                    "Worker '" + worker.getName() + "' is not assigned to machine '"
                  + machine.getUnitName() + "'.");
        }
    }
    
    public void checkOverdueTasks() {

        List<ProductionTask> overdueTasks =
            taskRepo.findByDeadlineBeforeAndProgressLessThan(LocalDate.now(), 100);

        for (ProductionTask task : overdueTasks) {

            String name = task.getTaskName() != null
                    ? task.getTaskName()
                    : "Unknown Task";

            notificationService.warning(
                "Task '" + name + "' is overdue (deadline " + task.getDeadline() + ")"
            );
        }
    }
    
    @Transactional
    public void updateScheduleStatus(Long scheduleId) {

        List<ProductionTask> tasks = taskRepo.findByScheduleId(scheduleId);

        ProductionSchedule schedule = scheduleRepo.findById(scheduleId)
                .orElseThrow(() -> new RuntimeException("Schedule not found"));

        if (tasks.isEmpty()) {
            schedule.setStatus("ACTIVE");
            scheduleRepo.save(schedule);
            return;
        }

        boolean allCompleted = tasks.stream()
                .allMatch(t -> t.getProgress() != null && t.getProgress() >= 100);

        boolean anyOverdue = tasks.stream()
                .anyMatch(t ->
                    t.getDeadline() != null &&
                    t.getDeadline().isBefore(LocalDate.now()) &&
                    (t.getProgress() == null || t.getProgress() < 100)
                );

        boolean someCompleted = tasks.stream()
                .anyMatch(t -> t.getProgress() != null && t.getProgress() > 0);

        if (anyOverdue) {
            schedule.setStatus("PAUSED");
        }
        else if (allCompleted) {
            schedule.setStatus("COMPLETED");
        }
        else if (someCompleted) {
            schedule.setStatus("IN_PROGRESS");
        }
        else {
            schedule.setStatus("ACTIVE");
        }

        scheduleRepo.save(schedule);
    }

}
