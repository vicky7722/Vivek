package com.orderkraft.model;

/**
 * Simple enum for departments.
 * Stored as String values in the DB via the "department" columns
 * on Worker and ProductionUnit.
 */
public enum Department {
    PRODUCTION,
    PACKAGING,
    SHIPPING_LOGISTICS;

    public static String toStringValue(Department d) {
        return d == null ? null : d.name();
    }

    public static Department fromString(String value) {
        if (value == null) return null;
        try {
            return Department.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
