package com.orderkraft.controller;

import com.orderkraft.service.NotificationService;
import com.orderkraft.service.NotificationService.Notification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin(origins = "http://localhost:4200")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    // GET /api/notifications?limit=20&since=2025-11-19T12:00:00
    @GetMapping
    public List<Notification> latest(@RequestParam(defaultValue = "20") int limit,
                                     @RequestParam(required = false) String since) {
        if (since != null && !since.isBlank()) {
            try {
                LocalDateTime t = LocalDateTime.parse(since);
                return notificationService.latestSince(limit, t);
            } catch (Exception ex) {
                // parsing failed – fall back to latest
            }
        }
        return notificationService.latest(limit);
    }
}
