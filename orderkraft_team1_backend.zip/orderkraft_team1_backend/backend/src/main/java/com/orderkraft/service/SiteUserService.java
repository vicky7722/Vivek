package com.orderkraft.service;

import com.orderkraft.model.SiteUser;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

public interface SiteUserService {
    SiteUser saveSiteUser(SiteUser u);
    List<SiteUser> getAllSiteUsers();
    Optional<SiteUser> getSiteUserById(Long id);
    SiteUser updateSiteUser(Long id, SiteUser updated);
    SiteUser updateProfile(Long id, String username, String phoneNumber, String avatarUrl);
    boolean changePassword(Long id, String current, String next);
    String deleteSiteUser(Long id);

    ResponseEntity<?> login(String email, String password);

    Optional<SiteUser> findByEmail(String email);
    int getRecaptchaThreshold();
    SiteUser savePhoto(Long userId, MultipartFile file) throws Exception;
    void deactivateUser(String email);
    void unlockUserByEmail(String email);
    void autoUnlockExpiredUsers();
}
