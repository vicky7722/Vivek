package com.orderkraft.service;

import com.orderkraft.model.Order;
import com.orderkraft.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    // ➕ Create Order
    public Order createOrder(Order order) {
        if (order.getCreatedAt() == null) {
            order.setCreatedAt(LocalDateTime.now());
        }
        return orderRepository.save(order);
    }

    // 📜 All Orders
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    // 🔎 Filter by Status
    public List<Order> getOrdersByStatus(String status) {
        return orderRepository.findByStatus(status);
    }

    // 🔍 Paginated & Search
    public Page<Order> getOrdersPaginated(String search, Pageable pageable) {
        if (search == null || search.isBlank()) {
            return orderRepository.findAll(pageable);
        }
        return orderRepository.findBySupplierContainingIgnoreCaseOrItemContainingIgnoreCase(search, search, pageable);
    }

    // 🔍 Find by ID
    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    // ✏️ Update Order
    public Order updateOrder(Long id, Order updatedOrder) {
        return orderRepository.findById(id).map(order -> {
            order.setSupplier(updatedOrder.getSupplier());
            order.setItem(updatedOrder.getItem());
            order.setQuantity(updatedOrder.getQuantity());
            order.setUnitPrice(updatedOrder.getUnitPrice());
            order.setTotalPrice(updatedOrder.getTotalPrice());
            order.setStatus(updatedOrder.getStatus());
            order.setCreatedAt(updatedOrder.getCreatedAt() != null ? updatedOrder.getCreatedAt() : LocalDateTime.now());
            return orderRepository.save(order);
        }).orElse(null);
    }

    // ❌ Delete Order
    public String deleteOrder(Long id) {
        if (orderRepository.existsById(id)) {
            orderRepository.deleteById(id);
            return "Order deleted successfully.";
        }
        return "Order not found.";
    }
}
