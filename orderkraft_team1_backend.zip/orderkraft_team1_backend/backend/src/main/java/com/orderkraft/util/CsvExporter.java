package com.orderkraft.util;

import com.orderkraft.dto.InventoryReportRow;
import java.io.IOException;
import java.io.Writer;
import java.util.List;

public class CsvExporter {

    public static void writeInventoryReport(List<InventoryReportRow> rows, Writer out) throws IOException {
        // Header
        out.write("Product ID,Product,Warehouse ID,Warehouse,Quantity\n");
        // Rows
        for (InventoryReportRow r : rows) {
            out.write(csv(r.getProductId()));
            out.write(',');
            out.write(csv(r.getProductName()));
            out.write(',');
            out.write(csv(r.getWarehouseId()));
            out.write(',');
            out.write(csv(r.getWarehouseName()));
            out.write(',');
            out.write(csv(r.getQuantity()));
            out.write('\n');
        }
        out.flush();
    }

    private static String csv(Object o) {
        if (o == null) return "";
        String s = String.valueOf(o);
        boolean mustQuote = s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r");
        if (mustQuote) {
            s = s.replace("\"", "\"\"");
            return "\"" + s + "\"";
        }
        return s;
    }
}
