package com.orderkraft.repository;
import com.orderkraft.model.Adjustment;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AdjustmentRepository extends JpaRepository<Adjustment, Long>{}
