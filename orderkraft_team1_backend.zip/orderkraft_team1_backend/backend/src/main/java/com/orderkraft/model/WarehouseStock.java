package com.orderkraft.model;

import jakarta.persistence.*;

@Entity
@Table(name = "warehouse_stock", uniqueConstraints = @UniqueConstraint(columnNames = {"warehouse_id","inventory_item_id"}))
public class WarehouseStock {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "warehouse_stock_seq_gen")
    @SequenceGenerator(name = "warehouse_stock_seq_gen", sequenceName = "warehouse_stock_seq", allocationSize = 1)
    private Long id;

    @Column(name = "warehouse_id")
    private Long warehouseId;

    @Column(name = "inventory_item_id")
    private Long inventoryItemId;

    @Column(name = "quantity")
    private Integer quantity;

    public WarehouseStock(){}
    // getters/setters...
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Long getWarehouseId(){return warehouseId;}
    public void setWarehouseId(Long warehouseId){this.warehouseId=warehouseId;}
    public Long getInventoryItemId(){return inventoryItemId;}
    public void setInventoryItemId(Long inventoryItemId){this.inventoryItemId=inventoryItemId;}
    public Integer getQuantity(){return quantity;}
    public void setQuantity(Integer quantity){this.quantity=quantity;}
}
