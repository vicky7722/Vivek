package com.orderkraft.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Loads password policy settings from application.properties.
 */
@Component
@ConfigurationProperties(prefix = "password.policy")
public class PasswordPolicyProperties {

    private int minLength = 8;
    private int maxLength = 64;
    private boolean requireUpper = true;
    private boolean requireLower = true;
    private boolean requireDigit = true;
    private boolean requireSpecial = true;
    private boolean disallowUsername = true;
    private String forbiddenWords;

    public int getMinLength() { return minLength; }
    public void setMinLength(int minLength) { this.minLength = minLength; }

    public int getMaxLength() { return maxLength; }
    public void setMaxLength(int maxLength) { this.maxLength = maxLength; }

    public boolean isRequireUpper() { return requireUpper; }
    public void setRequireUpper(boolean requireUpper) { this.requireUpper = requireUpper; }

    public boolean isRequireLower() { return requireLower; }
    public void setRequireLower(boolean requireLower) { this.requireLower = requireLower; }

    public boolean isRequireDigit() { return requireDigit; }
    public void setRequireDigit(boolean requireDigit) { this.requireDigit = requireDigit; }

    public boolean isRequireSpecial() { return requireSpecial; }
    public void setRequireSpecial(boolean requireSpecial) { this.requireSpecial = requireSpecial; }

    public boolean isDisallowUsername() { return disallowUsername; }
    public void setDisallowUsername(boolean disallowUsername) { this.disallowUsername = disallowUsername; }

    public String getForbiddenWords() { return forbiddenWords; }
    public void setForbiddenWords(String forbiddenWords) { this.forbiddenWords = forbiddenWords; }
}
