package com.orderkraft.controller;

import com.orderkraft.model.StockMovement;
import com.orderkraft.service.StockMovementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventory/movements") // ✅ The base URL is for movements
@CrossOrigin(origins = "http://localhost:4200", methods = {RequestMethod.GET, RequestMethod.OPTIONS})
public class StockMovementController {

    @Autowired
    private StockMovementService stockMovementService;

    /**
     * Gets all stock movements for a specific item.
     * Mapped to {GET /api/inventory/movements/{itemId}}
     */
    @GetMapping("/{itemId}") // ✅ This is correct
    public ResponseEntity<List<StockMovement>> getMovementsForItem(@PathVariable Long itemId) {
        System.out.println(">>> [StockMovementController] GET /movements/" + itemId + " called.");
        try {
            List<StockMovement> movements = stockMovementService.getMovementsForItem(itemId);
             System.out.println("<<< [StockMovementController] GET /movements/" + itemId + " returning " + movements.size() + " movements.");
            return ResponseEntity.ok(movements);
        } catch (Exception e) {
            System.err.println("!!! [StockMovementController] ERROR in GET /movements/" + itemId + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

     /**
     * Gets all stock movements.
     * Mapped to {GET /api/inventory/movements/all}
     */
    @GetMapping("/all") // ✅ This is also correct
    public ResponseEntity<List<StockMovement>> getAllMovements() {
        System.out.println(">>> [StockMovementController] GET /movements/all called.");
        try {
            List<StockMovement> movements = stockMovementService.getAllMovements();
            System.out.println("<<< [StockMovementController] GET /movements/all returning " + movements.size() + " movements.");
            return ResponseEntity.ok(movements);
        } catch (Exception e) {
            System.err.println("!!! [StockMovementController] ERROR in GET /movements/all: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}