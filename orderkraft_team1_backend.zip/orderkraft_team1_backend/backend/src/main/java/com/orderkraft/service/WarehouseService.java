package com.orderkraft.service;

import com.orderkraft.model.Warehouse;
import com.orderkraft.model.WarehouseStock;
import com.orderkraft.repository.WarehouseRepository;
import com.orderkraft.repository.WarehouseStockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WarehouseService {
    @Autowired private WarehouseRepository warehouseRepo;
    @Autowired private WarehouseStockRepository stockRepo;

    public Warehouse create(Warehouse w){ return warehouseRepo.save(w); }
    public List<Warehouse> getAll(){ return warehouseRepo.findAll(); }

    public List<WarehouseStock> getStockForWarehouse(Long warehouseId){ return stockRepo.findByWarehouseId(warehouseId); }

    public WarehouseStock transfer(Long fromWarehouseId, Long toWarehouseId, Long itemId, int qty){
        WarehouseStock from = stockRepo.findByWarehouseIdAndInventoryItemId(fromWarehouseId, itemId).orElse(null);
        WarehouseStock to = stockRepo.findByWarehouseIdAndInventoryItemId(toWarehouseId, itemId).orElse(null);

        if(from == null || from.getQuantity() == null || from.getQuantity() < qty) return null; // insufficient

        from.setQuantity(from.getQuantity() - qty);
        stockRepo.save(from);

        if(to == null){
            to = new WarehouseStock();
            to.setWarehouseId(toWarehouseId);
            to.setInventoryItemId(itemId);
            to.setQuantity(qty);
        } else {
            to.setQuantity((to.getQuantity() == null ? 0 : to.getQuantity()) + qty);
        }
        return stockRepo.save(to);
    }

    public WarehouseStock adjustStock(Long warehouseId, Long itemId, int delta){
        WarehouseStock s = stockRepo.findByWarehouseIdAndInventoryItemId(warehouseId, itemId).orElse(null);
        if(s == null){
            s = new WarehouseStock();
            s.setWarehouseId(warehouseId);
            s.setInventoryItemId(itemId);
            s.setQuantity(Math.max(0, delta));
        } else {
            int newQty = (s.getQuantity() == null ? 0 : s.getQuantity()) + delta;
            s.setQuantity(Math.max(0, newQty));
        }
        return stockRepo.save(s);
    }
}
