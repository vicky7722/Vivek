package com.orderkraft.service;

import com.orderkraft.model.MaintenanceSchedule;
import com.orderkraft.model.ProductionUnit;
import com.orderkraft.repository.MaintenanceScheduleRepository;
import com.orderkraft.repository.ProductionUnitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MaintenanceService {

    @Autowired
    private MaintenanceScheduleRepository repo;

    @Autowired
    private ProductionUnitRepository unitRepo;

    /**
     * Schedule maintenance for a unit.
     * - Validates time window
     * - Prevents overlap
     * - If the window includes "now", immediately activates and marks the unit as MAINTENANCE.
     */
    @Transactional
    public MaintenanceSchedule scheduleMaintenance(MaintenanceSchedule req) {

        // basic validation
    	// ✅ ADD VALIDATION HERE
        if (req.getUnitId() == null) {
            throw new RuntimeException("Unit ID is required");
        }
        if (req.getStartTime() == null || req.getEndTime() == null || req.getUnitId() == null) {
            throw new IllegalArgumentException("unitId, startTime and endTime are required");
        }
        if (req.getEndTime().isBefore(req.getStartTime())) {
            throw new IllegalArgumentException("endTime must be after startTime");
        }

        // check existing overlapping maintenance (any status except CANCELLED)
        List<MaintenanceSchedule> overlaps = repo
                .findByUnitIdAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
                        req.getUnitId(), req.getEndTime(), req.getStartTime());

        if (overlaps != null && overlaps.stream()
                .anyMatch(m -> !"CANCELLED".equalsIgnoreCase(m.getStatus()))) {
            throw new IllegalStateException("Overlapping maintenance already scheduled for unit");
        }

        // default status
        if (req.getStatus() == null || req.getStatus().isBlank()) {
            req.setStatus("PENDING");
        }

        // save schedule
        MaintenanceSchedule saved = repo.save(req);

        // If time window covers now, immediately activate & mark unit as MAINTENANCE
        LocalDateTime now = LocalDateTime.now();
        if (!saved.getStartTime().isAfter(now) && !saved.getEndTime().isBefore(now)) {
            activateMaintenance(saved);
        }

        return saved;
    }

    /**
     * Mark a maintenance as ACTIVE and set the unit to MAINTENANCE.
     */
    @Transactional
    public MaintenanceSchedule activateMaintenance(MaintenanceSchedule ms) {
        ms.setStatus("ACTIVE");
        repo.save(ms);

        ProductionUnit unit = unitRepo.findById(ms.getUnitId()).orElse(null);
        if (unit != null) {
            unit.setAvailabilityStatus("MAINTENANCE");
            unitRepo.save(unit);
        }
        return ms;
    }

    /**
     * Cancel a maintenance and recalc unit availability if needed.
     */
    @Transactional
    public MaintenanceSchedule cancelMaintenance(Long id) {
        MaintenanceSchedule ms = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Maintenance not found"));

        ms.setStatus("CANCELLED");
        repo.save(ms);

        // re-evaluate unit state if it was under maintenance
        ProductionUnit unit = unitRepo.findById(ms.getUnitId()).orElse(null);
        if (unit != null) {
            LocalDateTime now = LocalDateTime.now();
            List<MaintenanceSchedule> otherActive = repo
                    .findByUnitIdAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
                            unit.getId(), now, now);

            boolean stillActive = otherActive != null && otherActive.stream()
                    .anyMatch(m -> "ACTIVE".equalsIgnoreCase(m.getStatus()));

            if (!stillActive) {
                // if capacity full -> BUSY, else AVAILABLE
                Integer cap = unit.getCapacity();
                Integer load = unit.getCurrentLoad();

                if (cap != null && load != null && load >= cap) {
                    unit.setAvailabilityStatus("BUSY");
                } else {
                    unit.setAvailabilityStatus("AVAILABLE");
                }
                unitRepo.save(unit);
            }
        }

        return ms;
    }

    public List<MaintenanceSchedule> listForUnit(Long unitId) {
        return repo.findByUnitId(unitId);
    }

    public List<MaintenanceSchedule> listAll() {
        return repo.findAll();
    }

    /**
     * Check if unit has any non-cancelled maintenance overlapping the given window.
     */
    public boolean isUnitUnderMaintenance(Long unitId, LocalDateTime start, LocalDateTime end) {
        List<MaintenanceSchedule> overlapping = repo
                .findByUnitIdAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
                        unitId, end, start);

        if (overlapping == null || overlapping.isEmpty()) return false;

        return overlapping.stream()
                .anyMatch(m -> !"CANCELLED".equalsIgnoreCase(m.getStatus()));
    }

    // ==========================================================
    // 🔔 AUTO-SCHEDULER (runs every 30 seconds)
    // ==========================================================

    /**
     * Every 30 seconds:
     * 1. PENDING windows whose startTime <= now & endTime >= now → ACTIVE + unit MAINTENANCE.
     * 2. ACTIVE windows whose endTime < now → COMPLETED, unit restored (AVAILABLE/BUSY) if no more active maintenance.
     */
    @Scheduled(fixedRate = 30000) // 30,000 ms = 30 seconds
    @Transactional
    public void refreshMaintenanceStatuses() {
        LocalDateTime now = LocalDateTime.now();

        // 1️⃣ Activate PENDING that should be active now
        List<MaintenanceSchedule> pendingNow = repo
                .findByStatusAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
                        "PENDING", now, now);

        for (MaintenanceSchedule ms : pendingNow) {
            activateMaintenance(ms);
        }

        // 2️⃣ Complete ACTIVE that are in the past
        List<MaintenanceSchedule> expiredActive = repo
                .findByStatusAndEndTimeBefore("ACTIVE", now);

        for (MaintenanceSchedule ms : expiredActive) {
            completeMaintenance(ms);
        }
    }

    /**
     * Internal helper:
     * Mark maintenance COMPLETED and recompute unit status.
     */
    @Transactional
    protected void completeMaintenance(MaintenanceSchedule ms) {
        ms.setStatus("COMPLETED");
        repo.save(ms);

        ProductionUnit unit = unitRepo.findById(ms.getUnitId()).orElse(null);
        if (unit == null) return;

        LocalDateTime now = LocalDateTime.now();

        // Check if any other ACTIVE maintenance is still covering "now"
        List<MaintenanceSchedule> activeNowForUnit = repo
                .findByUnitIdAndStatusAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
                        unit.getId(), "ACTIVE", now, now);

        boolean stillUnderMaintenance = activeNowForUnit != null && !activeNowForUnit.isEmpty();

        if (!stillUnderMaintenance) {
            Integer cap = unit.getCapacity();
            Integer load = unit.getCurrentLoad();

            if (cap != null && load != null && load >= cap) {
                unit.setAvailabilityStatus("BUSY");
            } else {
                unit.setAvailabilityStatus("AVAILABLE");
            }
            unitRepo.save(unit);
        }
    }
}
