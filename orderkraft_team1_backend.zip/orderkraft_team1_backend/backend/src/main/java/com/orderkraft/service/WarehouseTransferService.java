package com.orderkraft.service;

import com.orderkraft.dto.WarehouseTransferRequest;
import com.orderkraft.exception.BadRequestException;
import com.orderkraft.exception.NotFoundException;
import com.orderkraft.model.WarehouseTransfer;
import com.orderkraft.repository.WarehouseTransferRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class WarehouseTransferService {

    private final WarehouseTransferRepository transferRepo;

    @PersistenceContext
    private EntityManager em;

    @Autowired
    public WarehouseTransferService(WarehouseTransferRepository transferRepo) {
        this.transferRepo = transferRepo;
    }

    @Transactional
    public WarehouseTransfer transfer(WarehouseTransferRequest req) {
        if (req.getFromWarehouseId() == null || req.getToWarehouseId() == null
                || req.getProductId() == null || req.getQuantity() == null) {
            throw new BadRequestException("fromWarehouseId, toWarehouseId, productId, quantity are required.");
        }
        if (req.getFromWarehouseId().equals(req.getToWarehouseId())) {
            throw new BadRequestException("Source and destination warehouse cannot be the same.");
        }
        if (req.getQuantity() <= 0) {
            throw new BadRequestException("Quantity must be > 0.");
        }

        Long fromWh = req.getFromWarehouseId();
        Long toWh   = req.getToWarehouseId();
        Long pid    = req.getProductId();
        int qty     = req.getQuantity();

        // ensure source row exists
        if (singleWarehouseStock(fromWh, pid) == null) {
            throw new NotFoundException("Source stock not found for this product in the source warehouse.");
        }

        int srcQty = ((Number) em.createQuery(
                "select ws.quantity from WarehouseStock ws where ws.warehouse.id=:w and ws.product.id=:p")
                .setParameter("w", fromWh).setParameter("p", pid).getSingleResult()).intValue();

        if (srcQty < qty) throw new BadRequestException("Insufficient quantity in source warehouse.");

        // decrease source
        em.createQuery("update WarehouseStock ws set ws.quantity = ws.quantity - :q " +
                       "where ws.warehouse.id=:w and ws.product.id=:p")
          .setParameter("q", qty).setParameter("w", fromWh).setParameter("p", pid)
          .executeUpdate();

        // increase destination (create if missing)
        if (singleWarehouseStock(toWh, pid) == null) {
            // Create a new row using entity references
            // Note: JPQL doesn't support INSERT ... SELECT with entity refs portably, so do it via native or two-step:
            // Here we do two-step: fetch qty (already have), then either update or persist via a helper.
            // We’ll try update first; if no row updated -> create via native.
            int updated = em.createQuery("update WarehouseStock ws set ws.quantity = :q " +
                    "where ws.warehouse.id=:w and ws.product.id=:p and ws.quantity is null")
                .setParameter("q", qty).setParameter("w", toWh).setParameter("p", pid)
                .executeUpdate();

            if (updated == 0) {
                em.createNativeQuery(
                    "insert into warehouse_stock (warehouse_id, product_id, quantity) values (?, ?, ?)")
                  .setParameter(1, toWh)
                  .setParameter(2, pid)
                  .setParameter(3, qty)
                  .executeUpdate();
            }
        } else {
            em.createQuery("update WarehouseStock ws set ws.quantity = ws.quantity + :q " +
                           "where ws.warehouse.id=:w and ws.product.id=:p")
              .setParameter("q", qty).setParameter("w", toWh).setParameter("p", pid)
              .executeUpdate();
        }

        WarehouseTransfer wt = new WarehouseTransfer();
        wt.setFromWarehouseId(fromWh);
        wt.setToWarehouseId(toWh);
        wt.setProductId(pid);
        wt.setQuantity(qty);
        wt.setPerformedByUserId(req.getPerformedByUserId());
        return transferRepo.save(wt);
    }

    public List<WarehouseTransfer> findAll() {
        return transferRepo.findAllOrderByCreatedAtDesc();
    }

    public List<WarehouseTransfer> findByProduct(Long productId) {
        return transferRepo.findByProductIdOrderByCreatedAtDesc(productId);
    }

    private Object singleWarehouseStock(Long warehouseId, Long productId) {
        try {
            return em.createQuery("select ws.id from WarehouseStock ws " +
                                  "where ws.warehouse.id=:w and ws.product.id=:p")
                    .setParameter("w", warehouseId)
                    .setParameter("p", productId)
                    .setMaxResults(1)
                    .getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }
}
