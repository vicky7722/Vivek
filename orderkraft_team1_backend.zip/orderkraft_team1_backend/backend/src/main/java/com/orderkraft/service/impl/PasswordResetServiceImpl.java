package com.orderkraft.service.impl;

import com.orderkraft.model.PasswordResetToken;
import com.orderkraft.model.SiteUser;
import com.orderkraft.repository.PasswordResetTokenRepository;
import com.orderkraft.service.PasswordResetService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Random;
import java.util.UUID;

@Service
public class PasswordResetServiceImpl implements PasswordResetService {

    private final PasswordResetTokenRepository tokenRepo;
    private final long tokenTtlSeconds;

    public PasswordResetServiceImpl(PasswordResetTokenRepository tokenRepo,
                                    @Value("${app.password-reset.token-ttl-seconds:3600}") long tokenTtlSeconds) {
        this.tokenRepo = tokenRepo;
        this.tokenTtlSeconds = tokenTtlSeconds;
    }

    @Override
    @Transactional
    public PasswordResetToken createTokenForUser(SiteUser user) {

        // remove old tokens
        tokenRepo.deleteAllByUser(user);

        String token = UUID.randomUUID().toString();
        String otp = String.valueOf(100000 + new Random().nextInt(900000)); // 6-digit OTP

        LocalDateTime expiresAt = LocalDateTime.now().plusSeconds(tokenTtlSeconds);

        PasswordResetToken prt =
                new PasswordResetToken(user, token, otp, expiresAt);

        return tokenRepo.save(prt);
    }


    @Override
    public PasswordResetToken findByToken(String token) {
        return tokenRepo.findByToken(token).orElse(null);
    }

    @Override
    @Transactional
    public void invalidateToken(PasswordResetToken token) {
        tokenRepo.delete(token);
    }

    @Override
    @Transactional
    public void invalidateAllForUser(SiteUser user) {
        tokenRepo.deleteAllByUser(user);
    }
}
