package com.orderkraft.dto;

import java.util.List;

public class SupplierPerformanceDTO {
    private Long supplierId;
    private Double onTimePct;
    private Double defectRate;
    private Double avgLeadTimeDays;

    public static class MonthPoint {
        private String label;
        private Double onTimePct;
        public MonthPoint() {}
        public MonthPoint(String label, Double onTimePct) { this.label = label; this.onTimePct = onTimePct; }
        public String getLabel(){return label;} public void setLabel(String label){this.label=label;}
        public Double getOnTimePct(){return onTimePct;} public void setOnTimePct(Double v){this.onTimePct=v;}
    }

    private List<MonthPoint> months;

    public Long getSupplierId() { return supplierId; }
    public void setSupplierId(Long supplierId) { this.supplierId = supplierId; }
    public Double getOnTimePct() { return onTimePct; }
    public void setOnTimePct(Double onTimePct) { this.onTimePct = onTimePct; }
    public Double getDefectRate() { return defectRate; }
    public void setDefectRate(Double defectRate) { this.defectRate = defectRate; }
    public Double getAvgLeadTimeDays() { return avgLeadTimeDays; }
    public void setAvgLeadTimeDays(Double avgLeadTimeDays) { this.avgLeadTimeDays = avgLeadTimeDays; }
    public List<MonthPoint> getMonths() { return months; }
    public void setMonths(List<MonthPoint> months) { this.months = months; }
}
