package com.orderkraft.config;

import com.orderkraft.security.JwtAuthFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Autowired
    private JwtAuthFilter jwtAuthFilter;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
                .cors(Customizer.withDefaults())
                .csrf(csrf -> csrf.disable())

                .authorizeHttpRequests(auth -> auth

                        // --- Public endpoints ---
                        .requestMatchers(
                                "/api/auth/**",
                                "/api/orders/**",
                                "/api/siteusers/login",
                                "/api/siteusers/register",
                                "/api/siteusers/add",
                                "/api/siteusers/forgot-password",
                                "/api/siteusers/verify-otp",
                                "/api/siteusers/reset-password",
                                "/uploads/**",
                                "/error",
                                "/favicon.ico"
                        ).permitAll()

                        // --- Contract download should use JWT, NOT BasicAuth ---
                        // This prevents browser login popup during file download
                        .requestMatchers("/api/suppliers/*/contracts/download/**").permitAll()

                        // --- Supplier module ---
                        .requestMatchers("/api/suppliers/**").authenticated()

                        // --- All /api endpoints ---
                        .requestMatchers("/api/**").authenticated()

                        // --- Everything else must be authenticated ---
                        .anyRequest().authenticated()
                )

                // ❌ Disable HTTP Basic to prevent browser popup
                .httpBasic(httpBasic -> httpBasic.disable())

                // Add JWT Filter BEFORE UsernamePasswordAuthenticationFilter
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
        
    }
    

}
