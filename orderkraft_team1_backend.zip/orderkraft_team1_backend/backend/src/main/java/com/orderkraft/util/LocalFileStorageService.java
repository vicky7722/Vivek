package com.orderkraft.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.UUID;

@Service
public class LocalFileStorageService {

    private final Path baseDir;

    public LocalFileStorageService(@Value("${file.storage.base-dir:C:\\\\orderkraft\\\\uploads}") String baseDir) {
        this.baseDir = Paths.get(baseDir).toAbsolutePath().normalize();
        try {
            Files.createDirectories(this.baseDir);
        } catch (IOException e) {
            throw new RuntimeException("Could not create base upload dir", e);
        }
    }

    public Path getContractFolder(Long supplierId) {
        Path folder = baseDir.resolve("contracts").resolve(String.valueOf(supplierId));
        try {
            Files.createDirectories(folder);
        } catch (IOException e) {
            throw new RuntimeException("Could not create contract folder", e);
        }
        return folder;
    }

    public String storeFile(Long supplierId, MultipartFile file) {
        String original = StringUtils.cleanPath(file.getOriginalFilename());
        String ext = "";
        int dot = original.lastIndexOf('.');
        if (dot >= 0) ext = original.substring(dot);
        String filename = UUID.randomUUID().toString() + ext;
        Path target = getContractFolder(supplierId).resolve(filename);
        try {
            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
            return filename;
        } catch (IOException e) {
            throw new RuntimeException("Failed to store file " + original, e);
        }
    }

    public Path loadFile(Long supplierId, String storedFileName) {
        Path folder = getContractFolder(supplierId);
        Path file = folder.resolve(storedFileName).normalize();
        if (!Files.exists(file)) {
            throw new RuntimeException("File not found: " + storedFileName);
        }
        return file;
    }

    public String getPublicDownloadPath(Long supplierId, String storedFileName) {
        // This builds a logical path for your API to serve the file.
        return "/api/suppliers/" + supplierId + "/contracts/download/" + storedFileName;
    }
}
