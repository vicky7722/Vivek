package com.orderkraft.controller;

import com.orderkraft.model.UserReview;
import com.orderkraft.service.UserReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/userreviews")
public class UserReviewController {

    @Autowired
    private UserReviewService userReviewService;

    @PostMapping("/add")
    public UserReview createUserReview(@RequestBody UserReview userReview) {
        return userReviewService.saveUserReview(userReview);
    }

    @GetMapping("/getAll")
    public List<UserReview> getAllUserReviews() {
        return userReviewService.getAllUserReviews();
    }

    @GetMapping("/{id}")
    public UserReview getUserReviewById(@PathVariable Long id) {
        return userReviewService.getUserReviewById(id).orElse(null);
    }

    @PutMapping("/{id}")
    public UserReview updateUserReview(@PathVariable Long id, @RequestBody UserReview userReview) {
        return userReviewService.updateUserReview(id, userReview);
    }

    @DeleteMapping("/{id}")
    public String deleteUserReview(@PathVariable Long id) {
        return userReviewService.deleteUserReview(id);
    }
}