package com.orderkraft.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "supplier_audit")
public class SupplierAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sup_audit_seq")
    @SequenceGenerator(name = "sup_audit_seq", sequenceName = "sup_audit_seq", allocationSize = 1)
    private Long id;

    @Column(name = "supplier_id")
    private Long supplierId;

    private String event;
    private String details;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public Long getSupplierId(){return supplierId;} public void setSupplierId(Long supplierId){this.supplierId=supplierId;}
    public String getEvent(){return event;} public void setEvent(String event){this.event=event;}
    public String getDetails(){return details;} public void setDetails(String details){this.details=details;}
    public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime createdAt){this.createdAt=createdAt;}
}
