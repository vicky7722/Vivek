package com.orderkraft.controller;

import com.orderkraft.model.OrderStatus;
import com.orderkraft.service.OrderStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orderstatuses")
public class OrderStatusController {

    @Autowired
    private OrderStatusService orderStatusService;

    @PostMapping("/add")
    public OrderStatus createOrderStatus(@RequestBody OrderStatus orderStatus) {
        return orderStatusService.saveOrderStatus(orderStatus);
    }

    @GetMapping("/getAll")
    public List<OrderStatus> getAllOrderStatuses() {
        return orderStatusService.getAllOrderStatuses();
    }

    @GetMapping("/{id}")
    public OrderStatus getOrderStatusById(@PathVariable Long id) {
        return orderStatusService.getOrderStatusById(id).orElse(null);
    }

    @PutMapping("/{id}")
    public OrderStatus updateOrderStatus(@PathVariable Long id, @RequestBody OrderStatus orderStatus) {
        return orderStatusService.updateOrderStatus(id, orderStatus);
    }

    @DeleteMapping("/{id}")
    public String deleteOrderStatus(@PathVariable Long id) {
        return orderStatusService.deleteOrderStatus(id);
    }
}