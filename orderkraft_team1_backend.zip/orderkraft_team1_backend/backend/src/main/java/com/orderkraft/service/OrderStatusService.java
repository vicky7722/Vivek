package com.orderkraft.service;

import com.orderkraft.model.OrderStatus;
import com.orderkraft.repository.OrderStatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderStatusService {

    @Autowired
    private OrderStatusRepository orderStatusRepository;

    public OrderStatus saveOrderStatus(OrderStatus orderStatus) {
        return orderStatusRepository.save(orderStatus);
    }

    public List<OrderStatus> getAllOrderStatuses() {
        return (List<OrderStatus>) orderStatusRepository.findAll();
    }

    public Optional<OrderStatus> getOrderStatusById(Long id) {
        return orderStatusRepository.findById(id);
    }

    public OrderStatus updateOrderStatus(Long id, OrderStatus updatedStatus) {
        Optional<OrderStatus> optionalStatus = orderStatusRepository.findById(id);
        if (optionalStatus.isPresent()) {
            OrderStatus status = optionalStatus.get();
            status.setStatus(updatedStatus.getStatus());
            return orderStatusRepository.save(status);
        }
        return null;
    }

    public String deleteOrderStatus(Long id) {
        if (orderStatusRepository.existsById(id)) {
            orderStatusRepository.deleteById(id);
            return "Order Status deleted successfully.";
        }
        return "Order Status not found.";
    }
}