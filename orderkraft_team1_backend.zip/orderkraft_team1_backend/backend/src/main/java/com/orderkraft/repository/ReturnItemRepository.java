package com.orderkraft.repository;

import com.orderkraft.model.ReturnItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReturnItemRepository extends JpaRepository<ReturnItem, Long> {

    // Find all returns, sorted by the newest first
    List<ReturnItem> findAllByOrderByTimestampDesc();
}