package com.orderkraft.dto;

public class ProfileUpdateRequest {
    private String username;
    private String phoneNumber;
    private String avatarUrl; // optional - normally set by upload endpoint, but allowed here if provided

    public ProfileUpdateRequest() {}

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }
}
