package com.orderkraft.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "user_audit")
public class UserAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_audit_seq_gen")
    @SequenceGenerator(name = "user_audit_seq_gen", sequenceName = "user_audit_seq", allocationSize = 1)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "action")
    private String action;

    @Column(name = "actor")
    private String actor;

    @Column(name = "created_at")
    private Long createdAt = Instant.now().toEpochMilli();

    // getters / setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
    public String getActor() { return actor; }
    public void setActor(String actor) { this.actor = actor; }
    public Long getCreatedAt() { return createdAt; }
    public void setCreatedAt(Long createdAt) { this.createdAt = createdAt; }
}
