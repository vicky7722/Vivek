package com.orderkraft.repository;

import com.orderkraft.model.PasswordResetToken;
import com.orderkraft.model.SiteUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface PasswordResetTokenRepository extends JpaRepository<PasswordResetToken, String> {
    Optional<PasswordResetToken> findByToken(String token);
    void deleteAllByUser(SiteUser user);
    long deleteAllByExpiresAtBefore(LocalDateTime before);
}
