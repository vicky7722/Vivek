package com.orderkraft.dto;

import java.time.LocalDate;
import java.util.List;

public class ScheduleValidationRequest {

    private LocalDate startDate;
    private LocalDate endDate;
    private List<Long> allocatedMachines;
    private Integer requiredWorkers;

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    public List<Long> getAllocatedMachines() { return allocatedMachines; }
    public void setAllocatedMachines(List<Long> allocatedMachines) { this.allocatedMachines = allocatedMachines; }

    public Integer getRequiredWorkers() { return requiredWorkers; }
    public void setRequiredWorkers(Integer requiredWorkers) { this.requiredWorkers = requiredWorkers; }
}
