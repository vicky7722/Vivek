package com.orderkraft.service;

import com.orderkraft.model.SupplierAudit;
import com.orderkraft.repository.SupplierAuditRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class SupplierAuditService {

    @Autowired private SupplierAuditRepository auditRepo;

    public SupplierAudit log(Long supplierId, String event, String details) {
        SupplierAudit a = new SupplierAudit();
        a.setSupplierId(supplierId);
        a.setEvent(event);
        a.setDetails(details);
        a.setCreatedAt(LocalDateTime.now());
        return auditRepo.save(a);
    }

    public List<SupplierAudit> getAuditForSupplier(Long supplierId) {
        return auditRepo.findBySupplierIdOrderByCreatedAtDesc(supplierId);
    }
}
