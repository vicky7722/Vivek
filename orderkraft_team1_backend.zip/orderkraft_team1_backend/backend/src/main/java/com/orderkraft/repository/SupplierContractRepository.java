package com.orderkraft.repository;

import com.orderkraft.model.SupplierContract;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SupplierContractRepository extends JpaRepository<SupplierContract, Long> {
    List<SupplierContract> findBySupplierIdOrderByVersionNoDesc(Long supplierId);
}
