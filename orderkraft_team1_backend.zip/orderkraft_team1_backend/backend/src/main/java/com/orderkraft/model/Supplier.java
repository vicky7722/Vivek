package com.orderkraft.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "supplier")
public class Supplier {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "supplier_seq_gen")
    @SequenceGenerator(name = "supplier_seq_gen", sequenceName = "supplier_seq", allocationSize = 1)
    private Long id;

    @Column(unique = true)
    private String name;

    private String email;
    private String phone;

    @Column(length = 1000)
    private String notes;

    private Integer rating;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "supplier_tags", joinColumns = @JoinColumn(name = "supplier_id"))
    @Column(name = "tag")
    private List<String> tags;

    public Supplier() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public Integer getRating() { return rating; }
    public void setRating(Integer rating) { this.rating = rating; }

    public List<String> getTags() { return tags; }
    public void setTags(List<String> tags) { this.tags = tags; }
}
