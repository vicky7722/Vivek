package com.orderkraft.service;

import com.orderkraft.model.ProductionUnit;
import com.orderkraft.model.Worker;
import com.orderkraft.repository.ProductionUnitRepository;
import com.orderkraft.repository.WorkerRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WorkerService {

    private final WorkerRepository repo;
    private final ProductionUnitRepository unitRepo;

    public WorkerService(WorkerRepository repo,
                         ProductionUnitRepository unitRepo) {
        this.repo = repo;
        this.unitRepo = unitRepo;
    }

    // -------- basic operations --------

    public List<Worker> getAll() {
        return repo.findAll();
    }

    public Worker add(Worker w) {
        return repo.save(w);
    }

    public long getAvailableWorkers() {
        return repo.countByAvailabilityStatus("AVAILABLE");
    }

    // -------- NEW: assign a machine to a worker --------
    /**
     * Assigns a machine (ProductionUnit) to a worker.
     * Rules:
     *  - Unit must exist and be of type MACHINE.
     *  - Worker and machine must have the same department.
     *  - Each worker can only have one assigned machine (enforced by model).
     */
    public Worker assignMachineToWorker(Long workerId, Long machineId) {
        Worker worker = repo.findById(workerId)
                .orElseThrow(() -> new IllegalArgumentException("Worker not found: " + workerId));

        ProductionUnit machine = unitRepo.findById(machineId)
                .orElseThrow(() -> new IllegalArgumentException("Machine not found: " + machineId));

//        if (!"MACHINE".equalsIgnoreCase(machine.getUnitType())) {
//            throw new IllegalArgumentException("Unit " + machine.getUnitName() + " is not a MACHINE.");
//        }

        // Department check
        String wDept = worker.getDepartment();
        String mDept = machine.getDepartment();
        if (wDept == null || mDept == null ||
                !wDept.trim().equalsIgnoreCase(mDept.trim())) {
            throw new IllegalArgumentException(
                    "Worker '" + worker.getName() + "' (" + wDept + ") and machine '" +
                            machine.getUnitName() + "' (" + mDept + ") are not in the same department.");
        }

        // Link worker → machine (one machine per worker)
        worker.setAssignedMachine(machine);
        return repo.save(worker);
    }
}
