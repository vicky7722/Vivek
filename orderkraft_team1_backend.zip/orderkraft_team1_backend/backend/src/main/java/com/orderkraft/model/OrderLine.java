package com.orderkraft.model;

import jakarta.persistence.*;

@Entity
@Table(name = "order_line")
public class OrderLine {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_line_seq_gen")
    @SequenceGenerator(name = "order_line_seq_gen", sequenceName = "order_line_seq", allocationSize = 1)
    private Long id;

    @Column(name = "product_item_id")
    private Long productItemId;

    @Column(name = "order_id")
    private Long orderId;

    @Column(name = "qty")
    private Integer qty;

    @Column(name = "price")
    private Double price;

    // Constructors
    public OrderLine() {
        super();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getProductItemId() { return productItemId; }
    public void setProductItemId(Long productItemId) { this.productItemId = productItemId; }
    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }
    public Integer getQty() { return qty; }
    public void setQty(Integer qty) { this.qty = qty; }
    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }
}