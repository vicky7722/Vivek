package com.orderkraft.repository;

import com.orderkraft.model.Worker;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WorkerRepository extends JpaRepository<Worker, Long> {
    long countByAvailabilityStatus(String status);
}
