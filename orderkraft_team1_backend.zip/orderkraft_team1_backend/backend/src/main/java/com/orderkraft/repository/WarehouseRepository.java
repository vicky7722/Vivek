package com.orderkraft.repository;
import com.orderkraft.model.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;
public interface WarehouseRepository extends JpaRepository<Warehouse, Long>{}
