package com.orderkraft.config;

import com.orderkraft.model.Item;
import com.orderkraft.model.Supplier;
import com.orderkraft.repository.ItemRepository;
import com.orderkraft.repository.SupplierRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DataLoader {

    @Autowired
    private SupplierRepository supplierRepository;

    @Autowired
    private ItemRepository itemRepository;

    @PostConstruct
    public void loadSampleData() {
        if (supplierRepository.count() == 0) {

            // ---- Create Suppliers ----
            Supplier s1 = new Supplier();
            s1.setName("ABC Traders");
            supplierRepository.save(s1);

            Supplier s2 = new Supplier();
            s2.setName("Global Supply Co.");
            supplierRepository.save(s2);

            Supplier s3 = new Supplier();
            s3.setName("Metro Hardware");
            supplierRepository.save(s3);

            // ---- Create Items for ABC Traders ----
            createItem("Steel Rod", 120.0, 500, s1.getId());
            createItem("Iron Sheet", 150.0, 300, s1.getId());

            // ---- Create Items for Global Supply Co. ----
            createItem("Copper Wire", 200.0, 1000, s2.getId());
            createItem("Aluminium Coil", 180.0, 600, s2.getId());

            // ---- Create Items for Metro Hardware ----
            createItem("Nails Pack", 50.0, 2000, s3.getId());
            createItem("Screws Pack", 60.0, 1800, s3.getId());

            System.out.println("✅ Sample supplier & item data seeded into database.");
        }
    }

    private void createItem(String name, double price, int qty, Long supplierId) {
        Item item = new Item();
        item.setName(name);
        item.setUnitPrice(price);
        item.setQuantity(qty);
        item.setSupplierId(supplierId);
        itemRepository.save(item);
    }
}
