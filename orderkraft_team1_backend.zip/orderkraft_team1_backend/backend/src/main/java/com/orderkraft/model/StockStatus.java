package com.orderkraft.model;

/**
 * Represents the stock status of an inventory item.
 * This is the single source of truth for status.
 */
public enum StockStatus {
    IN_STOCK,
    LOW_STOCK,
    OUT_OF_STOCK,
    ARCHIVED // This status is used for "soft deletes"
}