package com.orderkraft.service.impl;

import com.orderkraft.model.SiteUser;
import com.orderkraft.repository.SiteUserRepository;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class AppUserDetailsService implements UserDetailsService {

    private final SiteUserRepository repo;

    public AppUserDetailsService(SiteUserRepository repo) {
        this.repo = repo;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        SiteUser u = repo.findByEmailAddress(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

        // role provided by DB: store as ROLE_ prefixed
        String role = u.getRole() == null ? "USER" : u.getRole();
        return User.withUsername(u.getEmailAddress())
                .password(u.getPassword())
                .roles(role.replace("ROLE_", "").replace("ROLE", ""))
                .disabled("Inactive".equalsIgnoreCase(u.getStatus()))
                .build();
    }
}
