package com.orderkraft.dto;

public class KpiResponse {
    private long distinctProducts;
    private long totalUnits;
    private long lowStockItems;

    public KpiResponse() {}

    public KpiResponse(long distinctProducts, long totalUnits, long lowStockItems) {
        this.distinctProducts = distinctProducts;
        this.totalUnits = totalUnits;
        this.lowStockItems = lowStockItems;
    }

    public long getDistinctProducts() { return distinctProducts; }
    public void setDistinctProducts(long distinctProducts) { this.distinctProducts = distinctProducts; }
    public long getTotalUnits() { return totalUnits; }
    public void setTotalUnits(long totalUnits) { this.totalUnits = totalUnits; }
    public long getLowStockItems() { return lowStockItems; }
    public void setLowStockItems(long lowStockItems) { this.lowStockItems = lowStockItems; }
}
