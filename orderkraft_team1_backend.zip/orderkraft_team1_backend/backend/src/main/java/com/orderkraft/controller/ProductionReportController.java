package com.orderkraft.controller;

import com.orderkraft.dto.ReportFilterRequest;          // ✅ add this
import com.orderkraft.model.ProductionReport;
import com.orderkraft.service.ProductionReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "http://localhost:4200")
public class ProductionReportController {

    @Autowired
    private ProductionReportService service;

    // --- legacy GET endpoint, now wraps into ReportFilterRequest ---
    @GetMapping("/generate/{type}/{user}")
    public ProductionReport generate(@PathVariable String type,
                                     @PathVariable String user) {

        ReportFilterRequest req = new ReportFilterRequest();
        req.setType(type);                  // just set the type, no date filters
        return service.generateReport(req, user);
    }

    @GetMapping("/getAll")
    public List<ProductionReport> getAll() {
        return service.getAll();
    }

    // --- new endpoint with full filter object ---
    @PostMapping("/generate/{user}")
    public ProductionReport generateFiltered(@PathVariable String user,
                                             @RequestBody ReportFilterRequest request) {
        return service.generateReport(request, user);
    }
}
