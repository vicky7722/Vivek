package com.orderkraft.repository;

import com.orderkraft.model.ProductionTask;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.time.LocalDate;

public interface ProductionTaskRepository extends JpaRepository<ProductionTask, Long> {

    List<ProductionTask> findByScheduleId(Long scheduleId);

    List<ProductionTask> findByDeadlineBeforeAndProgressLessThan(LocalDate date, Integer progress);

    List<ProductionTask> findByDeadline(LocalDate date);

    // NEW helper
    List<ProductionTask> findByAssignedWorkerId(Long workerId);
}
