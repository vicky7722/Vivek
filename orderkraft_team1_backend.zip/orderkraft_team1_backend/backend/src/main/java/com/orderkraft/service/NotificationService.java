package com.orderkraft.service;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class NotificationService {

    public static class Notification {
        private String message;
        private String type;       // info / success / warning / error
        private LocalDateTime time;

        public Notification() {}

        public Notification(String message, String type, LocalDateTime time) {
            this.message = message;
            this.type = type;
            this.time = time;
        }

        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }

        public String getType() { return type; }
        public void setType(String type) { this.type = type; }

        public LocalDateTime getTime() { return time; }
        public void setTime(LocalDateTime time) { this.time = time; }
    }

    private static final int MAX_NOTIFICATIONS = 100;
    private final LinkedList<Notification> store = new LinkedList<>();

//    private void push(String msg, String type) {
//        synchronized (store) {
//            store.addFirst(new Notification(msg, type, LocalDateTime.now()));
//            while (store.size() > MAX_NOTIFICATIONS) {
//                store.removeLast();
//            }
//        }
//    }
    
    private void push(String msg, String type) {
        synchronized (store) {

            boolean exists = store.stream()
                .anyMatch(n -> n.getMessage().equals(msg));

            if (exists) {
                return; // do not add duplicate notification
            }

            store.addFirst(new Notification(msg, type, LocalDateTime.now()));

            while (store.size() > MAX_NOTIFICATIONS) {
                store.removeLast();
            }
        }
    }

    public void info(String msg)    { push(msg, "info"); }
    public void success(String msg) { push(msg, "success"); }
    public void warning(String msg) { push(msg, "warning"); }
    public void error(String msg)   { push(msg, "error"); }

    public List<Notification> latest(int limit) {
        synchronized (store) {
            int size = Math.min(limit, store.size());
            return Collections.unmodifiableList(new ArrayList<>(store.subList(0, size)));
        }
    }

    // NEW: return notifications after the provided time
    public List<Notification> latestSince(int limit, LocalDateTime since) {
        synchronized (store) {
            List<Notification> filtered = store.stream()
            		.filter(n -> n.getTime() != null && !n.getTime().isBefore(since))
                    .limit(limit)
                    .collect(Collectors.toList());
            return Collections.unmodifiableList(filtered);
        }
    }
    
    
}
