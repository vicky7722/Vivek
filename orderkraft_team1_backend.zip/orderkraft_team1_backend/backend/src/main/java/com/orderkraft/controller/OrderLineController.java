package com.orderkraft.controller;

import com.orderkraft.model.OrderLine;
import com.orderkraft.service.OrderLineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orderlines")
public class OrderLineController {

    @Autowired
    private OrderLineService orderLineService;

    @PostMapping("/add")
    public OrderLine createOrderLine(@RequestBody OrderLine orderLine) {
        return orderLineService.saveOrderLine(orderLine);
    }

    @GetMapping("/getAll")
    public List<OrderLine> getAllOrderLines() {
        return orderLineService.getAllOrderLines();
    }

    @GetMapping("/{id}")
    public OrderLine getOrderLineById(@PathVariable Long id) {
        return orderLineService.getOrderLineById(id).orElse(null);
    }

    @PutMapping("/{id}")
    public OrderLine updateOrderLine(@PathVariable Long id, @RequestBody OrderLine orderLine) {
        return orderLineService.updateOrderLine(id, orderLine);
    }

    @DeleteMapping("/{id}")
    public String deleteOrderLine(@PathVariable Long id) {
        return orderLineService.deleteOrderLine(id);
    }
}