package com.orderkraft.service;

import com.orderkraft.dto.ScheduleValidationRequest;
import com.orderkraft.dto.ValidationResult;
import com.orderkraft.model.ProductionSchedule;
import com.orderkraft.model.ProductionUnit;
import com.orderkraft.repository.ProductionScheduleRepository;
import com.orderkraft.repository.ProductionUnitRepository;
import com.orderkraft.repository.WorkerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.time.LocalDate;
import java.util.ArrayList;

@Service
public class ProductionScheduleService {

    private final ProductionScheduleRepository repo;
    private final ProductionUnitRepository unitRepo;
    private final WorkerRepository workerRepo;

    @Autowired
    public ProductionScheduleService(
            ProductionScheduleRepository repo,
            ProductionUnitRepository unitRepo,
            WorkerRepository workerRepo
    ) {
        this.repo = repo;
        this.unitRepo = unitRepo;
        this.workerRepo = workerRepo;
    }
    
    
    
    
    private void syncStatusWithDates(ProductionSchedule s) {
        if (s.getStartDate() == null || s.getEndDate() == null) {
            return;
        }

        var today = java.time.LocalDate.now();

        if (today.isAfter(s.getEndDate())) {
            s.setStatus("COMPLETED");
        } else if (today.isBefore(s.getStartDate())) {
            s.setStatus("ACTIVE"); // or PLANNED if you want later
        } else {
            s.setStatus("ACTIVE");
        }
    }


    // ------------------ BASIC CRUD / QUERY ------------------

    

    public Optional<ProductionSchedule> getById(Long id) {
        return repo.findById(id);
    }

    public ProductionSchedule add(ProductionSchedule schedule) {
    	syncStatusWithDates(schedule);
        return repo.save(schedule);
    }

    public ProductionSchedule update(Long id, ProductionSchedule payload) {

        ProductionSchedule schedule = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Schedule not found"));

        schedule.setName(payload.getName());
        schedule.setStartDate(payload.getStartDate());
        schedule.setEndDate(payload.getEndDate());
        schedule.setStatus(payload.getStatus());
        schedule.setRequiredWorkers(payload.getRequiredWorkers());

        // ---------- MACHINES ----------

        if(payload.getProductionMachines()!=null){
            schedule.getProductionMachines().clear();
            schedule.getProductionMachines().addAll(payload.getProductionMachines());
        }

        if(payload.getPackagingMachines()!=null){
            schedule.getPackagingMachines().clear();
            schedule.getPackagingMachines().addAll(payload.getPackagingMachines());
        }

        if(payload.getShippingMachines()!=null){
            schedule.getShippingMachines().clear();
            schedule.getShippingMachines().addAll(payload.getShippingMachines());
        }

        // ---------- ALLOCATED MACHINES ----------

        if(payload.getAllocatedMachines()!=null){
            schedule.getAllocatedMachines().clear();
            schedule.getAllocatedMachines().addAll(payload.getAllocatedMachines());
        }

        return repo.save(schedule);
    }


    public ProductionSchedule updateStatus(Long id, String status) {
        return repo.findById(id).map(s -> {
            s.setStatus(status);
            return repo.save(s);
        }).orElse(null);
    }



    public ProductionSchedule cloneSchedule(Long id) {
        ProductionSchedule s = repo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Schedule not found: " + id));

        ProductionSchedule copy = new ProductionSchedule();
        copy.setName(s.getName() + " (Copy)");
        copy.setStartDate(s.getStartDate());
        copy.setEndDate(s.getEndDate());
        copy.setAllocatedMachines(s.getAllocatedMachines());
        copy.setRequiredWorkers(s.getRequiredWorkers());
        copy.setCreatedBy(s.getCreatedBy());
        copy.setStatus("ACTIVE");
        copy.setCreatedAt(LocalDateTime.now());

        // copy per-department allocations too
        copy.setProductionMachines(s.getProductionMachines());
        copy.setPackagingMachines(s.getPackagingMachines());
        copy.setShippingMachines(s.getShippingMachines());
        copy.setProductionWorkers(s.getProductionWorkers());
        copy.setPackagingWorkers(s.getPackagingWorkers());
        copy.setShippingWorkers(s.getShippingWorkers());

        return repo.save(copy);
    }

    public List<ProductionSchedule> search(String status, String name) {
        List<ProductionSchedule> all = repo.findAll();
        return all.stream()
                .filter(s -> status == null || status.isBlank() || status.equalsIgnoreCase(s.getStatus()))
                .filter(s -> name == null || name.isBlank()
                        || (s.getName() != null && s.getName().toLowerCase().contains(name.toLowerCase())))
                .collect(Collectors.toList());
    }
    
//    public List<ProductionSchedule> getDeletedSchedules() {
//    	return repo.findAll()
//    	        .stream()
//    	        .filter(s -> !Boolean.TRUE.equals(s.getDeleted()))
//    	        .collect(Collectors.toList());
//
//    }
    public List<ProductionSchedule> getDeletedSchedules() {
        return repo.findByDeletedTrueAndStatusIgnoreCase("DELETED");
    }


    
//    public String delete(Long id, String reason) {
//
//        ProductionSchedule schedule = repo.findById(id).orElse(null);
//
//        if (schedule == null) {
//            return "Not found.";
//        }
//
//        schedule.setDeleted(true);
//        schedule.setDeletedAt(LocalDateTime.now());
//        schedule.setDeleteReason(reason);
//
//        repo.save(schedule);
//
//        return "Deleted successfully";
//    }
    public String delete(Long id, String reason) {

        ProductionSchedule schedule = repo.findById(id).orElse(null);

        if (schedule == null) {
            return "Not found.";
        }

        schedule.setDeleted(true);
        schedule.setStatus("DELETED");   // 🔥 ADD THIS
        schedule.setDeletedAt(LocalDateTime.now());
        schedule.setDeleteReason(reason);
        schedule.setStatus("DELETED");


        repo.save(schedule);

        return "Deleted successfully";
    }




    public List<ProductionSchedule> getAll() {

        List<ProductionSchedule> schedules = repo.findAll()
            .stream()
            .filter(s -> s.getDeleted() == null || !s.getDeleted())
            .collect(Collectors.toList());

        schedules.forEach(this::syncStatusWithDates);

        return schedules;
    }


    // ------------------ VALIDATION ------------------

    public ValidationResult validateSchedule(ScheduleValidationRequest req) {
        // This is your existing logic, cleaned and kept as-is for now.
        ValidationResult vr = new ValidationResult();

        if (req.getStartDate() == null || req.getEndDate() == null) {
            vr.addError("Start date and end date are required.");
            return vr;
        }

        if (req.getEndDate().isBefore(req.getStartDate())) {
            vr.addError("End date cannot be before start date.");
        }

        // Validate machines: existence, capacity, conflicts
        if (req.getAllocatedMachines() != null) {
            for (Long mId : req.getAllocatedMachines()) {
                ProductionUnit unit = unitRepo.findById(mId).orElse(null);
                if (unit == null) {
                    vr.addError("Machine/Unit with id " + mId + " does not exist.");
                    continue;
                }

                if ("BUSY".equalsIgnoreCase(unit.getAvailabilityStatus())) {
                    vr.addError("Machine " + unit.getUnitName() + " is currently BUSY.");
                }

                Integer cap = unit.getCapacity();
                Integer load = unit.getCurrentLoad();
                int safeCap = (cap != null) ? cap : 0;
                int safeLoad = (load != null) ? load : 0;

                if (safeCap > 0 && safeLoad >= safeCap) {
                    vr.addError("Machine " + unit.getUnitName() + " is at full capacity.");
                }

                List<ProductionSchedule> overlapping =
                        repo.findAllByAllocatedMachinesContains(mId);

                for (ProductionSchedule s : overlapping) {
                    boolean overlaps =
                            !(req.getEndDate().isBefore(s.getStartDate())
                                    || req.getStartDate().isAfter(s.getEndDate()));

                    if (overlaps) {
                        vr.addError("Machine " + unit.getUnitName()
                                + " conflicts with existing schedule: " + s.getName());
                    }
                }
            }
        }

        // General schedule date overlap
        repo.findAll().forEach(s -> {
            boolean overlap =
                    !(req.getEndDate().isBefore(s.getStartDate())
                            || req.getStartDate().isAfter(s.getEndDate()));

            if (overlap) {
                vr.addError("Schedule dates overlap with existing schedule: " + s.getName());
            }
        });

        // Worker capacity (global check for now)
        long availableWorkers = workerRepo.countByAvailabilityStatus("AVAILABLE");
        int required = (req.getRequiredWorkers() != null) ? req.getRequiredWorkers() : 0;

        if (required > availableWorkers) {
            vr.addError("Required workers: " + required
                    + ", Available workers: " + availableWorkers);
        }

        return vr;
        
    }
    
    @GetMapping("/schedules")
    public List<ProductionSchedule> getAllActive() {
        return repo.findAll()
            .stream()
            .filter(s -> !Boolean.TRUE.equals(s.getDeleted()))
            .collect(Collectors.toList());
    }
    

    public ProductionSchedule restoreSchedule(Long id) {

        ProductionSchedule schedule = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Schedule not found"));

        schedule.setDeleted(false);   // restore schedule

        return repo.save(schedule);
    }
}

