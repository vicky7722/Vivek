package com.orderkraft.controller;

import com.orderkraft.model.Alert;
import com.orderkraft.service.AlertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/alerts")
@CrossOrigin(origins = "http://localhost:4200")
public class AlertController {
    @Autowired
    private AlertService alertService;

    @GetMapping("/active")
    public List<Alert> getActive(){ return alertService.getActiveAlerts(); }

    @PostMapping("/create")
    public Alert create(@RequestParam Long itemId, @RequestParam String sku, @RequestParam String message){
        return alertService.createAlert(itemId, sku, message);
    }

    @PostMapping("/{id}/resolve")
    public ResponseEntity<?> resolve(@PathVariable Long id){
        Alert res = alertService.resolve(id);
        if(res == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(res);
    }
}
