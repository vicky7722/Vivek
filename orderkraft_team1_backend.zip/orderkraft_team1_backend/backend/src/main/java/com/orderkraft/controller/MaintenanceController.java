package com.orderkraft.controller;

import com.orderkraft.model.MaintenanceSchedule;
import com.orderkraft.service.MaintenanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/maintenance")
@CrossOrigin(origins = "http://localhost:4200")
public class MaintenanceController {

    @Autowired
    private MaintenanceService service;

    @PostMapping("/schedule")
    public MaintenanceSchedule schedule(@RequestBody MaintenanceSchedule req) {
        return service.scheduleMaintenance(req);
    }

    @DeleteMapping("/{id}")
    public String cancel(@PathVariable Long id) {
        service.cancelMaintenance(id);
        return "Cancelled";
    }

    @GetMapping("/unit/{unitId}")
    public List<MaintenanceSchedule> listForUnit(@PathVariable Long unitId) {
        return service.listForUnit(unitId);
    }

    @GetMapping
    public List<MaintenanceSchedule> listAll() {
        return service.listAll();
    }
}
