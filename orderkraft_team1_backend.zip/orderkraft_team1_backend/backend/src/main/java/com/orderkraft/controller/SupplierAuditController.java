package com.orderkraft.controller;

import com.orderkraft.model.SupplierAudit;
import com.orderkraft.service.SupplierAuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/suppliers")
@CrossOrigin(origins = "http://localhost:4200")
public class SupplierAuditController {

    @Autowired private SupplierAuditService auditService;

    @GetMapping("/{id}/audit")
    public List<SupplierAudit> getAudit(@PathVariable Long id) {
        return auditService.getAuditForSupplier(id);
    }
}
