package com.orderkraft.repository;

import com.orderkraft.model.SiteUser;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public interface SiteUserRepository extends JpaRepository<SiteUser, Long> {

    Optional<SiteUser> findByEmailAddress(String emailAddress);

    // =====================
    // FAILED ATTEMPTS
    // =====================
    @Modifying
    @Transactional
    @Query("UPDATE SiteUser u SET u.failedAttempts = u.failedAttempts + 1 WHERE u.emailAddress = :email")
    void incrementFailedAttempts(@Param("email") String email);

    @Modifying
    @Transactional
    @Query("UPDATE SiteUser u SET u.failedAttempts = 0 WHERE u.emailAddress = :email")
    void resetFailedAttempts(@Param("email") String email);

    // =====================
    // ACCOUNT LOCK
    // =====================
    @Modifying
    @Transactional
    @Query("UPDATE SiteUser u SET u.lockUntil = :until WHERE u.emailAddress = :email")
    void lockUser(@Param("email") String email, @Param("until") Long until);

    @Modifying
    @Transactional
    @Query("UPDATE SiteUser u SET u.lockUntil = NULL, u.failedAttempts = 0 WHERE u.emailAddress = :email")
    void unlockUser(@Param("email") String email);

    @Query("SELECT u FROM SiteUser u WHERE u.lockUntil IS NOT NULL AND u.lockUntil < :now")
    List<SiteUser> findExpiredLockedUsers(@Param("now") Long now);

    // =====================
    // STATUS UPDATE
    // =====================
    @Modifying
    @Transactional
    @Query("UPDATE SiteUser u SET u.status = :status WHERE u.emailAddress = :email")
    void updateUserStatus(@Param("email") String email, @Param("status") String status);
}