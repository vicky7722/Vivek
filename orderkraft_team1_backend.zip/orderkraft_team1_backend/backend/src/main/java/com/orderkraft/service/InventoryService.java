package com.orderkraft.service;
import com.orderkraft.model.ShippingStatus;

import com.orderkraft.model.InventoryItem;
import com.orderkraft.model.StockStatus; // Import the correct enum
import com.orderkraft.repository.InventoryRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class InventoryService {

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private StockMovementService stockMovementService; // Your service is injected

    // Get all items (✅ UPDATED to only get active items)
    public List<InventoryItem> getAllItems() {
        System.out.println(">>> [InventoryService] getAllItems (Active only) called.");
        return inventoryRepository.findAll();
    }

    // Get by ID
    public Optional<InventoryItem> getItem(Long id) {
         System.out.println(">>> [InventoryService] getItem called for ID: " + id);
        return inventoryRepository.findById(id);
    }

    @Transactional
    public InventoryItem addItem(InventoryItem item) {

        System.out.println(">>> [InventoryService] addItem called for item: " + item.getName());

        if (item.getQuantity() < 0) {
            item.setQuantity(0);
        }

        if (item.getReorderLevel() == null) {
            item.setReorderLevel(10);
        }

        if (item.getLocation() == null || item.getLocation().trim().isEmpty()) {
            item.setLocation("Unassigned");
        }

        if (item.getWarehouse() == null || item.getWarehouse().trim().isEmpty()) {
            item.setWarehouse("Unassigned");
        }

        if (item.getQuantity() <= 0) {
            item.setStatus(StockStatus.OUT_OF_STOCK);
        } else if (item.getQuantity() <= item.getReorderLevel()) {
            item.setStatus(StockStatus.LOW_STOCK);
        } else {
            item.setStatus(StockStatus.IN_STOCK);
        }

        if (item.getShippingStatus() == null) {
            item.setShippingStatus(ShippingStatus.PENDING);
        }

        item.setLastUpdated(LocalDateTime.now());

        // ✅ ONLY save inventory here
        InventoryItem savedItem = inventoryRepository.save(item);

        return savedItem;
    }



    // Get by SKU
    public Optional<InventoryItem> getBySku(String sku) {
        System.out.println(">>> [InventoryService] getBySku called for SKU: " + sku);
        return inventoryRepository.findBySku(sku);
    }
    
    public InventoryItem saveItem(InventoryItem item) {
         System.out.println(">>> [InventoryService] saveItem called for item: " + item.getName() + " (ID: " + item.getId() + ") - WARNING: Movement might not be recorded!");
         setDefaults(item); 
         item.setLastUpdated(LocalDateTime.now());
         item.setStatus(determineStatus(item));
         return inventoryRepository.save(item);
    }

    @Transactional
    public List<InventoryItem> saveAll(List<InventoryItem> items) {
        System.out.println(">>> [InventoryService] saveAll called for " + (items != null ? items.size() : 0) + " items.");
        if (items == null || items.isEmpty()) {
            throw new IllegalArgumentException("Item list cannot be empty");
        }
        List<InventoryItem> savedItems = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();
        for (InventoryItem i : items) {
            setDefaults(i);
            i.setLastUpdated(now);
            i.setStatus(determineStatus(i));
            InventoryItem savedItem = inventoryRepository.save(i);
            savedItems.add(savedItem);
            try {
                stockMovementService.recordMovement(savedItem, savedItem.getQuantity(), "ADD", "Bulk upload", "AdminUser");
            } catch (Exception e) {
                System.err.println("!!! [InventoryService] ERROR occurred while recording bulk ADD movement: " + e.getMessage());
                e.printStackTrace();
            }
        }
        System.out.println("<<< [InventoryService] saveAll finished.");
        return savedItems;
    }

    @Transactional
    public InventoryItem updateItem(Long id, InventoryItem updatedDetails) {
        System.out.println(">>> [InventoryService] updateItem called for ID: " + id);
        InventoryItem existingItem = inventoryRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Inventory item not found: " + id));

        if (existingItem.getStatus() == StockStatus.ARCHIVED) {
             System.err.println("!!! [InventoryService] ERROR: Cannot update an ARCHIVED item.");
             throw new RuntimeException("Cannot update an ARCHIVED item. Please restore it first.");
        }

        int oldQuantity = existingItem.getQuantity();
        System.out.println("    [InventoryService] Old Quantity: " + oldQuantity);

        existingItem.setSku(updatedDetails.getSku());
        existingItem.setName(updatedDetails.getName());
        existingItem.setDescription(updatedDetails.getDescription());
        existingItem.setQuantity(updatedDetails.getQuantity());
        existingItem.setReorderLevel(updatedDetails.getReorderLevel());
        existingItem.setLocation(updatedDetails.getLocation());
        existingItem.setWarehouse(updatedDetails.getWarehouse());
        
        // ======================================================
        // ✅✅✅ START: THIS IS THE FIX ✅✅✅
        // ======================================================
        existingItem.setShippingStatus(updatedDetails.getShippingStatus());
        existingItem.setTrackingNumber(updatedDetails.getTrackingNumber());
        // ======================================================
        // ✅✅✅ END: THIS IS THE FIX ✅✅✅
        // ======================================================
        
        existingItem.setStatus(determineStatus(existingItem)); 
        existingItem.setLastUpdated(LocalDateTime.now());

        InventoryItem savedItem = inventoryRepository.save(existingItem);
        System.out.println("    [InventoryService] Item updated. New Quantity: " + savedItem.getQuantity());

        int quantityChange = savedItem.getQuantity() - oldQuantity;
        if (quantityChange != 0) {
            System.out.println("    [InventoryService] Quantity Change: " + quantityChange);
            System.out.println("    [InventoryService] Attempting to record ADJUST movement...");
            try {
                stockMovementService.recordMovement(savedItem, quantityChange, "ADJUST", "Item updated", "AdminUser");
                System.out.println("    [InventoryService] Finished calling record movement for ADJUST.");
            } catch (Exception e) {
                 System.err.println("!!! [InventoryService] ERROR occurred while recording ADJUST movement: " + e.getMessage());
                 e.printStackTrace();
            }
        }
        return savedItem;
    }

    /**
     * ======================================================
     * ✅✅✅ THIS IS THE "SOFT DELETE" (ARCHIVE) METHOD ✅✅✅
     * ======================================================
     */
    @Transactional
    public void deleteItem(Long id) {
         System.out.println(">>> [InventoryService] archiveItem (delete) called for ID: " + id);
        InventoryItem itemToArchive = inventoryRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("InventoryItem not found with id: " + id));
         System.out.println("    [InventoryService] Found item to archive: " + itemToArchive.getName());

        // 1. Set the status to ARCHIVED
        itemToArchive.setStatus(StockStatus.ARCHIVED);
        // 2. Save the change (this is an UPDATE)
        inventoryRepository.save(itemToArchive);
         System.out.println("    [InventoryService] Item status set to ARCHIVED.");

        // 3. Record the movement (this is now safe)
         System.out.println("    [InventoryService] Attempting to record ARCHIVE movement...");
        try {
            // We record 0 quantity change, just that it was removed/archived
            stockMovementService.recordMovement(itemToArchive, 0, "REMOVE", "Item archived (deleted)", "AdminUser");
            System.out.println("    [InventoryService] Finished calling record movement for ARCHIVE.");
        } catch (Exception e) {
             System.err.println("!!! [InventoryService] ERROR occurred while recording ARCHIVE movement: " + e.getMessage());
             e.printStackTrace();
        }

        // 4. We DO NOT call inventoryRepository.deleteById(id)
         System.out.println("    [InventoryService] Item archived successfully.");
    }

    // Low stock finder
    public List<InventoryItem> findLowStock() {
        System.out.println(">>> [InventoryService] findLowStock (Active only) called.");
        return inventoryRepository.findLowStockActive();
    }

    // Adjust stock quantity
    @Transactional
    public InventoryItem adjustQuantity(Long id, int delta, String reason) {
        System.out.println(">>> [InventoryService] adjustQuantity called for ID: " + id + ", Delta: " + delta);
        InventoryItem item = inventoryRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Inventory item not found: " + id));

        if (item.getStatus() == StockStatus.ARCHIVED) {
             System.err.println("!!! [InventoryService] ERROR: Cannot adjust quantity of an ARCHIVED item.");
             throw new RuntimeException("Cannot adjust quantity of an ARCHIVED item.");
        }

        int oldQuantity = item.getQuantity();
        int newQuantity = oldQuantity + delta;
        item.setQuantity(Math.max(0, newQuantity));
        item.setLastUpdated(LocalDateTime.now());
        item.setStatus(determineStatus(item));

        InventoryItem updated = inventoryRepository.save(item);
        System.out.println("    [InventoryService] Quantity adjusted. New Quantity: " + updated.getQuantity());

        try {
            String type = delta > 0 ? "ADD" : "REMOVE";
            stockMovementService.recordMovement(updated, delta, type, reason, "System");
        } catch (Exception e) {
             System.err.println("!!! [InventoryService] ERROR occurred while recording adjust movement: " + e.getMessage());
             e.printStackTrace();
        }
        return updated;
    }

    // Summary for dashboard
    public Map<String, Object> stockSummary() {
         System.out.println(">>> [InventoryService] stockSummary (Active only) called.");
        List<InventoryItem> items = inventoryRepository.findAllActive(); 
        
        int totalItems = items.size();
        long totalQuantity = items.stream().mapToLong(InventoryItem::getQuantity).sum();
        long lowStockCount = items.stream()
                .filter(i -> i.getStatus() == StockStatus.LOW_STOCK || i.getStatus() == StockStatus.OUT_OF_STOCK)
                .count();

         List<Map<String, Object>> byItem = items.stream()
                 .map(this::mapItemToSummary)
                 .toList();

        Map<String, Object> summaryMap = new HashMap<>();
        summaryMap.put("totalItems", totalItems);
        summaryMap.put("totalQuantity", totalQuantity);
        summaryMap.put("lowStockCount", lowStockCount);
        summaryMap.put("items", byItem); // ✅ CHANGED: Use the mapped list

         System.out.println("<<< [InventoryService] stockSummary returning data.");
        return summaryMap;
    }

    // Helper to map InventoryItem
    private Map<String, Object> mapItemToSummary(InventoryItem i) {
        Map<String, Object> map = new HashMap<>();
        map.put("id", i.getId());
        map.put("sku", i.getSku());
        map.put("name", i.getName());
        map.put("quantity", i.getQuantity());
        map.put("location", i.getLocation());
        map.put("warehouse", i.getWarehouse());
        map.put("status", (i.getStatus() != null ? i.getStatus().name() : determineStatus(i).name()));
        map.put("reorderLevel", i.getReorderLevel());
        map.put("description", i.getDescription());
        map.put("lastUpdated", i.getLastUpdated() != null ? i.getLastUpdated().toString() : null);
        
        // ✅ ADDED: Also return the new fields to the summary
        map.put("shippingStatus", i.getShippingStatus() != null ? i.getShippingStatus().name() : null);
        map.put("trackingNumber", i.getTrackingNumber());
        
        return map;
    }


    // Helper method to set default values
    private void setDefaults(InventoryItem item) {
        if (item.getReorderLevel() == null) item.setReorderLevel(10);
        if (item.getQuantity() < 0) item.setQuantity(0);
        if (item.getLocation() == null || item.getLocation().trim().isEmpty()) item.setLocation("Unassigned");
        if (item.getWarehouse() == null || item.getWarehouse().trim().isEmpty()) item.setWarehouse("Unassigned");
    }

    // Helper method to determine status
      private StockStatus determineStatus(InventoryItem item) {
          if (item.getStatus() == StockStatus.ARCHIVED) {
              return StockStatus.ARCHIVED;
          }
          
          if (item.getQuantity() <= 0) {
              return StockStatus.OUT_OF_STOCK;
          } else if (item.getReorderLevel() != null && item.getQuantity() <= item.getReorderLevel()) {
              return StockStatus.LOW_STOCK;
          } else {
              return StockStatus.IN_STOCK;
          }
    }
}