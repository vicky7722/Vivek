package com.orderkraft.model;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "supplier_contract")
public class SupplierContract {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sup_contract_seq")
    @SequenceGenerator(name = "sup_contract_seq", sequenceName = "sup_contract_seq", allocationSize = 1)
    private Long id;

    @Column(name = "supplier_id")
    private Long supplierId;

    @Column(name = "file_name")
    private String fileName;        // original filename

    @Column(name = "stored_file_name")
    private String storedFileName;  // generated filename on disk

    @Column(name = "file_path")
    private String filePath;        // absolute path or relative to base dir

    @Column(name = "effective_date")
    private LocalDate effectiveDate;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;

    @Column(name = "version_no")
    private Integer versionNo;

    // getters/setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getSupplierId() { return supplierId; }
    public void setSupplierId(Long supplierId) { this.supplierId = supplierId; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getStoredFileName() { return storedFileName; }
    public void setStoredFileName(String storedFileName) { this.storedFileName = storedFileName; }

    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }

    public LocalDate getEffectiveDate() { return effectiveDate; }
    public void setEffectiveDate(LocalDate effectiveDate) { this.effectiveDate = effectiveDate; }

    public LocalDate getExpiryDate() { return expiryDate; }
    public void setExpiryDate(LocalDate expiryDate) { this.expiryDate = expiryDate; }

    public Integer getVersionNo() { return versionNo; }
    public void setVersionNo(Integer versionNo) { this.versionNo = versionNo; }
}
