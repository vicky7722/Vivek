package com.orderkraft.model;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "production_schedule")
public class ProductionSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "schedule_seq_gen")
    @SequenceGenerator(name = "schedule_seq_gen", sequenceName = "schedule_seq", allocationSize = 1)
    private Long id;

    // -----------------------------
    // BASIC SCHEDULE INFO
    // -----------------------------

    @Column(nullable = false)
    private String name;

    private LocalDate startDate;
    private LocalDate endDate;

    private String createdBy;

    private LocalDateTime createdAt = LocalDateTime.now();

    // ACTIVE, COMPLETED, ON_HOLD, CANCELLED ...
    private String status;
    
 // --- DELETE AUDIT ---
    @Column(name = "deleted")
    private Boolean deleted = false;

    private LocalDateTime deletedAt;

    @Column(length = 500)
    private String deleteReason;


    // -----------------------------
    // LEGACY AGGREGATE FIELDS
    // (KEEPING FOR BACKWARD COMPATIBILITY)
    // -----------------------------

    /**
     * Old field: flat list of all allocated machines.
     * Will be auto-filled from per-department lists via @PrePersist/@PreUpdate.
     */
    @ElementCollection
    @CollectionTable(
            name = "schedule_allocated_machines",
            joinColumns = @JoinColumn(name = "schedule_id")
    )
    @Column(name = "machine_id")
    private List<Long> allocatedMachines = new ArrayList<>();

    /**
     * Old field: total worker count.
     * Will be auto-filled based on per-department worker lists.
     */
    private Integer requiredWorkers = 0;

    // -----------------------------
    // NEW: PER-DEPARTMENT MACHINES
    // -----------------------------

    @ElementCollection
    @CollectionTable(
            name = "schedule_prod_machines",
            joinColumns = @JoinColumn(name = "schedule_id")
    )
    @Column(name = "machine_id")
    private List<Long> productionMachines = new ArrayList<>();

    @ElementCollection
    @CollectionTable(
            name = "schedule_pack_machines",
            joinColumns = @JoinColumn(name = "schedule_id")
    )
    @Column(name = "machine_id")
    private List<Long> packagingMachines = new ArrayList<>();

    @ElementCollection
    @CollectionTable(
            name = "schedule_ship_machines",
            joinColumns = @JoinColumn(name = "schedule_id")
    )
    @Column(name = "machine_id")
    private List<Long> shippingMachines = new ArrayList<>();

    // -----------------------------
    // NEW: PER-DEPARTMENT WORKERS
    // (STORE EXACT WORKER IDs)
    // -----------------------------

    @ElementCollection
    @CollectionTable(
            name = "schedule_prod_workers",
            joinColumns = @JoinColumn(name = "schedule_id")
    )
    @Column(name = "worker_id")
    private List<Long> productionWorkers = new ArrayList<>();

    @ElementCollection
    @CollectionTable(
            name = "schedule_pack_workers",
            joinColumns = @JoinColumn(name = "schedule_id")
    )
    @Column(name = "worker_id")
    private List<Long> packagingWorkers = new ArrayList<>();

    @ElementCollection
    @CollectionTable(
            name = "schedule_ship_workers",
            joinColumns = @JoinColumn(name = "schedule_id")
    )
    @Column(name = "worker_id")
    private List<Long> shippingWorkers = new ArrayList<>();

    // -----------------------------
    // CONSTRUCTORS
    // -----------------------------

    public ProductionSchedule() {
    }

    public ProductionSchedule(Long id) {
        this.id = id;
    }

    public ProductionSchedule(Long id,
                              String name,
                              LocalDate startDate,
                              LocalDate endDate,
                              String createdBy,
                              LocalDateTime createdAt,
                              String status) {
        this.id = id;
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.status = status;
    }

    // -----------------------------
    // LIFECYCLE HOOK:
    // KEEP LEGACY FIELDS IN SYNC
    // -----------------------------

    @PrePersist
    @PreUpdate
    protected void syncAggregates() {
        boolean hasDeptData =
                (productionMachines != null && !productionMachines.isEmpty())
                        || (packagingMachines != null && !packagingMachines.isEmpty())
                        || (shippingMachines != null && !shippingMachines.isEmpty())
                        || (productionWorkers != null && !productionWorkers.isEmpty())
                        || (packagingWorkers != null && !packagingWorkers.isEmpty())
                        || (shippingWorkers != null && !shippingWorkers.isEmpty());

        if (!hasDeptData) {
            // Legacy mode: frontend is only sending allocatedMachines / requiredWorkers.
            // Do NOT overwrite them.
            return;
        }

        // Merge all department machine ids into allocatedMachines
        List<Long> machines = new ArrayList<>();
        if (productionMachines != null) machines.addAll(productionMachines);
        if (packagingMachines != null) machines.addAll(packagingMachines);
        if (shippingMachines != null) machines.addAll(shippingMachines);
        this.allocatedMachines = machines;

        // Count workers across departments
        int totalWorkers = 0;
        if (productionWorkers != null) totalWorkers += productionWorkers.size();
        if (packagingWorkers != null) totalWorkers += packagingWorkers.size();
        if (shippingWorkers != null) totalWorkers += shippingWorkers.size();
        this.requiredWorkers = totalWorkers;
    }


    // -----------------------------
    // GETTERS / SETTERS
    // -----------------------------

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<Long> getAllocatedMachines() {
        return allocatedMachines;
    }

    public void setAllocatedMachines(List<Long> allocatedMachines) {
        this.allocatedMachines = allocatedMachines;
    }

    public Integer getRequiredWorkers() {
        return requiredWorkers;
    }

    public void setRequiredWorkers(Integer requiredWorkers) {
        this.requiredWorkers = requiredWorkers;
    }

    public List<Long> getProductionMachines() {
        return productionMachines;
    }

    public void setProductionMachines(List<Long> productionMachines) {
        this.productionMachines = productionMachines;
    }

    public List<Long> getPackagingMachines() {
        return packagingMachines;
    }

    public void setPackagingMachines(List<Long> packagingMachines) {
        this.packagingMachines = packagingMachines;
    }

    public List<Long> getShippingMachines() {
        return shippingMachines;
    }

    public void setShippingMachines(List<Long> shippingMachines) {
        this.shippingMachines = shippingMachines;
    }

    public List<Long> getProductionWorkers() {
        return productionWorkers;
    }

    public void setProductionWorkers(List<Long> productionWorkers) {
        this.productionWorkers = productionWorkers;
    }

    public List<Long> getPackagingWorkers() {
        return packagingWorkers;
    }

    public void setPackagingWorkers(List<Long> packagingWorkers) {
        this.packagingWorkers = packagingWorkers;
    }

    public List<Long> getShippingWorkers() {
        return shippingWorkers;
    }

    public void setShippingWorkers(List<Long> shippingWorkers) {
        this.shippingWorkers = shippingWorkers;
    }
    
    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public LocalDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(LocalDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public String getDeleteReason() {
        return deleteReason;
    }

    public void setDeleteReason(String deleteReason) {
        this.deleteReason = deleteReason;
    }

}
