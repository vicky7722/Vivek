package com.orderkraft.service;

import com.orderkraft.model.SiteUser;
import com.orderkraft.repository.SiteUserRepository;

import java.util.Collections;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;

import org.springframework.stereotype.Service;

@Service
public class SiteUserDetailsService implements UserDetailsService {

    private final SiteUserRepository repo;

    public SiteUserDetailsService(SiteUserRepository repo) {
        this.repo = repo;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        SiteUser user = repo.findByEmailAddress(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + email));
        String role = user.getRole() == null ? "USER" : user.getRole();
        return new User(
                user.getEmailAddress(),
                user.getPassword(),
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role))
        );
    }
}
