package com.orderkraft.service;

import com.orderkraft.model.Adjustment;
import com.orderkraft.repository.AdjustmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AdjustmentService {
    @Autowired private AdjustmentRepository repo;
    @Autowired private WarehouseService warehouseService; // to adjust warehouse stock
    @Autowired private InventoryService inventoryService; // to update central inventory if needed

    public Adjustment create(Long warehouseId, Long itemId, int delta, String reason){
        Adjustment a = new Adjustment();
        a.setWarehouseId(warehouseId);
        a.setItemId(itemId);
        a.setDelta(delta);
        a.setReason(reason);
        a.setCreatedAt(LocalDateTime.now());

        // adjust warehouse stock
        warehouseService.adjustStock(warehouseId, itemId, delta);
        // optionally keep central inventory synced - here we do not update central InventoryService quantity automatically,
        // but you could call inventoryService.adjustQuantity(itemId, delta) if central inventory should change too.

        return repo.save(a);
    }
}
