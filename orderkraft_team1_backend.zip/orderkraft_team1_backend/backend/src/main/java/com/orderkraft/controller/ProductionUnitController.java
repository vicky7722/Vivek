package com.orderkraft.controller;

import com.orderkraft.model.ProductionUnit;
import com.orderkraft.repository.MaintenanceScheduleRepository;
import com.orderkraft.repository.ProductionTaskRepository;
import com.orderkraft.repository.ProductionUnitRepository;
import com.orderkraft.service.ProductionUnitService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/units")
@CrossOrigin(origins = "http://localhost:4200")
public class ProductionUnitController {

    @Autowired
    private ProductionUnitRepository repo;

    @Autowired
    private ProductionTaskRepository taskRepo;

    @Autowired
    private MaintenanceScheduleRepository maintenanceRepo;

    @Autowired
    private ProductionUnitService unitService;

    // ----------------------------------------------------
    // CREATE
    // ----------------------------------------------------
    @PostMapping("/add")
    public ProductionUnit addUnit(@RequestBody ProductionUnit unit) {
        if (unit.getAvailabilityStatus() == null || unit.getAvailabilityStatus().isBlank()) {
            unit.setAvailabilityStatus("AVAILABLE");
        }
        if (unit.getCurrentLoad() == null) {
            unit.setCurrentLoad(0);
        }
        return repo.save(unit);
    }

    // ----------------------------------------------------
    // READ ALL (optionally filter by department)
    // ----------------------------------------------------
    @GetMapping("/getAll")
    public List<ProductionUnit> getAll(@RequestParam(required = false) String department) {
        List<ProductionUnit> units = repo.findAll();
        if (department == null || department.isBlank()) {
            return units;
        }
        String dep = department.trim().toUpperCase();
        return units.stream()
                .filter(u -> u.getDepartment() != null
                        && dep.equalsIgnoreCase(u.getDepartment()))
                .collect(Collectors.toList());
    }

    // ----------------------------------------------------
    // AVAILABLE UNITS FOR DATE RANGE (with optional dept)
    // ----------------------------------------------------
    @GetMapping("/available")
    public List<ProductionUnit> getAvailableUnits(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate start,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate end,
            @RequestParam(required = false) String department) {

        List<ProductionUnit> units = unitService.getAvailableUnits(start, end);
        if (department == null || department.isBlank()) {
            return units;
        }
        String dep = department.trim().toUpperCase();
        return units.stream()
                .filter(u -> u.getDepartment() != null
                        && dep.equalsIgnoreCase(u.getDepartment()))
                .collect(Collectors.toList());
    }

    // ----------------------------------------------------
    // UPDATE
    // ----------------------------------------------------
    @PutMapping("/{id}")
    public ResponseEntity<?> updateUnit(@PathVariable Long id, @RequestBody ProductionUnit payload) {
        return repo.findById(id).map(u -> {
            if (payload.getUnitName() != null) u.setUnitName(payload.getUnitName());
            if (payload.getCapacity() != null) u.setCapacity(payload.getCapacity());
//            if (payload.getUnitType() != null) u.setUnitType(payload.getUnitType());
            if (payload.getAvailabilityStatus() != null) u.setAvailabilityStatus(payload.getAvailabilityStatus());
            if (payload.getCurrentLoad() != null) u.setCurrentLoad(payload.getCurrentLoad());
            if (payload.getDepartment() != null) u.setDepartment(payload.getDepartment());
            ProductionUnit saved = repo.save(u);
            return ResponseEntity.ok(saved);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }
    
//    public ProductionUnit saveUnit(ProductionUnit unit) {
//
//        Department dept = departmentRepository
//                .findByName(unit.getDepartment().getName())
//                .orElseThrow(() -> new RuntimeException("Department not found"));
//
//        unit.setDepartment(dept);
//
//        return productionUnitRepository.save(unit);
//    }

    // ----------------------------------------------------
    // DELETE (only if no tasks & no active maintenance)
    // ----------------------------------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUnit(@PathVariable Long id) {
        // Check assigned tasks
        long assignedTasks = taskRepo.findAll().stream()
                .filter(t -> t.getUnit() != null && id.equals(t.getUnit().getId()))
                .count();
        if (assignedTasks > 0) {
            return ResponseEntity.badRequest().body("Unit has assigned tasks");
        }

        // Check active (non-cancelled) maintenance
        boolean hasMaintenance = maintenanceRepo.findByUnitId(id).stream()
                .anyMatch(m -> !"CANCELLED".equalsIgnoreCase(m.getStatus()));
        if (hasMaintenance) {
            return ResponseEntity.badRequest().body("Unit has maintenance scheduled/active");
        }

        repo.deleteById(id);
        return ResponseEntity.ok("Unit deleted");
    }
}
