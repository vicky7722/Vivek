package com.orderkraft.controller;

import com.orderkraft.model.Item;
import com.orderkraft.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/suppliers")
@CrossOrigin(origins = "http://localhost:4200")
public class SupplierItemController {

    @Autowired
    private ItemRepository itemRepo;

    // GET /api/suppliers/{supplierId}/items
    @GetMapping("/{supplierId}/items")
    public List<Item> getItems(@PathVariable Long supplierId) {
        return itemRepo.findBySupplierId(supplierId);
    }

    // POST /api/suppliers/{supplierId}/items
    @PostMapping("/{supplierId}/items")
    public Item addItem(
            @PathVariable Long supplierId,
            @RequestBody Item item
    ) {
        item.setId(null);           // force insert
        item.setSupplierId(supplierId);
        return itemRepo.save(item);
    }

    // PUT /api/suppliers/items/{itemId}
    @PutMapping("/items/{itemId}")
    public Item updateItem(
            @PathVariable Long itemId,
            @RequestBody Item payload
    ) {
        Item item = itemRepo.findById(itemId)
                .orElseThrow(() -> new RuntimeException("Item not found"));

        item.setName(payload.getName());
        item.setUnitPrice(payload.getUnitPrice());
        item.setQuantity(payload.getQuantity());

        return itemRepo.save(item);
    }

    // DELETE /api/suppliers/items/{itemId}
    @DeleteMapping("/items/{itemId}")
    public void deleteItem(@PathVariable Long itemId) {
        itemRepo.deleteById(itemId);
    }
}
