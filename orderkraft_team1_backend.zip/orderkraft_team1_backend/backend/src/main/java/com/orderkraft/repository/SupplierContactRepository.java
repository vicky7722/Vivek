package com.orderkraft.repository;

import com.orderkraft.model.SupplierContact;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SupplierContactRepository extends JpaRepository<SupplierContact, Long> {
    List<SupplierContact> findBySupplierId(Long supplierId);
}
