package com.orderkraft.controller;

import com.orderkraft.model.Adjustment;
import com.orderkraft.service.AdjustmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/adjustments")
@CrossOrigin(origins = "http://localhost:4200")
public class AdjustmentController {
    @Autowired private AdjustmentService service;

    @PostMapping("/create")
    public ResponseEntity<?> create(@RequestParam Long warehouseId, @RequestParam Long itemId, @RequestParam int delta, @RequestParam(required = false) String reason){
        Adjustment a = service.create(warehouseId, itemId, delta, reason);
        return ResponseEntity.ok(a);
    }
}
