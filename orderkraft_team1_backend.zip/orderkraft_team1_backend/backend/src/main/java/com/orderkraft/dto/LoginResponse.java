package com.orderkraft.dto;

public class LoginResponse {
	private Long id;            // <-- NEW
    private String emailAddress;
    private String username;    // <-- NEW
    private String role;
    private String status;
    
    
	public LoginResponse() {
		super();
	}
	public LoginResponse(Long id, String emailAddress, String username, String role, String status) {
		super();
		this.id = id;
		this.emailAddress = emailAddress;
		this.username = username;
		this.role = role;
		this.status = status;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

    
}
