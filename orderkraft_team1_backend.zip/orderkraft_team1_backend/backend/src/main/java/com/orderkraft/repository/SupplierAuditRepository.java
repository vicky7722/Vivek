package com.orderkraft.repository;

import com.orderkraft.model.SupplierAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SupplierAuditRepository extends JpaRepository<SupplierAudit, Long> {
    List<SupplierAudit> findBySupplierIdOrderByCreatedAtDesc(Long supplierId);
}
