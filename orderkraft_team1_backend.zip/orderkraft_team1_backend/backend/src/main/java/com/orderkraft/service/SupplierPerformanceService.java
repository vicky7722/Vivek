package com.orderkraft.service;

import com.orderkraft.dto.SupplierPerformanceDTO;
import com.orderkraft.model.PurchaseOrder;
import com.orderkraft.repository.PurchaseOrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SupplierPerformanceService {

    @Autowired private PurchaseOrderRepository poRepo;

    public SupplierPerformanceDTO computeForSupplier(Long supplierId, int monthsBack) {
        LocalDate now = LocalDate.now();
        LocalDate from = now.minusMonths(monthsBack);

        List<PurchaseOrder> orders = poRepo.findBySupplierIdOrderByCreatedDateDesc(supplierId)
                .stream()
                .filter(po -> po.getCreatedDate() != null && !po.getCreatedDate().isBefore(from))
                .collect(Collectors.toList());

        Map<YearMonth, List<PurchaseOrder>> byMonth = new HashMap<>();
        for (PurchaseOrder po : orders) {
            YearMonth ym = YearMonth.from(po.getCreatedDate());
            byMonth.computeIfAbsent(ym, k -> new ArrayList<>()).add(po);
        }

        List<SupplierPerformanceDTO.MonthPoint> months = new ArrayList<>();
        for (int i = monthsBack - 1; i >= 0; i--) {
            YearMonth ym = YearMonth.now().minusMonths(i);
            List<PurchaseOrder> list = byMonth.getOrDefault(ym, Collections.emptyList());
            double onTimePct = computeOnTimePct(list);
            String label = ym.getMonth().toString().substring(0,3) + " " + ym.getYear();
            months.add(new SupplierPerformanceDTO.MonthPoint(label, onTimePct));
        }

        double overallOnTime = computeOnTimePct(orders);
        double avgLead = computeAvgLeadDays(orders);
        double defectRate = computeDefectRate(orders);

        SupplierPerformanceDTO dto = new SupplierPerformanceDTO();
        dto.setSupplierId(supplierId);
        dto.setMonths(months);
        dto.setOnTimePct(overallOnTime);
        dto.setAvgLeadTimeDays(avgLead);
        dto.setDefectRate(defectRate);
        return dto;
    }

    private double computeOnTimePct(List<PurchaseOrder> orders) {
        if (orders == null || orders.isEmpty()) return 0.0;
        long total = orders.size();
        long onTime = orders.stream().filter(po -> {
            // treat a non-null deliveredDate as "on-time" for now
            return po.getDeliveredDate() != null;
        }).count();
        return Math.round((onTime * 10000.0 / total)) / 100.0;
    }

    private double computeAvgLeadDays(List<PurchaseOrder> orders) {
        List<Long> leadDays = orders.stream()
                .filter(po -> po.getCreatedDate() != null && po.getDeliveredDate() != null)
                .map(po -> java.time.temporal.ChronoUnit.DAYS.between(po.getCreatedDate(), po.getDeliveredDate()))
                .collect(Collectors.toList());
        if (leadDays.isEmpty()) return 0.0;
        double avg = leadDays.stream().mapToLong(Long::longValue).average().orElse(0.0);
        return Math.round(avg * 100.0) / 100.0;
    }

    private double computeDefectRate(List<PurchaseOrder> orders) {
        // placeholder: requires defect info; returning 0
        return 0.0;
    }
}
