package com.orderkraft.dto;

// This DTO maps the JSON from the Angular frontend
// { "itemId": 123, "quantityReturned": 1, "reason": "..." }
public class ReturnItemDTO {

    private Long itemId;
    private int quantityReturned;
    private String reason;

    // Getters and Setters
    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public int getQuantityReturned() {
        return quantityReturned;
    }

    public void setQuantityReturned(int quantityReturned) {
        this.quantityReturned = quantityReturned;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}