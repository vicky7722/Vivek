package com.orderkraft.controller;

import com.orderkraft.model.PasswordResetToken;
import com.orderkraft.model.SiteUser;
import com.orderkraft.payload.ApiResponse;
import com.orderkraft.payload.request.ForgotPasswordRequest;
import com.orderkraft.payload.request.ResetPasswordRequest;
import com.orderkraft.repository.SiteUserRepository;
import com.orderkraft.service.EmailService;
import com.orderkraft.service.PasswordResetService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final SiteUserRepository userRepo;
    private final PasswordResetService resetService;
    private final EmailService emailService;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.frontend.reset-url-template:http://localhost:4200/reset-password/%s}")
    private String resetUrlTemplate;

    public AuthController(SiteUserRepository userRepo,
                          PasswordResetService resetService,
                          EmailService emailService,
                          PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.resetService = resetService;
        this.emailService = emailService;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@Validated @RequestBody ForgotPasswordRequest req) {

        Optional<SiteUser> uOpt = userRepo.findByEmailAddress(req.getEmail());
        if (uOpt.isEmpty()) {
            return ResponseEntity.ok(new ApiResponse(true,
                "If an account exists, an email has been sent."));
        }

        SiteUser user = uOpt.get();

        // Create token + OTP
        PasswordResetToken token = resetService.createTokenForUser(user);

        String resetId = token.getToken();
        String otp = token.getOtp();

        // FULL Reset URL including resetId + otp
        String resetUrl = "http://localhost:4200/reset-password/" + resetId + "?otp=" + otp;

        try {
            emailService.sendPasswordResetEmail(user.getEmailAddress(), resetId, otp, resetUrl);
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(500).body(new ApiResponse(false, "Failed to send email"));
        }

        return ResponseEntity.ok(new ApiResponse(true,
            "If an account exists, an email has been sent."));
    }




    @PostMapping("/reset-password")
    @Transactional
    public ResponseEntity<?> resetPassword(@Validated @RequestBody ResetPasswordRequest req) {
        PasswordResetToken token = resetService.findByToken(req.getToken());
        if (token == null || token.isExpired()) {
            if (token != null) resetService.invalidateToken(token);
            return ResponseEntity.badRequest().body(new ApiResponse(false, "Invalid or expired token"));
        }

        SiteUser user = token.getUser();
        user.setPassword(passwordEncoder.encode(req.getNewPassword()));
        userRepo.save(user);

        resetService.invalidateAllForUser(user);

        return ResponseEntity.ok(new ApiResponse(true, "Password has been reset successfully"));
    }

    @GetMapping("/validate-reset")
    public ResponseEntity<?> validateToken(@RequestParam("token") String tokenStr) {
        PasswordResetToken token = resetService.findByToken(tokenStr);
        if (token == null || token.isExpired()) {
            return ResponseEntity.badRequest().body(new ApiResponse(false, "Invalid or expired token"));
        }
        return ResponseEntity.ok(new ApiResponse(true, "Token OK"));
    }
}
