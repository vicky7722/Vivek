package com.orderkraft.service;

import com.orderkraft.model.MaintenanceSchedule;
import com.orderkraft.model.ProductionSchedule;
import com.orderkraft.model.ProductionUnit;
import com.orderkraft.repository.MaintenanceScheduleRepository;
import com.orderkraft.repository.ProductionScheduleRepository;
import com.orderkraft.repository.ProductionUnitRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProductionUnitService {
	
	@Autowired
	private MaintenanceScheduleRepository maintenanceRepo;

    @Autowired
    private ProductionUnitRepository unitRepo;

    @Autowired
    private ProductionScheduleRepository scheduleRepo;

    /**
     * Returns units that are AVAILABLE, not at full capacity, and not already allocated
     * in any non-cancelled schedule that overlaps the given date range.
     */
    
    public void syncMaintenanceUnits() {

        List<ProductionUnit> units = unitRepo.findAll();

        for (ProductionUnit unit : units) {

            if ("MAINTENANCE".equalsIgnoreCase(unit.getAvailabilityStatus())) {

                boolean alreadyExists =
                        maintenanceRepo.existsByUnitIdAndStatus(unit.getId(), "ACTIVE");

                if (!alreadyExists) {

                    MaintenanceSchedule ms = new MaintenanceSchedule();

                    ms.setUnitId(unit.getId());
                    ms.setStartTime(LocalDateTime.now());
                    ms.setEndTime(LocalDateTime.now().plusDays(1));
                    ms.setReason("Automatic maintenance detection");
                    ms.setStatus("ACTIVE");

                    maintenanceRepo.save(ms);
                }
            }
        }
    }
    
    
    public List<ProductionUnit> getAvailableUnits(LocalDate start, LocalDate end) {
        List<ProductionUnit> all = unitRepo.findAll();
        List<ProductionUnit> free = new ArrayList<>();

        for (ProductionUnit u : all) {
            // must be marked available in the DB
            if (u.getAvailabilityStatus() == null ||
                !"AVAILABLE".equalsIgnoreCase(u.getAvailabilityStatus())) {
                continue;
            }

            // must have capacity left
            Integer capacity = u.getCapacity() == null ? 0 : u.getCapacity();
            Integer load = u.getCurrentLoad() == null ? 0 : u.getCurrentLoad();
            if (capacity > 0 && load >= capacity) {
                continue;
            }

            // check schedule overlap: if any non-cancelled schedule that uses this machine overlaps requested dates -> skip
            List<ProductionSchedule> schedulesUsing = scheduleRepo.findSchedulesByMachineId(u.getId());
            boolean conflict = schedulesUsing.stream().anyMatch(s -> {
                // ignore cancelled schedules
                if (s.getStatus() != null && s.getStatus().equalsIgnoreCase("CANCELLED")) return false;

                // if schedule start/end null, treat as conflict-safe -> assume overlap (be conservative)
                if (s.getStartDate() == null || s.getEndDate() == null) return true;

                // overlap condition:
                // NOT (existing.end < start OR existing.start > end) -> overlap
                return !(s.getEndDate().isBefore(start) || s.getStartDate().isAfter(end));
            });

            if (!conflict) {
                free.add(u);
            }
        }

        return free;
    }
}
