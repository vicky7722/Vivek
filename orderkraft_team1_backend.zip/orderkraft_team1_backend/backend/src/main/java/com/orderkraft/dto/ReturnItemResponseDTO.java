package com.orderkraft.dto;

import com.orderkraft.model.ReturnItem;
import java.time.LocalDateTime;

// This DTO is sent back to Angular to display in the "Returns" table
public class ReturnItemResponseDTO {

    private Long id;
    private int quantityReturned;
    private String reason;
    private LocalDateTime timestamp;
    private ItemSummaryDTO item; // Nested DTO for a clean response

    // This constructor makes it easy to convert an Entity to a DTO
    public ReturnItemResponseDTO(ReturnItem returnItem) {
        this.id = returnItem.getId();
        this.quantityReturned = returnItem.getQuantityReturned();
        this.reason = returnItem.getReason();
        this.timestamp = returnItem.getTimestamp();
        // Create the nested ItemSummaryDTO from the full InventoryItem
        if (returnItem.getItem() != null) {
            this.item = new ItemSummaryDTO(
                returnItem.getItem().getSku(),
                returnItem.getItem().getName()
            );
        }
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public int getQuantityReturned() { return quantityReturned; }
    public void setQuantityReturned(int quantityReturned) { this.quantityReturned = quantityReturned; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    public ItemSummaryDTO getItem() { return item; }
    public void setItem(ItemSummaryDTO item) { this.item = item; }

    /**
     * A simple inner class to hold basic item info.
     * The `record` type automatically creates getters, constructors, etc.
     */
    private record ItemSummaryDTO(String sku, String name) {}
}