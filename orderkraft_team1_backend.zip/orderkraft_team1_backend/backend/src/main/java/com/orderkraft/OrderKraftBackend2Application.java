package com.orderkraft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling   // 🔔 Enables @Scheduled jobs (including maintenance auto-updater)
public class OrderKraftBackend2Application {

    public static void main(String[] args) {
        SpringApplication.run(OrderKraftBackend2Application.class, args);
    }
}
