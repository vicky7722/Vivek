package com.orderkraft.service.impl;

import com.orderkraft.service.EmailService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender mailSender;
    private final String fromAddress;

    @Value("${app.frontend.base-url:http://localhost:4200}")
    private String frontendBaseUrl;

    public EmailServiceImpl(JavaMailSender mailSender,
                            @Value("${spring.mail.username:orderkraft@example.com}") String fromAddress) {
        this.mailSender = mailSender;
        this.fromAddress = fromAddress;
    }

    @Override
    public void sendPasswordResetEmail(String toEmail, String resetId, String otp, String resetUrl) {
        String subject = "OrderKraft: Password reset request";

        String body = """
            Hello,

            You requested a password reset.

            OTP: %s

            Reset Reference ID: %s

            Reset Password Link:
            %s

            If you did not request this, ignore this message.

            Regards,
            OrderKraft Team
            """.formatted(otp, resetId, resetUrl);

        sendSimple(toEmail, subject, body);
    }


    @Override
    public void sendAccountUnlockedEmail(String toEmail) {
        sendSimple(toEmail,
                "OrderKraft: Account unlocked",
                "Your account has been unlocked. You can try logging in again.");
    }

    private void sendSimple(String to, String subject, String text) {
        try {
            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setFrom(fromAddress);
            msg.setTo(to);
            msg.setSubject(subject);
            msg.setText(text);
            mailSender.send(msg);
        } catch (MailException ignored) {}
    }
}
