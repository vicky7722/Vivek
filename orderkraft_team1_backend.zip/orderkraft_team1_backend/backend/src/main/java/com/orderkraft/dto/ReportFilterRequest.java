package com.orderkraft.dto;

import java.time.LocalDate;

public class ReportFilterRequest {

    private String type;        // e.g. "PERFORMANCE"
    private Long unitId;        // optional
    private LocalDate fromDate; // optional
    private LocalDate toDate;   // optional

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public Long getUnitId() { return unitId; }
    public void setUnitId(Long unitId) { this.unitId = unitId; }

    public LocalDate getFromDate() { return fromDate; }
    public void setFromDate(LocalDate fromDate) { this.fromDate = fromDate; }

    public LocalDate getToDate() { return toDate; }
    public void setToDate(LocalDate toDate) { this.toDate = toDate; }
}
