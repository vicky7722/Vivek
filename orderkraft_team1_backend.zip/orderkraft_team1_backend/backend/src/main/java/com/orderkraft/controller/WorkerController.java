package com.orderkraft.controller;

import com.orderkraft.model.Worker;
import com.orderkraft.service.WorkerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


@RestController
@RequestMapping("/api/resources/workers")
@CrossOrigin(origins = "http://localhost:4200")
public class WorkerController {

    private final WorkerService service;

    public WorkerController(WorkerService service) {
        this.service = service;
    }

    @GetMapping
    public List<Worker> all(@RequestParam(required = false) String department) {
        List<Worker> workers = service.getAll();
        if (department == null || department.isBlank()) {
            return workers;
        }
        String dep = department.trim().toUpperCase();
        return workers.stream()
                .filter(w -> w.getDepartment() != null
                        && dep.equalsIgnoreCase(w.getDepartment()))
                .collect(Collectors.toList());
    }

    @PostMapping("/add")
    public ResponseEntity<?> add(@RequestBody Worker worker) {

        try {

            if(worker.getName()==null || worker.getName().isBlank()){
                return ResponseEntity.badRequest().body("Worker name required");
            }

            if(worker.getDepartment()==null || worker.getDepartment().isBlank()){
                return ResponseEntity.badRequest().body("Department required");
            }

            if(worker.getAvailabilityStatus()==null){
                worker.setAvailabilityStatus("AVAILABLE");
            }

            Worker saved = service.add(worker);

            return ResponseEntity.ok(saved);

        } catch(Exception e){

            e.printStackTrace();   // 🔴 shows real error in backend console
            return ResponseEntity.internalServerError().body(e.getMessage());

        }

    }
    
    
    @PostMapping("/{workerId}/assign-machine/{machineId}")
    public ResponseEntity<?> assignMachine(@PathVariable Long workerId,
                                           @PathVariable Long machineId) {
        try {
            Worker updated = service.assignMachineToWorker(workerId, machineId);
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().body(ex.getMessage());
        }
    }

}
