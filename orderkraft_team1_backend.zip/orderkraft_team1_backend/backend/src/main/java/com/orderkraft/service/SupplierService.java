package com.orderkraft.service;

import com.orderkraft.model.Supplier;
import com.orderkraft.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SupplierService {

    @Autowired
    private SupplierRepository supplierRepository;

    // ------------------------ Supplier CRUD ----------------------------

    public Supplier create(Supplier s) {
        return supplierRepository.save(s);
    }

    public Supplier update(Long id, Supplier payload) {
        return supplierRepository.findById(id).map(existing -> {

            existing.setName(payload.getName());
            existing.setEmail(payload.getEmail());
            existing.setPhone(payload.getPhone());
            existing.setNotes(payload.getNotes());
            existing.setRating(payload.getRating());
            existing.setTags(payload.getTags());

            return supplierRepository.save(existing);

        }).orElseThrow(() -> new NoSuchElementException("Supplier not found"));
    }

    public Page<Supplier> list(int page, int size, String q) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("name").ascending());

        if (q == null || q.isEmpty()) {
            return supplierRepository.findAll(pageable);
        }

        return supplierRepository.findByNameContainingIgnoreCase(q, pageable);
    }

    public Optional<Supplier> get(Long id) {
        return supplierRepository.findById(id);
    }

    public void delete(Long id) {
        supplierRepository.deleteById(id);
    }
}
