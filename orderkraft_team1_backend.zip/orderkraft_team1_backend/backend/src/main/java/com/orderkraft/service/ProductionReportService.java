package com.orderkraft.service;

import com.orderkraft.dto.ReportFilterRequest;
import com.orderkraft.model.ProductionReport;
import com.orderkraft.model.ProductionTask;
import com.orderkraft.repository.ProductionReportRepository;
import com.orderkraft.repository.ProductionTaskRepository;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductionReportService {

    private final ProductionReportRepository repo;
    private final ProductionTaskRepository taskRepo;

    public ProductionReportService(ProductionReportRepository repo,
                                   ProductionTaskRepository taskRepo) {
        this.repo = repo;
        this.taskRepo = taskRepo;
    }

    public ProductionReport generateReport(ReportFilterRequest filter, String user) {

        // 1) Load & filter tasks in memory (simple but fine for demo)
        List<ProductionTask> allTasks = taskRepo.findAll();

        LocalDate from = filter.getFromDate();
        LocalDate to = filter.getToDate();

        List<ProductionTask> tasks = allTasks.stream()
                .filter(t -> t.getDeadline() != null)
                .filter(t -> from == null || !t.getDeadline().isBefore(from))
                .filter(t -> to == null || !t.getDeadline().isAfter(to))
                .collect(Collectors.toList());

        // 2) Write CSV under /reports
        try {
            Path dir = Paths.get("reports");
            if (Files.notExists(dir)) {
                Files.createDirectories(dir);
            }

            String type = (filter.getType() != null && !filter.getType().isEmpty())
                    ? filter.getType()
                    : "REPORT";

            String fileName = type + "_" + System.currentTimeMillis() + ".csv";
            Path path = dir.resolve(fileName);

            StringBuilder sb = new StringBuilder();
            sb.append("TaskId,Name,Deadline,Progress,Status\n");
            for (ProductionTask t : tasks) {
                sb.append(t.getId()).append(',')
                  .append(escape(t.getTaskName())).append(',')
                  .append(t.getDeadline()).append(',')
                  .append(t.getProgress() == null ? 0 : t.getProgress()).append(',')
                  .append(escape(t.getStatus()))
                  .append('\n');
            }

            // Java 8 compatible write:
            Files.write(path,
                    sb.toString().getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE_NEW);

            // 3) Persist report metadata
            ProductionReport r = new ProductionReport();
            r.setReportType(type);
            r.setGeneratedBy(user);
            r.setGeneratedDate(LocalDateTime.now());
            r.setFilePath(path.toString());

            return repo.save(r);

        } catch (IOException e) {
            throw new RuntimeException("Failed to generate report", e);
        }
    }

    private String escape(String s) {
        if (s == null) return "";
        return '"' + s.replace("\"", "\"\"") + '"';
    }

    public List<ProductionReport> getAll() {
        return repo.findAll();
    }
}
