package com.orderkraft.service;

import com.orderkraft.model.*;
import com.orderkraft.repository.*;
import com.orderkraft.util.LocalFileStorageService;
import com.orderkraft.dto.SupplierHistoryDTO;
import com.orderkraft.dto.SupplierPerformanceDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SupplierAuxService {

    @Autowired private SupplierContactRepository contactRepo;
    @Autowired private SupplierContractRepository contractRepo;
    @Autowired private SupplierPaymentRepository paymentRepo;
    @Autowired private LocalFileStorageService fileStorage;

    // Contacts
    public List<SupplierContact> getContacts(Long supplierId) {
        return contactRepo.findBySupplierId(supplierId);
    }
    public SupplierContact addContact(SupplierContact c) { return contactRepo.save(c); }
    public SupplierContact updateContact(Long id, SupplierContact c) { c.setId(id); return contactRepo.save(c); }
    public void deleteContact(Long id) { contactRepo.deleteById(id); }

    // Contracts
    public List<SupplierContract> getContracts(Long supplierId) {
        return contractRepo.findBySupplierIdOrderByVersionNoDesc(supplierId);
    }

    public SupplierContract saveContract(Long supplierId, MultipartFile file, LocalDate effective, LocalDate expiry) {
        String storedFileName = fileStorage.storeFile(supplierId, file);
        Path path = fileStorage.getContractFolder(supplierId).resolve(storedFileName);

        SupplierContract c = new SupplierContract();
        c.setSupplierId(supplierId);
        c.setFileName(file.getOriginalFilename());
        c.setStoredFileName(storedFileName);
        c.setFilePath(path.toString());
        c.setEffectiveDate(effective);
        c.setExpiryDate(expiry);
        // determine version: latest versionNo + 1
        Integer latestVersion = contractRepo.findBySupplierIdOrderByVersionNoDesc(supplierId)
                .stream().findFirst().map(SupplierContract::getVersionNo).orElse(0);
        c.setVersionNo((latestVersion == null ? 0 : latestVersion) + 1);
        return contractRepo.save(c);
    }

    // Payments
    public List<SupplierPayment> getPayments(Long supplierId) { return paymentRepo.findBySupplierId(supplierId); }
    public SupplierPayment savePayment(SupplierPayment p) { return paymentRepo.save(p); }

    // File access
    public Path loadContractFile(Long supplierId, String storedFileName) {
        return fileStorage.loadFile(supplierId, storedFileName);
    }

    // PERFORMANCE & HISTORY (skeletons - you must hook into orders/delivery tables)
    public SupplierPerformanceDTO computePerformanceForSupplier(Long supplierId) {
        // TODO: replace with real aggregation queries on orders/delivery tables
        // returning dummy values if no data
        SupplierPerformanceDTO dto = new SupplierPerformanceDTO();
        dto.setSupplierId(supplierId);
        dto.setOnTimePct(0.0);
        dto.setDefectRate(0.0);
        dto.setAvgLeadTimeDays(0.0);
        // Example: actually compute using joins and aggregate functions
        return dto;
    }

    public List<SupplierHistoryDTO> getHistoryForSupplier(Long supplierId) {
        // TODO: query order & delivery tables and map to SupplierHistoryDTO
        return List.of(); // empty list for now
    }
}
