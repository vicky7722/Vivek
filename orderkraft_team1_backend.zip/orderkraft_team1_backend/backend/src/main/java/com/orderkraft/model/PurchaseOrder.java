package com.orderkraft.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "purchase_order")
public class PurchaseOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "po_seq")
    @SequenceGenerator(name = "po_seq", sequenceName = "po_seq", allocationSize = 1)
    private Long id;

    @Column(name = "po_no", unique = true)
    private String poNo;

    @Column(name = "supplier_id")
    private Long supplierId;

    // Financials
    private BigDecimal amount;

    // Basic status (PENDING, PAID, DISPATCHED, DELIVERED, RETURNED, CANCELLED, COMPLETED)
    private String status;

    // Dates
    @Column(name = "created_date")
    private LocalDate createdDate;

    @Column(name = "processed_at")
    private LocalDate processedAt;

    @Column(name = "dispatched_date")
    private LocalDate dispatchedDate;

    @Column(name = "delivered_date")
    private LocalDate deliveredDate;

    @Column(name = "cancelled_date")
    private LocalDate cancelledDate;

    @Column(name = "return_date")
    private LocalDate returnDate;

    // Item details (single-line simplified). You can later expand to items table.
    private String item;
    private Integer quantity;
    private BigDecimal unitPrice;

    // Cancel / Return metadata
    @Column(length = 1000)
    private String cancelReason;

    @Column(name = "return_quantity")
    private Integer returnQuantity;

    @Column(length = 1000)
    private String returnReason;

    // Payment
    @Column(name = "payment_status")
    private String paymentStatus; // PENDING / PAID / FAILED

    // Constructors
    public PurchaseOrder() {}

    // Getters / Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getPoNo() { return poNo; }
    public void setPoNo(String poNo) { this.poNo = poNo; }

    public Long getSupplierId() { return supplierId; }
    public void setSupplierId(Long supplierId) { this.supplierId = supplierId; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDate getCreatedDate() { return createdDate; }
    public void setCreatedDate(LocalDate createdDate) { this.createdDate = createdDate; }

    public LocalDate getProcessedAt() { return processedAt; }
    public void setProcessedAt(LocalDate processedAt) { this.processedAt = processedAt; }

    public LocalDate getDispatchedDate() { return dispatchedDate; }
    public void setDispatchedDate(LocalDate dispatchedDate) { this.dispatchedDate = dispatchedDate; }

    public LocalDate getDeliveredDate() { return deliveredDate; }
    public void setDeliveredDate(LocalDate deliveredDate) { this.deliveredDate = deliveredDate; }

    public LocalDate getCancelledDate() { return cancelledDate; }
    public void setCancelledDate(LocalDate cancelledDate) { this.cancelledDate = cancelledDate; }

    public LocalDate getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }

    public String getItem() { return item; }
    public void setItem(String item) { this.item = item; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice) { this.unitPrice = unitPrice; }

    public String getCancelReason() { return cancelReason; }
    public void setCancelReason(String cancelReason) { this.cancelReason = cancelReason; }

    public Integer getReturnQuantity() { return returnQuantity; }
    public void setReturnQuantity(Integer returnQuantity) { this.returnQuantity = returnQuantity; }

    public String getReturnReason() { return returnReason; }
    public void setReturnReason(String returnReason) { this.returnReason = returnReason; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }
}
