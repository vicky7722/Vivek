package com.orderkraft.dto;

import java.util.ArrayList;
import java.util.List;

public class ValidationResult {

    private boolean valid = true;
    private List<String> errors = new ArrayList<>();

    public ValidationResult() {
    }

    public ValidationResult(boolean valid) {
        this.valid = valid;
    }

    // Convenience: add one error and mark as invalid
    public void addError(String message) {
        if (message == null || message.isBlank()) {
            return;
        }
        this.valid = false;
        this.errors.add(message);
    }

    // ---- Getters / setters ----

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = (errors != null) ? errors : new ArrayList<>();
        this.valid = this.errors.isEmpty();
    }

    /**
     * Optional helper used by Angular when it wants a single string.
     */
    public String getMessage() {
        if (valid) {
            return "OK";
        }
        return String.join("; ", errors);
    }
}
