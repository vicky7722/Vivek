package staticInnerClass1;
import java.util.*;
import java.text.*;
public class Main {
public static void main(String[] args){

     Scanner sc=new Scanner(System.in);
     DecimalFormat df=new DecimalFormat("0.00");
     System.out.println("Enter the ticket type\n1.Platinum\n2.Gold\n3.Silver");
     int input=sc.nextInt();
     int noOfSeats;
     switch (input)
     {
          case 1:
          System.out.println("Enter the no. of seats");
          Ticket.noOfSeats=sc.nextInt();
          System.out.println("Cost of the tickets is Rs."+df.format(Ticket.Platinum.computeCost()));
          break;
          
          case 2:
          System.out.println("Enter the no. of seats");
          Ticket.noOfSeats=sc.nextInt();
          System.out.println("Cost of the tickets is Rs."+df.format(Ticket.Gold.computeCost()));
          break;
          
          case 3:
          System.out.println("Enter the no. of seats");
          Ticket.noOfSeats=sc.nextInt();
          System.out.println("Cost of the tickets is Rs."+df.format(Ticket.Silver.computeCost()));
          break;
          default:
          System.out.println("Invalid choice");
     
     
     }
   }
} 