package staticInnerClass1;
public class Ticket {
	public static int noOfSeats;
public static class Platinum{
	public static Double computeCost() {
		return 210.50*noOfSeats;
	}
}
public static class Gold{
	public static Double computeCost() {
		return 168.45*noOfSeats;
	}
}
public static class Silver{
	public static Double computeCost() {
		return 107.37*noOfSeats;
	}
}
}

