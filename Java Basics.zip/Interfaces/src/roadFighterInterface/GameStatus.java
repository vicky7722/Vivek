package roadFighterInterface;
public interface GameStatus {
    public void status();
}