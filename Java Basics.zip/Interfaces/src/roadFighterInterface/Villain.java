package roadFighterInterface;
public class Villain implements GameStatus{
    private Integer damage;
 
    public Villain(Integer damage) {
        this.damage = damage;
    }
 
    public Integer getDamage() {
        return damage;
    }
 
    public void setDamage(Integer damage) {
        this.damage = damage;
    }
    public void status() {
        if(damage == 100){
            System.out.println("The Villain Damage level is :100\n----GAME OVER----\nYOU WINS!!!");
        }
        else{
            System.out.println("The Villain Damage level is :"+damage);
        }
    }
 
}