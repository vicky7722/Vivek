package roadFighterInterface;
public class Hero implements GameStatus{
    private Integer life;
 
    public Hero(Integer life) {
        this.life = life;
    }
 
    public Integer getLife() {
        return life;
    }
 
    public void setLife(Integer life) {
        this.life = life;
    }
 
    public void status() {
        if(life <1){
            System.out.println("You have 0 lives left\nYou lose the GAME !!!");
        }
        else{
            System.out.println("You have "+life+" lives left");
        }
    }
}