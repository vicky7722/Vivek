package javaInterfaces;
interface MaintainanceCharge{
	public abstract Float calculateMaintanceCharge(Float noOfYears);
}
 