package javaInterfaces;
class SavingsAccount implements MaintainanceCharge{
	public Float calculateMaintanceCharge(Float noOfYears) {
		return (2*50*noOfYears)+50;
	}
}
 


