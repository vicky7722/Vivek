package javaInterfaces;
public class CurrentAccount implements MaintainanceCharge{
	public Float calculateMaintanceCharge(Float noOfYears) {
		return (100*noOfYears)+200;
	}
}