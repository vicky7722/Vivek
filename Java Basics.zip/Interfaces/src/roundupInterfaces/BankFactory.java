package roundupInterfaces;
public class BankFactory {
	ICICI icici =new ICICI();
	HDFC hdfc =new HDFC();
	public ICICI getIcici() {
		return icici;
	}
	public HDFC getHdfc() {
		return hdfc;
	}
}
