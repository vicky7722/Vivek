package multipleInheritancewithinterfaces;
public interface BikeSpeed {
	int averageSpeed();
	
}