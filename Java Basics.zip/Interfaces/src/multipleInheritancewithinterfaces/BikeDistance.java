package multipleInheritancewithinterfaces;

public interface BikeDistance {
	int totalDistance();
}
