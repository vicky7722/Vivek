package staticInnerClass;

public class Shape {
	public static double value1;
	public static double value2;
public static class Rectangle{
	private double value1;
	private double value2;
	public Double computeRectangleArea() {
		return value1*value2;
	}
	public void setValue1(double value1) {
		this.value1=value1;
	}
	public double getValue1() {
		return value1;
	}
	public void setValue2(double value2) {
		this.value2=value2;
	}
	public double getValue2() {
		return value2;
	}
}
public static class Triangle{
	private double value1;
	private double value2;
	public Double computeTriangleArea() {
		return 0.5*value1*value2;
	}
	public void setValue1(double value1) {
		this.value1=value1;
	}
	public double getValue1() {
		return value1;
	}
	public void setValue2(double value2) {
		this.value2=value2;
	}
	public double getValue2() {
		return value2;
	}
}
}
