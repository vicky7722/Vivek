package interface1;
public interface Stall {
	void display();
}
