package nestedclasses;
public class Stall 
{
        public String name,detail,owner;
        public Integer cost;
 
        Stall(String name, String detail, String owner, Integer cost)
        {
                this.name = name;
                this.detail = detail;
                this.owner = owner;
                this.cost = cost;
        }
 
        public class GoldStall
        {
                public Integer tvSet;
                public GoldStall(Integer tvSet)
                {
                        this.tvSet = tvSet;
                }
 
                public class PlatinumStall
                {
                        public Integer projector;
                        public PlatinumStall(Integer projector)
                        {
                                this.projector = projector;
                        }
 
                        public void display()
                        {
                                System.out.println("Stall Name:"+name );
                                System.out.println("Details:"+detail);
                                System.out.println("Owner Name:"+owner);
                                System.out.println("TV Sets:"+tvSet);
                                System.out.println("Projectors:"+projector);
                                int total_cost = cost+ tvSet*100 + projector*500;
                                System.out.println("Total Cost:"+total_cost);
                        }
                }
        }
 
        
        
}