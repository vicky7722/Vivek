package abstractClass;
public class StageEvent extends Event{
	private double costPerShow;
	private int noOfShows;
	
    
    //Fill your code here


    public StageEvent(String name, String detail, String type, String organiser, int noOfShows, double costPerShow) {
		super(name, detail, type, organiser);
		this.noOfShows = noOfShows;
		this.costPerShow = costPerShow;
	}


	public Double calculateAmount() {

        //Fill your code here

        return noOfShows*costPerShow;

    }


	public int getNoOfShows() {
		return noOfShows;
	}


	public void setNoOfShows(int noOfShows) {
		this.noOfShows = noOfShows;
	}


	public double getCostPerShow() {
		return costPerShow;
	}


	public void setCostPerShow(int costPerShow) {
		this.costPerShow = costPerShow;
	}  
	
}