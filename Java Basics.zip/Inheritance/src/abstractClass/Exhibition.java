package abstractClass;
public class Exhibition extends Event{
	private int noOfStalls;
	private double rentPerStall;
    public Exhibition(String name, String detail, String type, String organiser, int noOfStalls, double rentPerStall) {
		super(name, detail, type, organiser);
		this.noOfStalls = noOfStalls;
		this.rentPerStall = rentPerStall;
	}
    
	//Fill your code here

    public int getNoOfStalls() {
		return noOfStalls;
	}

	public void setNoOfStalls(int noOfStalls) {
		this.noOfStalls = noOfStalls;
	}

	public double getRentPerStall() {
		return rentPerStall;
	}

	public void setRentPerStall(double rentPerStall) {
		this.rentPerStall = rentPerStall;
	}

	public Double calculateAmount() {
		
        //Fill your code here

        return noOfStalls*rentPerStall;
    }
     	
}