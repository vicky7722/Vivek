package calculateRewardPoints;
public class VISACard {
	
	public Double computeRewardPoints(String type, Double amount){
        double fna=(amount*0.01);
            return fna;
    }

}
