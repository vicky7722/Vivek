package calculateRewardPoints;
class HPVISACard extends VISACard{
    public Double computeRewardPoints(String type, Double amount){
			
        //fill code here
        double fa=((amount*0.01)+10);
        double fna=(amount*0.01);
        if(type.equalsIgnoreCase("Fuel")){
            return fa;
        }
        else{
            return fna;
        }
    }
}
