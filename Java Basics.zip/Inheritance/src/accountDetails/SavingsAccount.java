package accountDetails;
class SavingsAccount extends Account{
	private double interestRate;
	public void display() {
		super.display();
		System.out.println("Interest Rate : "+String.format("%.2f",interestRate));
	}
	public double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	public SavingsAccount(String holderName, long accountNumber, String iFSCCode, long contactNumber,
			double interestRate) {
		super(holderName, accountNumber, iFSCCode, contactNumber);
		this.interestRate = interestRate;
	}
	

}