package studentFeedbacksingleInheritance;
public class Student {
	public int id;
	public String name;
	public String department;
	public int courseId;
	public Student(int id, String name, String department, int courseId) {
		super();
		this.id = id;
		this.name = name;
		this.department = department;
		this.courseId = courseId;
	}
	public String toString()
	{
		return "Student :\nId: "+id+"\nName : "+name+"\nDepartment : "+department+"\n Course Id :"+courseId;
	} 
}

