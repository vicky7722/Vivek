package studentFeedbacksingleInheritance;
public class StudentRating extends Student{
	public int id2;
	public String review;
	public int stars;
	public Student student;
	
	public StudentRating(int id, String name, String department, int courseId, String review, int stars,int id2 ) {
		super(id, name, department, courseId);
		this.id2 = id2;
		this.review = review;
		this.stars = stars;
		this.student = student;
	}

	public String toString() {
		return super.toString()+"\nRating ID: "+id2+"\nReview: "+review+"Rating Stars: "+stars;
	}
}
