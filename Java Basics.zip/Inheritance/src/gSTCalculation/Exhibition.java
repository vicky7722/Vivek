package gSTCalculation;
class Exhibition extends Event {
	   private static int gst=5;
	   private int noOfStalls;
	   public Exhibition(String name, String type, double costPerDay, int noOfDays, int noOfStalls) {
		super(name, type, costPerDay, noOfDays);
		this.noOfStalls = noOfStalls;
	}

		//Fill your code here
	   
	    public static int getGst() {
			return gst;
		}

		public static void setGst(int gst) {
			Exhibition.gst = gst;
		}

		public int getNoOfStalls() {
			return noOfStalls;
		}

		public void setNoOfStalls(int noOfStalls) {
			this.noOfStalls = noOfStalls;
		}

		public Double totalCost() {
			 double cost,tc,tax;
		     cost=costPerDay*noOfDays;
		     tax=cost*0.05;
		     tc=cost+tax;
		     return tc;
	       //Fill your code here
	    }
	    
	    
	    public String toString() {
	       //Fill your code here
	    	return "Event Details\n" + "Name:"+name+"\nType:"+type+"\nNumber of stalls:"+noOfStalls+"\nTotal amount: "+String.format("%.2f",totalCost());
	    }
	}