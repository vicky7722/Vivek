package gSTCalculation;

class StageEvent extends Event{
	private static int gst=15;
	private int noOfSeats;
	public static int getGst() {
		return gst;
	}

	public static void setGst(int gst) {
		StageEvent.gst = gst;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public StageEvent(String name, String type, double costPerDay, int noOfDays,int noOfSeats) {
		super(name,type,costPerDay,noOfDays);
		this.noOfSeats=noOfSeats;
	}

    //Fill your code here

    public Double totalCost() {

    	double cost,tc,tax;
	    cost=costPerDay*noOfDays;
	    tax=cost*0.15;
	    tc=cost+tax;
	    return tc;
    }
    
    public String toString() {
       return "Event Details\n" + "Name:"+name+"\nType:"+type+"\nNumber of seats:"+noOfSeats+"\nTotal amount: "+String.format("%.2f",totalCost());
    }
}