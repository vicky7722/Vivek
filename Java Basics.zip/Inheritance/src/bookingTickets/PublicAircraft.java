package bookingTickets;
public class PublicAircraft extends Aircraft
{
    private boolean checkInBeforeTwoHours;
    private int noOfKgsAllowed;
    private double additionalFeePerkg;
    public boolean isCheckInBeforeTwoHours() {
        return checkInBeforeTwoHours;
    }
    public void setCheckInBeforeTwoHours(boolean checkInBeforeTwoHours) {
        this.checkInBeforeTwoHours = checkInBeforeTwoHours;
    }
    public int getNoOfKgsAllowed() {
        return noOfKgsAllowed;
    }
    public void setNoOfKgsAllowed(int noOfKgsAllowed) {
        this.noOfKgsAllowed = noOfKgsAllowed;
    }
    public double getAdditionalFeePerkg() {
        return additionalFeePerkg;
    }
    public void setAdditionalFeePerkg(double additionalFeePerkg) {
        this.additionalFeePerkg = additionalFeePerkg;
    }
    public PublicAircraft(String aircraftName, String source, String destination, boolean checkInBeforeTwoHours,
        int noOfKgsAllowed, double additionalFeePerkg) {
        super(aircraftName, source, destination);
        this.checkInBeforeTwoHours = checkInBeforeTwoHours;
        this.noOfKgsAllowed = noOfKgsAllowed;
        this.additionalFeePerkg = additionalFeePerkg;
    }
    public void displayDetails()
    {
        System.out.println("Flight Details : ");
        System.out.println("Public Aircraft : ");
        super.displayDetails();
        if(checkInBeforeTwoHours==true){
            System.out.println("Flight check in before two hours : Yes");
        }
        else{
             System.out.println("Flight check in before two hours : Yes");
        }
        System.out.println("Number of kgs allowed per person : "+noOfKgsAllowed);
        System.out.println("Additional fee charged for extra baggage per Kg : "+String.format("%.2f",additionalFeePerkg));
        
        
    }
    
 
}