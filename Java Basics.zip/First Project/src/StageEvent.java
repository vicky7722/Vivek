public class StageEvent extends Event{
	private int totalShow;
	private int seatsPerShow;
	public int getTotalShow() {
		return totalShow;
	}
	public void setTotalShow(int totalShow) {
		this.totalShow = totalShow;
	}
	public int getSeatsPerShow() {
		return seatsPerShow;
	}
	public void setSeatsPerShow(int seatsPerShow) {
		this.seatsPerShow = seatsPerShow;
	}
	public StageEvent(String name, String detail, String organizer, int totalShow, int seatsPerShow) {
		super(name, detail, organizer);
		this.totalShow = totalShow;
		this.seatsPerShow = seatsPerShow;
	}
	public void totalCredit(){
		int tc=(totalShow*seatsPerShow)*100;
		System.out.println("Total Credit Gained is "+tc);
	}
	public String toString(){
		
		return super.toString()+"\nTotal Events : "+totalShow+"\nTotal Seats : "+seatsPerShow+"\nCredit Details";
	}
}
