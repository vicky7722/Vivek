
public interface GameStatus {
	void status();
}
