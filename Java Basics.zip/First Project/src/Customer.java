public class Customer{
	//Fill your code
	public String customerName;
	public String customerEmail;
	public String customerType;
	public String customerAddress;
	
	public void displayDetails(){

			//Fill your code

	}

	public Customer(String customerName, String customerEmail, String customerType, String customerAddress) {
		this.customerName = customerName;
		this.customerEmail = customerEmail;
		this.customerType = customerType;
		this.customerAddress = customerAddress;
	}
	
}