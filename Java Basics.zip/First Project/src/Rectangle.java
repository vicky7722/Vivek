public class Rectangle {
    		private int len;
			private int wid;
	//Fill your code	
	

	public Integer area() {		

		//Fill your code
		return 0;	

	}
	public Rectangle(int len, int wid) {
		this.len = len;
		this.wid = wid;
	}
	public int getLen() {
		return len;
	}
	public void setLen(int len) {
		this.len = len;
	}
	public int getWid() {
		return wid;
	}
	public void setWid(int wid) {
		this.wid = wid;
	}
	public void display(){
		
		//Fill your code	

	}
	
	Rectangle dimensionChange(Integer newDimension){

		Rectangle rectangleObject = null;
		//Fill your code	
		return rectangleObject;
	}
	

}
