import java.util.*;
public class BankMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter account number:");
		int accNo=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter account name:");
		String accName=sc.nextLine();
		System.out.println("Enter balance");
		double balance=sc.nextDouble();
		System.out.println("Enter pin");
		int pin=sc.nextInt();
		BankAccount ba=new BankAccount(accNo,accName,balance,pin);
		int n;
		do{
			System.out.println("Enter 1 to deposit");
			System.out.println("Enter 2 to withdraw");
			System.out.println("Enter 3 to Check Balance");
			System.out.println("Enter 4 to Display Account Details");
			System.out.println("Enter 5 to Change Pin");
			System.out.println("Enter 6 to exit");
			n=sc.nextInt();
			switch(n){
			case 1:
				System.out.println("Enter amount to be deposited:");
				double dep=sc.nextDouble();
				ba.deposit(dep);
				break;
			case 2:
				System.out.println("Enter amount to withdraw:");
				double wid=sc.nextDouble();
				ba.withdraw(wid);
				break;
			case 3:
				System.out.println(ba.balanceCheck());
				break;
			case 4:
				ba.displayAccount();
				break;
			case 5:
				System.out.println("Enter new pin:");
				int newpin=sc.nextInt();
				ba.pinChange(pin, newpin);
				break;
			case 6:
				break;
				
			default:System.out.println("Choose valid option");
			}
		}while(n!=6);
		
		sc.close();
	}

}
