
public interface BikeSpeed {
	int averageSpeed();
	
}
