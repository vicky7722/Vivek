import java.util.*;

public class Main3 {
	public static void main(String args[]) {
		
		ArrayList<Event> eventList=new ArrayList<>();
		ArrayList<Hall> hallList=new ArrayList<>();
		
		eventList.add(new Event("Book Fair","All books available","John","Exhibition"));
		eventList.add(new Event("Furniture Fair","Discount of 20%","Joe","Exhibition"));
		eventList.add(new Event("Magic show","Magic without Logic","Jack","Stage event"));
		
		hallList.add(new Hall("Sdf hall","123456",new Double(10000.0),"Jill"));
		hallList.add(new Hall("JKL hall","135790",new Double(25000.0),"James"));
		hallList.add(new Hall("TUV hall","246800",new Double(15000.0),"Jane"));
		
		//write your code here
		
	}
}
