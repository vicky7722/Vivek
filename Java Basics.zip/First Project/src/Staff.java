
import java.util.*;
public class Staff extends Person{
	public int	employeeID;
	public String	designation;
	public int getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Staff(String name, Date dateOfBirth, String gender, String mobileNumber, String bloodBankName,int employeeID, String designation) {
		super();
		this.employeeID = employeeID;
		this.designation = designation;
	}
	public Staff() {
		super();
	}
	public void displayDetails() {
		super.displayDetails();
		System.out.println("Employee ID: "+employeeID);
		System.out.println("Designation: "+designation);
	}
}
