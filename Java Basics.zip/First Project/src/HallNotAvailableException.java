public class HallNotAvailableException extends Exception {
	//fill your code here
	public HallNotAvailableException(String message){
		super(message);
	}
}
