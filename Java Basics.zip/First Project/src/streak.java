import java.util.*;
public class streak {
	public static void main(String[] args){
		Scanner sc= new Scanner(System.in);
        int s,n,temp,cnt=0,i,j=1,flag,t=0;
        s=sc.nextInt();
        n=sc.nextInt();
        for(i=1;i<=n;i++){
            temp=i;
            flag=j;
            while(temp%flag==0 && flag<=n){
                cnt++;
                temp++;
                flag++;
            }
            if(cnt==s){
                t++;
            }
            cnt=0;
    }
    System.out.println(t);
}
}
