import java.util.*;
class UidSorter implements Comparator<User>
{
   @Override
   public int compare(User u1,User u2)
    {
      return u1.getUname().compareTo(u2.getUname());
 
    }
}