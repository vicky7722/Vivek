import java.util.*;
public class User implements Comparable<User>
{
	
	private int uid;
	private String uname;
	private String email;
	private String DOB;
	
	public User() {}
 
	public User(int uid, String uname, String email, String DOB) {
		super();
		this.uid = uid;
		this.uname = uname;
		this.email = email;
		this.DOB = DOB;
	}
 
	public int getUid() {
		return uid;
	}
 
	public void setUid(int uid) {
		this.uid = uid;
	}
 
	public String getUname() {
		return uname;
	}
 
	public void setUname(String uname) {
		this.uname = uname;
	}
 
	public String getEmail() {
		return email;
	}
 
	public void setEmail(String email) {
		this.email = email;
	}
 
	public String getDOB() {
		return DOB;
	}
 
	public void setDOB(String DOB) {
		this.DOB = DOB;
	}
	
	@Override
	public String toString()
	{
		return uid+"\n"+uname+"\t"+email+"\t"+DOB+"\n";
	}
 
	@Override
	public int hashCode() {
		return Objects.hash(DOB, uname, uid, email);
	}
 
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		return Objects.equals(DOB, other.DOB) && Objects.equals(uname, other.uname) && uid == other.uid
				&& email == other.email;
	}
 
	@Override
	public int compareTo(User o) {
		if(uid>o.uid) {
			return 1;
		}
		else if(uid<o.uid)
		{
			return -1;
		}
		else {
			return 0;
		}
		
	}//compareTo()
	
	
 
}
