import java.util.*;
public class UserTreeSet {
	 
	public static void main(String[] args) {
		User u1=new User(1011,"Neha","Neha@abc.com","23 June 2001");
		User u2=new User(1012,"Tom","Tom@abc.com","28 July 2001");
		User u3=new User(1013,"Tina","Tina@abc.com","26 August 2001");
		User u4=new User(1014,"Nishant","Nish@abc.com","29 September 2001");
		User u5=new User(1011,"Neha","Neha@abc.com","23 October 2001");
		
		
		Set<User> set=new TreeSet<>();
		
		set.add(u1);
		set.add(u2);
		set.add(u3);
		set.add(u4);
		set.add(u5);
		
		System.out.println(set);
 
	}
 
}
 
