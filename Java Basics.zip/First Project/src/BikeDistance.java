
public interface BikeDistance {
	int totalDistance();
}
