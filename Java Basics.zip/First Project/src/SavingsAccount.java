class SavingsAccount implements MaintenanceCharge{
	public float calculateMaintancecharge(Float noOfYears) {
		return (2*noOfYears*50+50);
	}
}
