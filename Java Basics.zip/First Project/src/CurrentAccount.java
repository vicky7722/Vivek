
public class CurrentAccount implements MaintenanceCharge{

	@Override
	public float calculateMaintancecharge(Float noOfYears) {
		// TODO Auto-generated method stub
		return (100*noOfYears+200);
	}
}
