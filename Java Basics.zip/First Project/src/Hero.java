
public class Hero implements GameStatus{
	private int life;

	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}

	public Hero(int life) {
		super();
		this.life = life;
	}
	public void status() {
		life=life-1;
		System.out.println("You have "+life+" lives left");
		if(life==0) {
			System.out.println("You lose the GAME !!!");
			return;
		}
	}
}
