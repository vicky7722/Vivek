import java.util.ArrayList;
public class HallBookingBO {
	public static Boolean validateHallBooking(ArrayList<HallBooking> bookingList,HallBooking booking) throws HallNotAvailableException{
		//fill your code here
		return 
	}
}
