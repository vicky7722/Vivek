
public class Villain implements GameStatus{
	private int damage;

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}

	public Villain(int damage) {
		super();
		this.damage = damage;
	}
	public void status() {
		damage=damage+50;
		System.out.println("The Villain Damage level is :"+damage);
		if(damage==100) {
			System.out.println("----GAME OVER----");
			System.out.println("YOU WINS!!!");
			return;
		}
	}
}
