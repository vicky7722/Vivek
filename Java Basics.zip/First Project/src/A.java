
public final class A {
	void add() {
		System.out.println("Ins a");
	}

}
