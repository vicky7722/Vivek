import java.util.*;
import java.text.*;
class Account{
	private String name;
	private String accountNumber;
	private double balance;
	private Date startDate;
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public SimpleDateFormat getFormatter() {
		return formatter;
	}
	public void setFormatter(SimpleDateFormat formatter) {
		this.formatter = formatter;
	}
	public Account(String name, String accountNumber, double balance, Date startDate) {
		super();
		this.name = name;
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.startDate = startDate;
	}
	
}