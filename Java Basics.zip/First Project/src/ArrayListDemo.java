import java.util.*;

	public class ArrayListDemo {
		 
		public static void main(String[] args) {
			List<String> list=new ArrayList<>();
			list.add("Paushika");
			list.add("Maruthi");
			list.add("Dolly");
			list.add("Saipriya");
			list.add("Rohit");
			list.add("Raushan");

			System.out.println(list);


	 
		}
	 
	}

