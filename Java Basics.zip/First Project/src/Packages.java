
public class Packages {
	public static void main(String[] args) {
		Display[] arr=new Display[3];
		for(int i=0;i<3;i++) {
			arr[i]=new Display();
		}
		arr[0].x=0;
		arr[1].x=1;
		arr[2].x=2;
		for(int i=0;i<3;++i) {
			arr[i].show();
		}
	}
}
