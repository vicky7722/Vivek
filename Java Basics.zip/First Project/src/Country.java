public class Country{
	public String name;
	public String countryCode;
	public String isdCode;
                //Fill code here		
		void display() {
			//Fill code here
		}
				public Country(String name, String countryCode, String isdCode) {
					this.name = name;
					this.countryCode = countryCode;
					this.isdCode = isdCode;
				}
}