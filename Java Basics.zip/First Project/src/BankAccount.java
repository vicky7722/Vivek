
public class BankAccount {
	private int accNo;
	private String accName;
	private double balance;
	private int pin;
	public BankAccount(int accNo,String accName,double balance,int pin) {
		this.accNo=accNo;
		this.accName=accName;
		this.balance=balance;
		this.pin=pin;
	}
	public BankAccount(int accNo,String accName) {
		this.accNo=accNo;
		this.accName=accName;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void deposit(double amt) {
		balance=balance+amt;
		System.out.println(balance);
	}
	public void withdraw(double amt) {
		if(balance>amt) {
			balance=balance-amt;
		}
		else {
			System.out.println("Insufficient balance");
		}
	}
	public double balanceCheck() {
		return balance;
	}
	public void displayAccount() {
		System.out.println("accNo:"+accNo);
		System.out.println("accName:"+accName);
		System.out.println("balance:"+balance);
	}
	public void pinChange(int oldPin,int newPin) {
		if(oldPin==pin) {
			pin=newPin;
		}
		System.out.println("Your pin is changed and new pin is "+pin);
	}
}
