import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.Date;
 
public class Main1 {
 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-HH:mm:ss");
        sdf.setLenient(false);
        System.out.println("Enter the stage event start date and end date");
        String startDateStr = sc.nextLine();
        try{
            Date startDate = sdf.parse(startDateStr);
            System.out.println("Start Date: " +sdf.format(startDate));
        }
        catch (ParseException e){
            System.out.println("Input dates should be in the format 'dd-MM-yyyy-HH:mm:ss'");
        }
        String endDateStr=sc.nextLine();
        try {
        	Date endDate=sdf.parse(endDateStr);
        	System.out.println("End Date: "+sdf.format(endDate));
        }
        catch(ParseException e) {
        	System.out.println("Input dates should be in the format 'dd-MM-yyyy-HH:mm:ss'");
        }
        sc.close();
 
    }
 
}
 