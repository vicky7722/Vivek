
public interface MaintenanceCharge {
	float calculateMaintancecharge(Float noOfYears);
}
