
public class LoginMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoginTest l=new LoginTest();
		try {
			l.authenticateUser("admik", "password");
		}
		catch(LoginException le) {
			le.printStackTrace();
		}
	}

}
