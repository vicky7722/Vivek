import java.util.*;
public class UserIterator {
 
	public static void main(String[] args) {
	
 
		List<String> list=new LinkedList(Arrays.asList(new String[] {"Nikita","Preeti","Yogesh","Shraman","Utsa"}));
		
		
		System.out.println("get(1):"+list.get(1));
		                  list.add(1,"Aditya");
        System.out.println(list); 	
        list.set(1, "Nikita");
        System.out.println(list);
        
        //ListIterator
        
        ListIterator<String> itr=list.listIterator();
        
        //moving the cursor after the last record
        while(itr.hasNext()) {
        	String k=itr.next();
        	if(k.equals("Utsa")) {
        		itr.set("NEW ASSOCIATE");
        	}
        	
        }
        
        //iterating the collection in backward order
        System.out.println("----------Printing Collection in Reverse order----");
        while(itr.hasPrevious()) {
        	String k=itr.previous();
        	System.out.println(k);
        
        }
        
        
        
        
		
		
		
		
	}
 
}