import java.text.*;
import java.util.*;
 
public class Main {
 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-HH:mm:ss");
        sdf.setLenient(false);
        System.out.println("Enter the stage event start date and end date");;
        try{
            String startDateStr = sc.nextLine();
            Date startDate = sdf.parse(startDateStr);
            System.out.println("Start Date: " +sdf.format(startDate));
        }
        catch (ParseException e){
            System.out.println("Input dates should be in the format 'dd-MM-yyyy-HH:mm:ss'");
        }
        try {
			String endDateStr=sc.nextLine();
        	Date endDate=sdf.parse(endDateStr);
        	System.out.println("End Date: "+sdf.format(endDate));
        }
        catch(ParseException e) {
        	System.out.println("Input dates should be in the format 'dd-MM-yyyy-HH:mm:ss'");
        }
        sc.close();
 
    }
 
}
 