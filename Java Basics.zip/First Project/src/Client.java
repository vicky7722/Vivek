
public class Client implements Display{
	private int clientId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String phoneNumber;
	private String email;
	private String passport;
	private String iataCountryCode;
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassport() {
		return passport;
	}
	public Client(int clientId, String firstName, String middleName, String lastName, String phoneNumber, String email,
			String passport, String iataCountryCode) {
		super();
		this.clientId = clientId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.passport = passport;
		this.iataCountryCode = iataCountryCode;
	}
	public void setPassport(String passport) {
		this.passport = passport;
	}
	public String getIataCountryCode() {
		return iataCountryCode;
	}
	public void setIataCountryCode(String iataCountryCode) {
		this.iataCountryCode = iataCountryCode;
	}
	public void displayClientDetails() {
		System.out.println("Client Details");
		System.out.println("Client Id : "+clientId);
		System.out.println("First Name :"+firstName);
		System.out.println("Middle Name : "+middleName);
		System.out.println("Last Name : "+lastName);
		System.out.println("Phone Number : "+phoneNumber);
		System.out.println("Email : "+email);
		System.out.println("Passport : "+passport);
		System.out.println("IATA Country Code : "+iataCountryCode);
	}
	
}
