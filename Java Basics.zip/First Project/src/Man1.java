
public class Man1 {
	public static void main(String[] args) {
		 B b = new B();
		 b.add();
	}
}
