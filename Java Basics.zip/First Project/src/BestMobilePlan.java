public class BestMobilePlan
    {
        public static void printPlanDetails(int day,int night,int weekend)
        {
            //type your code here
            double pa=0,pb=0;
            if(day>=100){
                day=day-100;
                pa=pa+day*25;
            }
            pa=pa+night*15;
            pa=pa+weekend*20;
            pa=pa/100;
            if(day>=250){
                day=day-250;
                pb=pb+(day*45);
            }
            pb=pb+(night*35);
            pb=pb+(weekend*25);
            pb=pb/100;
            System.out.println("Plan A costs "+pa);
            System.out.println("Plan B costs "+pb);
            if(pa>pb){
                System.out.println("Plan B is cheapest");
            }
            if(pa<pb){
                System.out.println("Plan A is cheapest");
            }
            if(pa==pb){
                System.out.println("Plan A and B are the same price");
            }
        }
    }

