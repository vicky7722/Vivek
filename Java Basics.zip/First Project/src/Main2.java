import java.util.Scanner;
 
public class Main2 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("Enter the number of rows and columns of the show:");
            int n = sc.nextInt();
            int[][] seats = new int[n][n];
 
            System.out.println("Enter the number of seats  to booked:");
            int seatCount = sc.nextInt();
            for (int i=0; i < seatCount; i++) {
            	System.out.println("Enter the seat number "+(i+1));
                int seatNumber = sc.nextInt();
 
                if (seatNumber < 0 || seatNumber >= n * n) {
                    
                }
 
                if (seats[seatNumber] == 1) {
                    throw new SeatNotAvailableException("SeatNotAvailableException: Already Booked");
                }
                else {
                    seats[seatNumber] = 1;
                    System.out.println("The seats booked are:");
                    for(int j=0;j<n;j++) {
                    	for(int k=0;k<n;k++) {
                    		System.out.print(seats[k]+" ");
                    	}
                    	System.out.println("");
                    }
                }
            }
        }
        catch(SeatNotAvailableException e) {
            System.out.println(e.getMessage());
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println(e.getMessage());
        }
        finally {
            sc.close();
        }
        
    }
 
}