
public class B extends A{
	void add() {
		System.out.println("Ins B");
	}
}
