
public class LoginTest  {
	public void authenticateUser(String uname,String password) throws LoginException{
		if(uname.equalsIgnoreCase("admin")&&password.equalsIgnoreCase("password")) {
			System.out.println("Legitimate to pass");
		}
		else {
			throw new LoginException("Please enter valid credentials");
		}
	}
}
