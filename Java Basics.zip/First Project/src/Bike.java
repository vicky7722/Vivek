
public class Bike implements BikeSpeed,BikeDistance {
	private int distance;
	private int speed;
	public Bike(int distance, int speed) {
		super();
		this.distance = distance;
		this.speed = speed;
	}
	public Bike() {
		super();
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int averageSpeed() {
		return distance;
	}
	public int totalDistance() {
		return distance*speed;
	}
}
