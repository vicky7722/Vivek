import java.util.*;
public class sumandnum {

	public static void main(String[] args) {
		int num1=3,num2=5;
		int res=num1|num2;
		System.out.println(res);
	}
}
