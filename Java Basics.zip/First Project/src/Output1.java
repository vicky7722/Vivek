
public class Output1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer s1=new StringBuffer("Hello");
		s1.setCharAt(l,x);
		System.out.println(s1);
	}

}
