class Exhibition extends Event{
	
	private int stallCount;

	public int getStallCount() {
		return stallCount;
	}

	public void setStallCount(int stallCount) {
		this.stallCount = stallCount;
	}

	public Exhibition(String name, String detail, String organizer, int stallCount) {
		super(name, detail, organizer);
		this.stallCount = stallCount;
	}
	public void totalCredit(){
		int tc=stallCount*50;
		System.out.println("Total Credit Gained is "+tc);
	}
	public String toString(){
		
		return super.toString()+"\nStall Count: "+stallCount+"\nCredit Details ";
	}
}