package numberFormatException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Item type details:");
        
        System.out.print("Enter the name: ");
        String name = scanner.nextLine();
        
        double deposit = 0;
        double costPerDay = 0;
        
        try {
            System.out.print("Enter the deposit: ");
            deposit = Double.parseDouble(scanner.nextLine());
            
            System.out.print("Enter the cost per day: ");
            costPerDay = Double.parseDouble(scanner.nextLine());
            
            ItemType item = new ItemType(name, deposit, costPerDay);
            System.out.println("The details of the item type are:");
            System.out.println(item);
        } catch (NumberFormatException e) {
            System.out.println("java.lang.NumberFormatException: " + e.getMessage());
        }
        
        scanner.close();
    }
}