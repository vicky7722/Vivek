import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
 
public class ParseExceptionMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SimpleDateFormat d = new SimpleDateFormat("dd-MM-yyyy-HH:mm:ss");
        d.setLenient(false);
 
        System.out.println("Enter the stage event start date and end date");
 
        try {
                    String startDateInput = scanner.nextLine();
                    Date startDate = d.parse(startDateInput);
                    String endDateInput = scanner.nextLine();
                    Date endDate = d.parse(endDateInput);
                    System.out.println("Start date:" + d.format(startDate));    
                    System.out.println("End date:" + d.format(endDate));
        }
                catch (ParseException e) {
            System.out.println("Input dates should be in the format 'dd-MM-yyyy-HH:mm:ss'");
            
         }
                
         }
    }
 