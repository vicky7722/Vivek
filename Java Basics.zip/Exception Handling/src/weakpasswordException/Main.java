package weakpasswordException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the user details");
        String[] userDetails = scanner.nextLine().split(",");
 
        String name = userDetails[0];
        String mobile = userDetails[1];
        String username = userDetails[2];
        String password = userDetails[3];
 
        User user = new User(name, mobile, username, password);
 
        try {
            UserBO.validate(user);
            System.out.println(user);
        } catch (WeakPasswordException e) {
            System.out.println("WeakPasswordException: " + e.getMessage());
        }
 
        scanner.close();
    }
}
 