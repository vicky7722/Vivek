package eventTypeDoesNotExistsException;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
   public static void main(String[] args) {
       ArrayList<EventType> typeList = new ArrayList<>();
       typeList.add(new EventType("Stage Event", Long.valueOf(1)));
       typeList.add(new EventType("Exhibition", Long.valueOf(2)));
       typeList.add(new EventType("Sports meet", Long.valueOf(3)));

       Scanner scanner = new Scanner(System.in);
       System.out.println("Enter the number of the events:");
       int numberOfEvents = Integer.parseInt(scanner.nextLine());

       List<Event> events = new ArrayList<>();

       for (int i = 1; i <= numberOfEvents; i++) {
           System.out.println("Enter the details of event " + i);
           String[] eventDetails = scanner.nextLine().split(",");

           String name = eventDetails[0];
           String detail = eventDetails[1];
           String ownerName = eventDetails[2];
           Long typeId = Long.valueOf(eventDetails[3]);

           boolean valid = false;
           while (!valid) {
               try {
                   valid = isValid(typeId, typeList);
               } catch (EventTypeDoesNotExistsException e) {
                   System.out.println("EventTypeDoesNotExistsException: " + e.getMessage());
                   System.out.println("Enter the correct event type id:");
                   typeId = Long.valueOf(scanner.nextLine());
               }
           }

           events.add(new Event(name, detail, ownerName, typeId));
       }

       System.out.println("The events entered are:");
       System.out.printf("%-15s%-15s%-15s%-15s\n", "Name", "Details", "Owner name", "Event typeid");
       for (Event event : events) {
           System.out.println(event);
       }

       scanner.close();
   }
	public static Boolean isValid(Long typeId, List<EventType> typeList) throws EventTypeDoesNotExistsException {
       for (EventType type : typeList) {
           if (type.getId().equals(typeId)) {
               return true;
           }
       }
       throw new EventTypeDoesNotExistsException("No event type available with the given id");
   }
}
