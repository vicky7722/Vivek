import java.util.InputMismatchException;
import java.util.Scanner;
 
public class Inputmismatchexception {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter an integer input");
 
        try {
            int input = scanner.nextInt();
            System.out.println("Entered value is " + input);
        } catch (InputMismatchException e) {
            System.out.println("java.util.InputMismatchException");
        } finally {
            scanner.close();
        }
    }
}