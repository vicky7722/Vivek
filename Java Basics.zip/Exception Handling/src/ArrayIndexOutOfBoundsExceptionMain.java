import java.util.*;
 
public class ArrayIndexOutOfBoundsExceptionMain {
    public static void main(String args[]) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of seats to be booked:");
        int num=sc.nextInt();
        int[] arr = new int[100];
        int x=1; int temp=0;
           try{
            for(int i=0;i<num;i++)
            {
                System.out.println("Enter the seat number "+x);
                  temp=sc.nextInt();
            
                        int s=arr[temp-1];
                         arr[i]=temp;
                         x++;
                    }
            
               System.out.println("The seats booked are:");
            for(int i=0;i<num;i++)
            {
                System.out.println(arr[i]);
            }           
          
}//try
    catch(ArrayIndexOutOfBoundsException e){
        System.out.println("java.lang.ArrayIndexOutOfBoundsException: "+(temp-1));
    }       
            
             
    }//main
        }//clss