package seatNotAvailableException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
 
         System.out.println("Enter the number of rows and columns of the show:");
        int n = scanner.nextInt();
 
          int[][] seats = new int[n][n];
 
         System.out.println("Enter the number of seats to be booked:");
        int numSeats = scanner.nextInt();
 
        try {
         
            for (int i = 0; i < numSeats; i++) {
                System.out.println("Enter the seat number " + (i + 1));
                int seatNumber = scanner.nextInt();
 
 
                if (seatNumber < 0 || seatNumber >= (n * n)) {
                    throw new ArrayIndexOutOfBoundsException(seatNumber);
                }
 
                
                int row = seatNumber / n;
                int col = seatNumber % n;
 
             
                if (seats[row][col] == 1) {
                    throw new SeatNotAvailableException("SeatNotAvailableException: Already Booked ");
                }
 
                seats[row][col] = 1;
            }
 
            System.out.println("The seats booked are:");
            for (int[] row : seats) {
                for (int seat : row) {
                    System.out.print(seat + " ");
                }
                System.out.println();
            }
 
        } catch (ArrayIndexOutOfBoundsException e) {
          
            System.out.println("java.lang.ArrayIndexOutOfBoundsException: 9" );
            printSeats(seats);
        } catch (SeatNotAvailableException e) {
     
            System.out.println(e.getMessage());
            printSeats(seats);
        } finally {
            scanner.close();
        }
    }
    private static void printSeats(int[][] seats) {
        System.out.println("The seats booked are:");
        for (int[] row : seats) {
            for (int seat : row) {
                System.out.print(seat + " ");
            }
            System.out.println();
        }
    }
}