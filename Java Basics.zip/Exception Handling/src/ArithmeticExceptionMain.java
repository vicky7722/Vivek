import java.util.*;
public class ArithmeticExceptionMain{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the cost of the item for n days");
		int costOfItem=sc.nextInt();
		System.out.println("Enter the value of n");
		int n=sc.nextInt();
		try{
			int costPerDay=costOfItem/n;
			System.out.println("Cost per day of the item is "+costPerDay);
		}
		catch(ArithmeticException e){
			System.out.println(e);
		}
		sc.close();
	}
}