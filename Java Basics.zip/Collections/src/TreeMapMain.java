import java.util.*;
public class TreeMapMain {
 
    public static void main(String[] args){
        //fill your code here
        Map<Integer,Integer> tm = new TreeMap<>();
 
 
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of events:");
        int n = sc.nextInt();
        System.out.println("Enter event details in CSV(Customer Name,Ticket Price,No of Seats Booked)");
        for(int i = 0; i<n; i++)
        {
            String input ;
            input = sc.next();
            String[] tmp = input.split(",");
 
            int seat_price = Integer.parseInt(tmp[1]);
            int no_of_seats = Integer.parseInt(tmp[2]);
 
            if(!tm.containsKey(seat_price))
                tm.put(seat_price,no_of_seats);
            else
                tm.put(seat_price, tm.get(seat_price)+no_of_seats);
        }
 
        System.out.println("Ticket Price    Tickets Booked");
        for (int key : tm.keySet()) {
            System.out.println(key+"                 "+tm.get(key));
        }
        
    }
}
 