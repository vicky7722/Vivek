package comparableInterface;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of users:");
        int n = sc.nextInt();
        sc.nextLine(); // Consume newline left-over
 
        ArrayList<Address> addressList= new ArrayList<>();
        
        System.out.println("Enter user address in CSV(Username,AddressLine 1,AddressLine 2,PinCode)");
        for (int i = 0; i < n; i++) {
            String userDetails = sc.nextLine();
            String[] details = userDetails.split(",");
            String username = details[0];
            String addressLine1 = details[1];
            String addressLine2 = details[2];
            Integer pinCode = Integer.parseInt(details[3]);
            Address address = new Address(username, addressLine1, addressLine2, pinCode);
            addressList.add(address);
        }
 
        Collections.sort(addressList);
        System.out.println("User Details:");
        for (Address add : addressList) {
            System.out.println(add);
        }
    }
}