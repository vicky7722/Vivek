package comparableInterface;
import java.util.Objects;

public class Address implements Comparable<Address>{
	private String username;
	private String addressLine1;
	private String addressLine2;
	private int pinCode;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	public Address(String username, String addressLine1, String addressLine2, int pinCode) {
		super();
		this.username = username;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.pinCode = pinCode;
	}
	public Address() {
		super();
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(addressLine1, addressLine2, pinCode, username);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		return Objects.equals(addressLine1, other.addressLine1) && Objects.equals(addressLine2, other.addressLine2)
				&& pinCode == other.pinCode && Objects.equals(username, other.username);
	}
	public int compareTo(Address a) {
		if(a.pinCode>pinCode) {
			return -1;
		}
		else if(a.pinCode<pinCode) {
			return 1;
		}
		else {
			return this.addressLine1.compareTo(addressLine1);
		}
	}
	public String toString() {
		return username+","+addressLine1+","+addressLine2+","+pinCode;
	}
}
