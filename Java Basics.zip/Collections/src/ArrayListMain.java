import java.util.*;
public class ArrayListMain {
	public static void main(String args[]) {
		//write your code here
		Scanner sc=new Scanner(System.in);
		String ch="y";
		int x=1;
		ArrayList<String> al = new ArrayList<>();
		while(ch.equalsIgnoreCase("y")){
			System.out.println("Enter the username "+x);
			al.add(sc.nextLine());
			System.out.println("Do you want to continue?(y/n)");
			ch=sc.nextLine();
			x++;
		}
		System.out.println("The Names entered are:");
		for(String i:al) {
			System.out.println(i);
		}
		
		sc.close();
	}
}
