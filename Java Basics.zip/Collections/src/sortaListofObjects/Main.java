package sortaListofObjects;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of halls:");
		int n=Integer.parseInt(sc.nextLine());
		List<Hall> hall=new ArrayList<>();
		for(int i=0;i<n;i++) {
			System.out.println("Enter the details of hall "+(i+1));
			String h=sc.nextLine();
			String[] ha=h.split(",");
			String name=ha[0];
			String cn=ha[1];
			double cpd=Double.parseDouble(ha[2]);
			String on=ha[3];
			Hall hl=new Hall(name,cn,cpd,on);
			hall.add(hl);
		}
		System.out.println("Sorted Order (from the least expensive to the most):");
		Collections.sort(hall);
		System.out.printf("%-15s%-15s%-15s%-15s\n","Name","Contact number","Cost per day","Owner name");
		for(Hall h:hall) {
			System.out.printf("%-15s%-15s%-15s%-15s\n",h.getName(),h.getContactNumber(),h.getCostPerDay(),h.getOwnerName());
		}
	}

}
