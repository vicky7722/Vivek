package iteratorclass;
import java.util.*;
public class Main {

	public static void main(String[] args){
		//Your code here
		System.out.println("Enter the number of stall details");
		Scanner sc=new Scanner(System.in);
		int n=Integer.parseInt(sc.nextLine());
		List <Stall> st=new ArrayList<>();
		for(int i=0;i<n;i++) {
			System.out.println("Enter the stall "+(i+1)+" detail");
			String[] det = sc.nextLine().split(",");
			Stall stall=new Stall(det[0],det[1],det[2],det[3]);
			st.add(stall);
		}
		ListIterator<Stall> itr=st.listIterator();
		while(itr.hasNext()) {
			Stall k=itr.next();
			if(k.getName().toLowerCase().startsWith("test")) {
				itr.remove();
			}
		}
		System.out.printf("%-15s %-20s %-15s %s\n","Name","Detail","Type","OwnerName");
		for(Stall s:st) {
			System.out.printf("%-15s %-20s %-15s %s\n",s.getName(),s.getDetail(),s.getType(),s.getOwnerName());
		}
		sc.close();
	}

}
