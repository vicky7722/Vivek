package MinandMax;
import java.util.*;

class TicketBooking implements Comparable<TicketBooking> {
private String customerName;
private Integer price;
 
public TicketBooking(String customerName, Integer price) {
this.customerName = customerName;
this.price = price;
}
 
public String getCustomerName() {
return customerName;
}
 
public void setCustomerName(String customerName) {
this.customerName = customerName;
}
 
public Integer getPrice() {
return price;
}
 
public void setPrice(Integer price) {
this.price = price;
}
 
@Override
public int compareTo(TicketBooking other) {
return this.price.compareTo(other.price);
}
}
 