package MinandMax;
import java.util.*;
public class Main {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.println("Enter the number of customers");
int n = Integer.parseInt(sc.nextLine());
if (n <= 0) {
System.out.println("Invalid Input");
return;
}
 
List<TicketBooking> bookings = new ArrayList<>();
System.out.println("Enter the booking price accordingly with customer name in CSV(Customer Name,Price)");
for (int i = 0; i < n; i++) {
String[] input = sc.nextLine().split(",");
String name = input[0].trim();
Integer price = Integer.parseInt(input[1].trim());
bookings.add(new TicketBooking(name, price));
}
 
TicketBooking minSpender = Collections.min(bookings);
TicketBooking maxSpender = Collections.max(bookings);
 
System.out.println(minSpender.getCustomerName()+" spends minimum amount of Rs."+minSpender.getPrice());
System.out.println(maxSpender.getCustomerName()+" spends maximum amount of Rs."+maxSpender.getPrice());
}
}