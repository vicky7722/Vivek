package seatArrangement;
import java.util.*;
public class Main {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
 
System.out.println("Enter the number of rows ");
int rows = sc.nextInt();
System.out.println("Enter the number of seats per row ");
int seatPerRow = sc.nextInt();
sc.nextLine(); 
 
List<List<Seat>> seatList = Seat.generateSeats(rows, seatPerRow);
 
System.out.println("Enter the seats to book in CSV format");
String toBook = sc.nextLine();
 
Seat.book(seatList, toBook);
}
}