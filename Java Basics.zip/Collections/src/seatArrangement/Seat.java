package seatArrangement;
import java.util.*;

class Seat {
private Character section;
private Integer number;
private Boolean booked;
 
public Seat(Character section, Integer number, Boolean booked) {
this.section = section;
this.number = number;
this.booked = booked;
}
 
public Character getSection() {
return section;
}
 
public Integer getNumber() {
return number;
}
 
public Boolean isBooked() {
return booked;
}
 
public void setBooked(Boolean booked) {
this.booked = booked;
}
 
public static List<List<Seat>> generateSeats(int rows, int seat) {
List<List<Seat>> allSeats = new ArrayList<>();
char sectionChar = 'A';
for (int i = 0; i < rows; i++) {
List<Seat> row = new ArrayList<>();
for (int j = 1; j <= seat; j++) {
row.add(new Seat(sectionChar, j, false));
}
allSeats.add(row);
sectionChar++;
}
return allSeats;
}
 
public static void book(List<List<Seat>> seats, String toBook) {
String[] bookingList = toBook.split(",");
for (String booking : bookingList) {
booking = booking.trim();
if (booking.length() < 2) continue;
 
char section = booking.charAt(0);
int number = Integer.parseInt(booking.substring(1));
for (List<Seat> row : seats) {
for (Seat s : row) {
if (s.getSection() == section && s.getNumber() == number) {
s.setBooked(true);
}
}
}
}
 
System.out.println("Seats");
for (List<Seat> row : seats) {
for (Seat s : row) {
if (!s.isBooked()) {
System.out.print(s.getSection() + "" + s.getNumber()+" ");
}
else{
    System.out.print("-- ");
}
}
System.out.println("");
}
}
}