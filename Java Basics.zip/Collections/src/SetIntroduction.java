import java.util.*;
public class SetIntroduction {
	public static void main(String args[]) {
		//write your code here
		Scanner sc=new Scanner(System.in);
		String ch="Y";
		Set<String> s=new HashSet<>();
		while(ch.equalsIgnoreCase("Y")) {
			System.out.println("Enter the username");
			s.add(sc.nextLine());
			System.out.println("Do you want to continue? (Y/N)");
			ch=sc.nextLine();
		}
		System.out.println("The unique number of usernames is "+s.size());
		sc.close();
	}
}
