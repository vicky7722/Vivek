import java.util.*;
 
public class TicketBookingMain {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
List<List<Integer>> weekData = new ArrayList<>();
 
System.out.println("Enter the count of booked tickets:");
 
for (int i = 0; i < 5; i++) {
System.out.println("On Day " + (i + 1));
String[] input = sc.nextLine().split(",");
List<Integer> remaining = new ArrayList<>();
for (String booked : input) {
remaining.add(100 - Integer.parseInt(booked.trim()));
}
weekData.add(remaining);
}
 
String choice;
do {
System.out.println("Enter the day to know its remaining ticket count:");
int day = Integer.parseInt(sc.nextLine().trim());
 
if (day >= 1 && day <= 5) {
List<Integer> tickets = weekData.get(day - 1);
System.out.println("Remaining tickets: " + tickets);
} else {
System.out.println("Invalid day entered. Please enter a number between 1 and 5.");
}
 
System.out.print("Do you want to continue? (y/n)\n");
choice = sc.nextLine().trim().toLowerCase();
 
} while (choice.equals("y"));
 
sc.close();
}
}