import java.util.*; 
public class StringMethodsMain{ 
	public static void main (String[] args) throws Exception{ 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first string :");
		String str1=sc.nextLine();
		System.out.println("Enter the second string :");
		String str2=sc.nextLine();
		System.out.println("Substring : "+str1.substring(3));
		System.out.println("The character at 3rd position in the second string is : "+str2.charAt(3));
		System.out.println("Are string 1 and string 2 equal? : "+str1.equalsIgnoreCase(str2));
		System.out.println("Concatenated string : "+str1.concat(str2));
		sc.close();
		//Fill your code		

	} 
} 



