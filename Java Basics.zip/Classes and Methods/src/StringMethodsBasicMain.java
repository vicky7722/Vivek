
import java.util.*; 
public class StringMethodsBasicMain{ 
	public static void main (String[] args) throws Exception{ 
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first string : ");
		String str1=sc.nextLine();
		System.out.println("Enter the second string : ");
		String str2=sc.nextLine();
		System.out.println("Upper Case : "+str1.toUpperCase());
		System.out.println("Lower Case : "+str2.toLowerCase());
		sc.close();
		//Fill your code		

	} 
} 



