import java.util.*; 
public class SumofanArrayMain{ 
	public static void main (String[] args) throws Exception{
		Scanner sc=new Scanner(System.in);
		int sum=0,i,j;
		System.out.println("Enter n :");
		int n=sc.nextInt();
		int a[]=new int[n];
		for(i=0;i<n;i++){
			a[i]=sc.nextInt();
		}
		for(j=0;j<n;j++){
			sum=sum+a[j];
		}
		System.out.println("Sum of array elements is : "+sum);
		sc.close();

		//Fill your code		

	} 
} 
