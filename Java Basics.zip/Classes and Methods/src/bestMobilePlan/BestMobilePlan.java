package bestMobilePlan;
public class BestMobilePlan
    {
        public static void printPlanDetails(int day,int night,int weekend)
        {
                double a = (Math.max(0,(day-100))*25)+(15*night)+(20*weekend);
                double b = (Math.max(0, (day-250))*45)+(35*night)+(25*weekend);
                a/=100;
                b/=100;
 
                System.out.printf("Plan A costs %.2f\n",a);
                System.out.printf("Plan B costs %.2f\n", b);
                if(a == b)  System.out.println("Plan A and B are the same price");
                else if(b < a) System.out.println("Plan B is cheapest");
                else    System.out.println("Plan A is cheapest");
        }
    }