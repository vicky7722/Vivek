package bestMobilePlan;
import java.util.Scanner;
 
public class Main
    {
        public static void main(String[] args)
        {
            Scanner scan=new Scanner(System.in);
            int day = scan.nextInt();
            int night = scan.nextInt();
            int weekend = scan.nextInt();
            BestMobilePlan.printPlanDetails(day,night,weekend);
            scan.close();
        }
    }
