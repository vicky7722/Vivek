package rectangleDimensionChange;
import java.io.*;
import java.util.Scanner;
 
public class RectangleMain {
    public static void main(String[] args) throws Exception, IOException 
    {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the length of the rectangle");
            int l = sc.nextInt();
            System.out.println("Enter the width of the rectangle");
            int w = sc.nextInt();
            Rectangle r = new Rectangle(l,w);
            r.display();
            System.out.println("Area of the Rectangle:"+r.area());
            System.out.println("Enter the new dimension");
            int newdim = sc.nextInt();
            Rectangle r1 = r.dimensionChange(newdim);
            if(r1 instanceof Rectangle) r1.display();
            System.out.println("Area of the Rectangle:"+r1.area());
 
    }
}



