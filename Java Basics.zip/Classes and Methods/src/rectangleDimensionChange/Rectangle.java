package rectangleDimensionChange;
public class Rectangle 
{
    private Integer length,width;
 
    public Integer getLength() {
        return length;
    }
    public void setLength(Integer length) {
        this.length = length;
    }
    public Integer getWidth() {
        return width;
    }
    public void setWidth(Integer width) {
        this.width = width;
    }
    public Rectangle(Integer length,Integer width)
    {
        this.length = length;
        this.width = width;
    }
    public Integer area() 
    {       
        int area = length * width;
        return area;    
 
    }
    public void display()
    {
        System.out.println("Rectangle Dimension");
        System.out.println("Length:"+length);
        System.out.println("Width:"+width);
 
    }
    
    Rectangle dimensionChange(Integer newDimension)
    {
        length *= newDimension;
        width *=newDimension;
        Rectangle rectangleObject = new Rectangle(length,width);
        return rectangleObject;
    }
    
 
}
 
