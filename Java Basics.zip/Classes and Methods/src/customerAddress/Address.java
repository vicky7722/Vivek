package customerAddress;
public class Address{
    public String street;
    public String city;
    public int pincode;
    public String country;

    public Address(String street,String city,int pincode,String country){
        this.street=street;
        this.city=city;
        this.pincode=pincode;
        this.country=country;
    }
    public Address(){
        
    }

                void displayAddress() {
			//Fill code here
                     System.out.println("Street: "+street);
                     System.out.println("City: "+city);
                     System.out.println("Pincode: "+pincode);
                     System.out.println("Country: "+country);
		}
}