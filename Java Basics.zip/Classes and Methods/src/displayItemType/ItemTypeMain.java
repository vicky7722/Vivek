package displayItemType;
import java.util.*;
class Main{
	public static void main(String[] args) throws Exception{ 
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the item type name");
		String name=sc.nextLine();
		System.out.println("Enter the cost per day");
		Double costPerDay = sc.nextDouble();
		System.out.println("Enter the deposit");
		Double deposit = sc.nextDouble();
		ItemType obj=new ItemType();
		obj.setName(name);
		obj.setCostPerDay(costPerDay);
		obj.setDeposit(deposit);
		obj.display();
		sc.close();
		//Fill your code		

	}
}

