package displayItemType;
public class ItemType {
	private String	name;
	private Double	costPerDay;
	 private Double	deposit;	
	
	public String getName() {
		return name;
	}
 
	public void setName(String name) {
		this.name = name;
	}
 
	public Double getCostPerDay() {
		return costPerDay;
	}
 
	public void setCostPerDay(Double costPerDay) {
		this.costPerDay = costPerDay;
	}
 
	public Double getDeposit() {
		return deposit;
	}
 
	public void setDeposit(Double deposit) {
		this.deposit = deposit;
	}
 
	public void display(){
		System.out.println("Item type details");
		System.out.println("Name : "+name);
		System.out.println("CostPerDay : "+String.format("%.2f",costPerDay));
		System.out.println("Deposit : "+String.format("%.2f",deposit));
		
	
	
	}
}