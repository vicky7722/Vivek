package customerClassWithConstructor;
public class Customer{
	//Fill your code
	public String customerName;
	public String customerEmail;
	public String customerType;
	public String customerAddress;
	
	public void displayDetails(){
		System.out.println("Name: "+customerName);
		System.out.println("E-mail: "+customerEmail);
		System.out.println("Type: "+customerType);
		System.out.println("Location: "+customerAddress);

			//Fill your code

	}

	public Customer(String customerName, String customerEmail, String customerType, String customerAddress) {
		this.customerName = customerName;
		this.customerEmail = customerEmail;
		this.customerType = customerType;
		this.customerAddress = customerAddress;
	}
	
}