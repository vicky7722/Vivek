package comparePhoneNumber;
import java.util.*;
public class UserMain {
 
    public static void main(String[] args) {
        
        
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter Name");
        String name = sc.nextLine();
        
        System.out.println("Enter UserName");
        String username = sc.nextLine();
        
        System.out.println("Enter Password");
        String password = sc.nextLine();
        
        System.out.println("Enter PhoneNumber");
        long phoneNumber = sc.nextLong();
        sc.nextLine();
        User u1 = new User(name,username,password,phoneNumber);
        
        
 
        System.out.println("Enter Name");
        String name1 = sc.nextLine();
        
        System.out.println("Enter UserName");
        String username1 = sc.nextLine();
        
        System.out.println("Enter Password");
        String password1 = sc.nextLine();
        
        System.out.println("Enter PhoneNumber");
        long phoneNumber1 = sc.nextLong();
        
        User u2 = new User(name1,username1,password1,phoneNumber1);
        
        boolean flag = u1.comparePhoneNumber(u2);
        if(flag == true) System.out.println("Same Users");
        else System.out.println("Different Users");
        
 
    }
 
}