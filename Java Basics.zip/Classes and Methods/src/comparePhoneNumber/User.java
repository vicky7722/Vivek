package comparePhoneNumber;

public class User {


       private String name;
       private String username;
       private String password;
       private Long phoneNumber;
       
       public User(String name, String username, String password, Long phoneNumber) {
           this.name=name;
           this.username = username;
           this.password= password;
           this.phoneNumber=phoneNumber;
           
       }
       
       

       public String getName() {
           return name;
       }

       public void setName(String name) {
           this.name = name;
       }

       public String getUsername() {
           return username;
       }

       public void setUsername(String username) {
           this.username = username;
       }

       public String getPassword() {
           return password;
       }

       public void setPassword(String password) {
           this.password = password;
       }

       public Long getPhoneNumber() {
           return phoneNumber;
       }

       public void setPhoneNumber(Long phoneNumber) {
           this.phoneNumber = phoneNumber;
       }
                   boolean flag = false;

       public boolean comparePhoneNumber(User user) 
       {
           if(this.phoneNumber.equals(user.phoneNumber)) 
               flag= true;
           return flag;    
       }
       
   }



