import java.util.*;
public class LuckypairsMain{
    public static void main(String[] args){    	  
        Scanner sc=new Scanner(System.in);
        int a,b,n,i;
        a=sc.nextInt();
        b=sc.nextInt();
        n=sc.nextInt();
        for(i=0;i<n;i++){
            if(i%2==0){
                a=a*2;
            }
            else{
                b=b*2;
            }
        }
        System.out.println(a+b);
        sc.close();
           //Fill your code
    }
}