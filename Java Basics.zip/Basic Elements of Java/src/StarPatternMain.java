import java.util.*;
class StarPatternMain{
	public static void main(String[] args) throws Exception{ 
		Scanner sc=new Scanner(System.in);
		int n,i,j;
		n=sc.nextInt();
		for(i=0;i<n;i++){
			for(j=0;j<=i;j++){
				System.out.print("*");
			}
			System.out.println("");
		} 
		sc.close();
//		Fill your code

	}
}
