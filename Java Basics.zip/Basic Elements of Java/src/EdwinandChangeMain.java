import java.util.*;
class EdwinandChangeMain {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int  n,cnt=0;
        n=sc.nextInt();
        while(n>=100){
            cnt++;
            n=n-100;
        }
        while(n>=50){
            cnt++;
            n=n-50;
        }
        while(n>=10){
            cnt++;
            n=n-10;
        }
        while(n>=5){
            cnt++;
            n=n-5;
        }
        while(n>=2){
            cnt++;
            n=n-2;
        }
        while(n>=1){
            cnt++;
            n=n-1;
        }
        System.out.println(cnt);
        sc.close();
        
            // Fill your code here
        
     }
}