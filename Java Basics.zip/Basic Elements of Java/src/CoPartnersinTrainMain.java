import java.util.*;
public class CoPartnersinTrainMain{
    public static void main(String[] args){ 
        Scanner sc=new Scanner(System.in);
        int n;
        n=sc.nextInt();
        if(n%8==1){
            System.out.println(n+3+"LB");
        }   	     
        else if(n%8==2){
            System.out.println(n+3+"MB");
        }
        else if(n%8==3){
            System.out.println(n+3+"UB");
        }
        else if(n%8==4){
            System.out.println(n-3+"LB");
        }
        else if(n%8==5){
            System.out.println(n-3+"MB");
        }
        else if(n%8==6){
            System.out.println(n-3+"UB");
        }
        else if(n%8==7){
            System.out.println(n+1+"SU");
        }
        else{
            System.out.println(n-1+"SL");
        }
        sc.close();
           //Fill your code
    }
}