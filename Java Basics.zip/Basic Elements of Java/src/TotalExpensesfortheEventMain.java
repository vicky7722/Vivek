import java.util.*;
class Main{
	public static void main(String[] args) throws Exception{ 
		Scanner sc=new Scanner(System.in);
		double be,te,fe,le,toe,bep,tep,fep,lep;
		System.out.println("Enter branding expenses");
		be=sc.nextDouble();
		System.out.println("Enter travel expenses");
		te=sc.nextDouble();
		System.out.println("Enter food expenses");
		fe=sc.nextDouble();
		System.out.println("Enter logistics expenses");
		le=sc.nextDouble();
		toe=Math.round((be+te+fe+le)*100.00)/100.00;
		bep=Math.round(((be/toe)*100)*100.00)/100.00;
		tep=Math.round(((te/toe)*100)*100.00)/100.00;
		fep=Math.round(((fe/toe)*100)*100.00)/100.00;
		lep=Math.round(((le/toe)*100)*100.00)/100.00;
		System.out.println("Total expenses: Rs."+formatDouble(toe));
		System.out.println("Branding expenses percentage: "+formatDouble(bep)+"%");
		System.out.println("Travel expenses percentage: "+formatDouble(tep)+"%");
		System.out.println("Food expenses percentage: "+formatDouble(fep)+"%");
		System.out.println("Logistics expenses percentage: "+formatDouble(lep)+"%");
		sc.close();

//		Fill your code

	}
	public static String formatDouble(double num){
		return String.format("%.2f",num);
	}
}
