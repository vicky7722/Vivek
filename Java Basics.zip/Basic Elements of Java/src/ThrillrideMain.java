import java.util.*;
class ThrillrideMain{
	public static void main(String[] args) throws Exception{ 
		Scanner sc=new Scanner(System.in);
		int n;
		n=sc.nextInt();
		if(n<15 || n>60){
			System.out.println("Not Allowed");
		}
		else{
			System.out.println("Allowed");
		}
		sc.close();
	}
}
