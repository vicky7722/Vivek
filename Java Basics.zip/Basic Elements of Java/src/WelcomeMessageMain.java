public class WelcomeMessageMain{
    public static void main(String[] args){   
        System.out.println("Welcome to Amphi Event Management System"); 	     
           //Fill your code
    }
}