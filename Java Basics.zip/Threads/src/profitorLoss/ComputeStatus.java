package profitorLoss;
import java.util.List;

public class ComputeStatus implements Runnable {
    List<Event> eventList;
 
    public ComputeStatus() {
        super();
    }
 
    public ComputeStatus(List<Event> eventList) {
        super();
        this.eventList = eventList;
    }
 
    @Override
    public void run() {
        for (Event event : eventList) {
            HallBooking booking = event.getHallbooking();
            double percentage = ((double) booking.getSeatsBooked() / booking.getHallCapacity()) * 100;
 
            if (percentage >= 60) {
                System.out.println(event.getName() + " yields profit");
            } else {
                System.out.println(event.getName() + " yields loss");
            }
        }
    }
}