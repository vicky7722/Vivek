package profitorLoss;
public class Event {
    private String name;
    private HallBooking hallbooking;
 
    public Event(String name, HallBooking hallbooking) {
        this.name = name;
        this.hallbooking = hallbooking;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public HallBooking getHallbooking() {
        return hallbooking;
    }
 
    public void setHallbooking(HallBooking hallbooking) {
        this.hallbooking = hallbooking;
    }
}