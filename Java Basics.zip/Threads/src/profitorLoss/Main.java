package profitorLoss;
import java.util.*;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);
 
        System.out.println("Enter the number of events");
        int n = Integer.parseInt(sc.nextLine());
 
        if (n <= 0 || n % 2 != 0) {
            System.out.println("Invalid Input");
            return;
        }
 
        List<Event> eventList = new ArrayList<>();
        System.out.println("Enter event details in CSV");
 
        for (int i = 0; i < n; i++) {
            String[] details = sc.nextLine().split(",");
            String eventName = details[0].trim();
            String hallName = details[1].trim();
            double cost = Double.parseDouble(details[2].trim());
            int hallCapacity = Integer.parseInt(details[3].trim());
            int seatsBooked = Integer.parseInt(details[4].trim());
 
            HallBooking hallBooking = new HallBooking(hallName, cost, hallCapacity, seatsBooked);
            Event event = new Event(eventName, hallBooking);
            eventList.add(event);
        }
 
        // Split event list into two halves
        List<Event> firstHalf = eventList.subList(0, n / 2);
        List<Event> secondHalf = eventList.subList(n / 2, n);
 
        ThreadGroup tg = new ThreadGroup("EventGroup");
 
        Thread t1 = new Thread(tg, new ComputeStatus(firstHalf));
        Thread t2 = new Thread(tg, new ComputeStatus(secondHalf));
 
        t1.start();
        t1.join();  // Ensure first thread finishes before second starts
 
        t2.start();
        t2.join();  // Wait for the second thread to finish
    }
}