package movieRating;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
 
        System.out.println("Enter the ratings");
        String inputRatings = sc.nextLine();
 
        MovieRating ratingThread = new MovieRating(inputRatings);
        ratingThread.start();
    }
}
 