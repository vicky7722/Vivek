package movieRating;
public class MovieRating extends Thread {
    private String ratings;
 
    // Default constructor
    public MovieRating() {
        super();
    }
 
    // Parameterized constructor
    public MovieRating(String ratings) {
        super();
        this.ratings = ratings;
    }
 
    // Getter
    public String getRatings() {
        return ratings;
    }
 
    // Setter
    public void setRatings(String ratings) {
        this.ratings = ratings;
    }
 
    @Override
    public void run() {
        String[] parts = ratings.split(",");
        double sum = 0;
        int count = 0;
 
        for (String part : parts) {
            try {
                sum += Integer.parseInt(part.trim());
                count++;
            } catch (NumberFormatException e) {
                // Skip invalid numbers if any
            }
        }
 
        double average = count > 0 ? sum / count : 0;
        System.out.printf("Rating: %.1f\n", average);
    }
}