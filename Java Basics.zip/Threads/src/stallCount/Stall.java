package stallCount;
public class Stall implements Runnable {
    private String stallName;
    private String details;
    private Double stallArea;
    private String owner;
    private Double stallCost;
 
    public Stall(String stallName, String details, Double stallArea, String owner) {
        this.stallName = stallName;
        this.details = details;
        this.stallArea = stallArea;
        this.owner = owner;
        this.stallCost = 0.0;
    }
 
    public String getStallName() {
        return stallName;
    }
 
    public void setStallName(String stallName) {
        this.stallName = stallName;
    }
 
    public String getDetails() {
        return details;
    }
 
    public void setDetails(String details) {
        this.details = details;
    }
 
    public Double getStallArea() {
        return stallArea;
    }
 
    public void setStallArea(Double stallArea) {
        this.stallArea = stallArea;
    }
 
    public String getOwner() {
        return owner;
    }
 
    public void setOwner(String owner) {
        this.owner = owner;
    }
 
    public Double getStallCost() {
        return stallCost;
    }
 
    public void setStallCost(Double stallCost) {
        this.stallCost = stallCost;
    }
 
    @Override
    public void run() {
        this.stallCost = stallArea * 150.0;
    }
}
 