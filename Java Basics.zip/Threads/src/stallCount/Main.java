package stallCount;
import java.util.ArrayList;
import java.util.Scanner;
 
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
 
        System.out.println("Enter the number of stalls:");
        int n = Integer.parseInt(sc.nextLine());
 
        ArrayList<Stall> stalls = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String input = sc.nextLine();
            String[] details = input.split(",");
 
            String stallName = details[0].trim();
            String stallDetails = details[1].trim();
            Double stallArea = Double.parseDouble(details[2].trim());
            String owner = details[3].trim();
 
            Stall stall = new Stall(stallName, stallDetails, stallArea, owner);
            stalls.add(stall);
        }
 
        ArrayList<Thread> threads = new ArrayList<>();
        for (Stall stall : stalls) {
            Thread thread = new Thread(stall);
            threads.add(thread);
            thread.start();
        }
 
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
 
        double totalRevenue = 0.0;
        for (Stall stall : stalls) {
            totalRevenue += stall.getStallCost();
        }
 
        System.out.printf("The total revenue is %.1f\n", totalRevenue);
 
        sc.close();
    }
}
 