package articlecount;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
 
        System.out.println("Enter the number of lines");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline
 
        Article[] articles = new Article[n];
 
        for (int i = 0; i < n; i++) {
            System.out.println("Enter line " + (i + 1));
            String line = scanner.nextLine();
            articles[i] = new Article(line);
            articles[i].start();
        }
 
        int totalCount = 0;
        for (Article article : articles) {
            try {
                article.join();
                totalCount += article.getCount();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
 
        System.out.println("There are " + totalCount + " articles in the given input");
    }
}
 