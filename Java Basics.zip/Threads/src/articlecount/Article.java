package articlecount;
public class Article extends Thread {
    private String line;
    private int count;
 
    // Parameterized Constructor
    public Article(String line) {
        this.line = line;
        this.count = 0;
    }
 
    // Getter for line
    public String getLine() {
        return line;
    }
 
    // Setter for line
    public void setLine(String line) {
        this.line = line;
    }
 
    // Getter for count
    public int getCount() {
        return count;
    }
 
    // Setter for count
    public void setCount(int count) {
        this.count = count;
    }
 
    // Method to count articles in the line
    @Override
    public void run() {
        String[] words = line.split("\\s+");
        for (String word : words) {
            if (word.equalsIgnoreCase("a") || word.equalsIgnoreCase("an") || word.equalsIgnoreCase("the")) {
                count++;
            }
        }
    }
}