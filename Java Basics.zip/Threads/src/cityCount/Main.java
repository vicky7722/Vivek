package cityCount;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
 
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<User> userList = new ArrayList<>();
 
        System.out.println("Enter the number of users:");
        int n = Integer.parseInt(sc.nextLine());
 
        for (int i = 1; i <= n; i++) {
            System.out.println("Enter the details of user " + i);
            String input = sc.nextLine();
            String[] details = input.split(",");
            User user = new User(details[0].trim(), details[1].trim(), details[2].trim(), details[3].trim());
            userList.add(user);
        }
 
        System.out.println("Enter the number of cities:");
        int m = Integer.parseInt(sc.nextLine());
 
        List<CityCount> cityCountThreads = new ArrayList<>();
 
        for (int i = 1; i <= m; i++) {
            System.out.println("Enter the name of city " + i);
            String city = sc.nextLine();
            CityCount cityCountThread = new CityCount(city, userList);
            cityCountThreads.add(cityCountThread);
            cityCountThread.start(); 
        }
 
        for (CityCount cityCountThread : cityCountThreads) {
            try {
                cityCountThread.join(); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        for (CityCount cityCountThread : cityCountThreads) {
            System.out.println(cityCountThread.getCity() + "--" + cityCountThread.getCount());
        }
 
        sc.close();
    }
}