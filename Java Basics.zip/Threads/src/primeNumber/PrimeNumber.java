package primeNumber;
public class PrimeNumber extends Thread {
    private int number;
 
    // Default constructor
    public PrimeNumber() {
        super();
    }
 
    // Parameterized constructor
    public PrimeNumber(int number) {
        super();
        this.number = number;
    }
 
    // Getter
    public int getNumber() {
        return number;
    }
 
    // Setter
    public void setNumber(int number) {
        this.number = number;
    }
 
    @Override
    public void run() {
        System.out.println("Prime number between 1 to " + number);
        for (int i = 2; i <= number; i++) {
            if (isPrime(i)) {
                System.out.print(i + " ");
            }
        }
        System.out.println(); // Print newline after listing primes
    }
 
    private boolean isPrime(int n) {
        if (n <= 1) return false;
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) return false;
        }
        return true;
    }
}