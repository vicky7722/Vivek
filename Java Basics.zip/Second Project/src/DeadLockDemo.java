public class DeadLockDemo implements Runnable
{
public static void main(String args[])
{
  DeadLockDemo d1=new DeadLockDemo();
  DeadLockDemo d2=new DeadLockDemo();
  Thread t1=new Thread(d1);
  Thread t2=new Thread(d2);
  d1.grabIt=d2;
  d2.grabIt=d1;
  t1.start();
  t2.start();
  System.out.println("Satrted!!!");
  try
  {
   t1.join();
   t2.join();
  }
  catch(InterruptedException e)
  {
   System.out.println("Error Occured!!!");
  }
  System.exit(0);
}
DeadLockDemo grabIt;
public synchronized void run()
{
  try
  {
   Thread.sleep(500);
  }
  catch(InterruptedException e)
  {
   System.out.println("Error Occured!!!");
  }
  grabIt.synchIt();
}
public synchronized void synchIt()
{
  try
  {
   Thread.sleep(500);
   System.out.println("Synch!");
  }
  catch(InterruptedException e)
  {
   System.out.println("Error Occured!!!");
  }
  System.out.println("In the synchIt() Method");
}
}