import java.util.*;
public class SeatMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of rows");
		int r=sc.nextInt();
		System.out.println("Enter the number of seats per row");
		int s=sc.nextInt();
		System.out.println("Enter the seats to book in CSV format");
		List<List<Seat>> Outerseat=new ArrayList<>();
		List<Integer> innerSeat=new ArrayList<>();
		for(int i=0;i<s;i++) {
			
		}
		Seat.generateSeats(r,s);
		
	}

}
