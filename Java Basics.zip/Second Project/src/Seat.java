import java.util.ArrayList;
import java.util.List;

public class Seat {
    private Character section;
	private Integer number;
	private Boolean booked;
	
	public Seat() {}
	public Seat(Character section, Integer number, Boolean booked) {
		super();
		this.section = section;
		this.number = number;
		this.booked = booked;
	}

	public static List<List<Seat>> generateSeats(int rows,int seat){
		// fill your code
		   
	}
	
	public static void book(List<List<Seat>> seat,String seats){
        
        // fill your code
        
	}

	public Character getSection() {
		return section;
	}

	public void setSection(Character section) {
		this.section = section;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public Boolean getBooked() {
		return booked;
	}

	public void setBooked(Boolean booked) {
		this.booked = booked;
	}
	
	
	
}
