import java.util.*;
public class PrimeOddThread implements Runnable{
int num;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrimeOddThread c=new PrimeOddThread();
		Scanner sc=new Scanner(System.in);
		int i=sc.nextInt();
		c.num=i;
		c.start();
		if(c.odd())
			System.out.println("Odd");
		else
			System.out.println("Even");
		sc.close();
	}
	public void run() {
		if(prime()) {
			System.out.println("Prime");
		}
		else {
			System.out.println("Non-Prime");
		}
	}
	public boolean prime() {
		for(int i=2;i<num;i++) {
			if(num%i==0)
				return false;
		}
		return true;
	}
	public boolean odd() {
		if(num%2==0)
			return false;
		else
			return true;
	}
}
