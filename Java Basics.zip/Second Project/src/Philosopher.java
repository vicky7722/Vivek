class Philosopher extends Thread
{
ChopStick left,right;
int philo_num;
 
Philosopher(int num,ChopStick c1, ChopStick c2)
{
philo_num=num;
left=c1;
right=c2;
}
 
public void eat()
{
left.takeup();
right.takeup();
System.out.println("Philospher "+(philo_num+1)+" is eating");
}
 
public void think()
{
left.putdown();
right.putdown();
System.out.println("Philospher "+(philo_num+1)+" is thinking");
}
public void run()
{
while(true)
{
eat();
try
{
   sleep(1000);
}
catch(InterruptedException e) {}
think();
try
{
   sleep(1000);
}
catch(InterruptedException e) {}
 
}}}