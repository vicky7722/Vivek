import java.util.Objects;

public class Hall implements Comparable<Hall>{
	private String name;
	private String contactNumber;
	private double costPerDay;
	private String ownerName;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public double getCostPerDay() {
		return costPerDay;
	}
	public void setCostPerDay(double costPerDay) {
		this.costPerDay = costPerDay;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public Hall(String name, String contactNumber, double costPerDay, String ownerName) {
		super();
		this.name = name;
		this.contactNumber = contactNumber;
		this.costPerDay = costPerDay;
		this.ownerName = ownerName;
	}
	@Override
	public int hashCode() {
		return Objects.hash(contactNumber, costPerDay, name, ownerName);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hall other = (Hall) obj;
		return Objects.equals(contactNumber, other.contactNumber)
				&& Double.doubleToLongBits(costPerDay) == Double.doubleToLongBits(other.costPerDay)
				&& Objects.equals(name, other.name) && Objects.equals(ownerName, other.ownerName);
	}
	@Override
	public String toString() {
		return "Hall [name=" + name + ", contactNumber=" + contactNumber + ", costPerDay=" + costPerDay + ", ownerName="
				+ ownerName + "]";
	}
	public int compareTo(Hall h) {
		if(h.costPerDay>costPerDay) {
			return -1;
		}
		else if(h.costPerDay<costPerDay) {
			return 1;
		}
		else {
			return 0;
		}
	}
}
