class Dining
{
static ChopStick[] chopsticks=new ChopStick[5];
static Philosopher[] philo=new Philosopher[5];
public static void main(String args[])
{
for(int i=0;i<=4;i++)
{
chopsticks[i]=new ChopStick();
}
for(int i=0;i<=4;i++)
{
philo[i]=new Philosopher(i,chopsticks[i],chopsticks[(i+1)%5]);
}
for(int i=0;i<=4;i++)
{
philo[i].start();
}
}
}