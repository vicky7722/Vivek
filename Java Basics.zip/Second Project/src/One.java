class One
{
  void display(int num)
{
  System.out.println(""+num);
  try
  {
   Thread.sleep(1000);
  }
  catch(InterruptedException e)
  {
   System.out.println("Interrupted!!!");
  }
  System.out.println("Done");
}
}