public class Priority extends Thread
{
int n;
public Priority(int n)
{
  this.n=n;
}
public void run()
{
  for(int i=0;i<=n;i++)
  {
   System.out.println("i = "+i);
  }
  System.out.println(Thread.currentThread().getName());
  System.out.println("Its priority was: "+Thread.currentThread().getPriority());
  Thread.currentThread().setPriority(MAX_PRIORITY);
  System.out.println("Its priority now is: "+Thread.currentThread().getPriority());
}
public static void main(String args[])
{
  for(int x=0;x<2;x++)
  {
   Priority p=new Priority(5);
   p.start();
   p.setName("Thread "+(x+1));
  }
}
}