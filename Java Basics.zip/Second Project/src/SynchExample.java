public class SynchExample
{
public static void main(String args[])
{
  One one=new One();
  int digit=10;
  Two s1=new Two(one,digit++);
  Two s2=new Two(one,digit++);
  Two s3=new Two(one,digit++);
  try
  {
   s1.t.join();
   s2.t.join();
   s3.t.join();
  }
  catch(InterruptedException e)
  {}
}
}