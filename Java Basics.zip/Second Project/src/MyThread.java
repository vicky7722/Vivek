public class MyThread implements Runnable{
	public static void main(String args[]){
		MyThread t1=new MyThread();
		t1.create();
		System.out.println("This is main thread!!!");
	}
	public void create(){
		Thread t2=new Thread(this);
		t2.start();
	}
	public void run(){
		while(true){
			try{
				System.out.println("This is child thread....");
				Thread.sleep(500);
			}
			catch(InterruptedException e){}
		}
	}
}